(function () {
  const cont = document.getElementById('defect-map-container');
  if (!cont) return;

  // 準備 Canvas
  const cvs = document.createElement('canvas');
  cvs.width = cont.clientWidth || 900;
  cvs.height = cont.clientHeight || 560;
  cont.innerHTML = '';
  cont.appendChild(cvs);
  const ctx = cvs.getContext('2d');

  // 顯示 tooltip
  const tip = document.createElement('div');
  tip.className = 'map-tooltip';
  tip.style.display = 'none';
  cont.style.position = 'relative';
  cont.appendChild(tip);

  function showTip(x, y, info) {
    tip.innerHTML = `
      <div class="row">
        <div class="dot" style="background:#6aa6ff"></div>
        <div class="meta">${info.label}</div>
        <div>${info.size || ''}</div>
      </div>
      <div class="row"><div></div><div>chip</div><div>${info.chip_name || '-'}</div></div>
      <div class="row"><div></div><div>x,y</div><div>${info.x}, ${info.y}</div></div>
      <div class="row"><div></div><div>pic</div><div>${info.pic_name || ''}</div></div>
    `;
    tip.style.left = `${x + 12}px`;
    tip.style.top = `${y + 12}px`;
    tip.style.display = 'block';
  }
  function hideTip() { tip.style.display = 'none'; }

  // 將 defects array 正規化到 Canvas
  function draw(keys) {
    ctx.clearRect(0, 0, cvs.width, cvs.height);
    if (!keys || keys.length === 0) return;

    // 取得兩筆 defects
    const comp = LR.getCompareData(keys); // {A:[], B:[], keys:[kA,kB]}
    const A = comp.A || [];
    const B = comp.B || [];

    // 估計座標範圍
    const all = A.concat(B);
    if (all.length === 0) return;

    const nums = (v) => (v == null ? 0 : Number(v));
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    all.forEach(d => {
      const x = nums(d.x), y = nums(d.y);
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
    });
    if (!isFinite(minX) || !isFinite(maxX) || minX === maxX) { minX = 0; maxX = 1; }
    if (!isFinite(minY) || !isFinite(maxY) || minY === maxY) { minY = 0; maxY = 1; }

    const pad = 20;
    const scaleX = (x) => pad + (cvs.width - pad * 2) * ((nums(x) - minX) / (maxX - minX));
    const scaleY = (y) => pad + (cvs.height - pad * 2) * ((nums(y) - minY) / (maxY - minY));

    // 底圖
    ctx.fillStyle = '#0b1222';
    ctx.fillRect(0, 0, cvs.width, cvs.height);

    // A
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = '#59c3ff';
    A.forEach(d => {
      const x = scaleX(d.x), y = scaleY(d.y);
      ctx.beginPath();
      ctx.arc(x, y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    });
    // B
    ctx.fillStyle = '#ff7aa2';
    B.forEach(d => {
      const x = scaleX(d.x), y = scaleY(d.y);
      ctx.beginPath();
      ctx.arc(x, y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    });

    // 簡易點選 hit-test（掃描，挑最近點）
    cvs.onclick = (ev) => {
      const rect = cvs.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      let best = null, bestDist = 9e9, bestLabel = '';

      function test(arr, label) {
        for (const d of arr) {
          const x = scaleX(d.x), y = scaleY(d.y);
          const dx = x - mx, dy = y - my;
          const dist = dx * dx + dy * dy;
          if (dist < bestDist && dist < 12 * 12) { best = d; bestDist = dist; bestLabel = label; }
        }
      }
      test(A, 'A'), test(B, 'B');

      if (best) {
        showTip(mx, my, { label: bestLabel, ...best });
      } else {
        hideTip();
      }
    };
  }

  // 只要 selection 改或缺陷載入完成就重畫
  Bus.on('compare-selection-changed', (keys) => draw(keys));
  Bus.on('defect-data-ready', (keys) => draw(keys));

  // 初始隱藏 tip
  cvs.addEventListener('mouseleave', hideTip);
})();