// 多筆 Defect Tables（兩欄並排 + 內層 overflow-y）+ 分組畫廊（水平換行）
(function(){
  const contId = 'defect-lists-container';
  const countId = 'dl-count';
  const galleryId = 'gallery-grid';

  function buildTableForKey(key, defects){
    const { scantime, glass_id, recipe_id } = Utils.parseKey(key);
    const wrap = document.createElement('div');
    wrap.className = 'defect-table-wrap';

    const title = document.createElement('div');
    title.className = 'defect-table-title';
    title.textContent = `${scantime} ｜ ${glass_id} ｜ ${recipe_id}`;
    wrap.appendChild(title);

    const tbl = document.createElement('table');
    tbl.className = 'table defect-table';
    const thead = document.createElement('thead');
    thead.innerHTML = `<tr><th>#</th><th>x</th><th>y</th><th>size</th><th>type</th><th>chip</th><th>image</th></tr>`;
    tbl.appendChild(thead);

    const tbody = document.createElement('tbody');

    // 依「原點→遠」排序給索引（你要求的預設）
    const list = (defects||[]).slice().sort((a,b)=>{
      const da = Utils.dist(+a.x,+a.y,0,0);
      const db = Utils.dist(+b.x,+b.y,0,0);
      return Utils.cmpNum(da, db);
    });

    const imgBase = State.imgBaseByKey[key] || '';
    list.forEach((d,i)=>{
      const tr = document.createElement('tr');
      const x = d.x ?? ''; const y = d.y ?? '';
      const sz = (d.size ?? d.defect_size ?? '').toUpperCase();
      const tp = (d.type ?? d.predict_code ?? '');
      const chip = (d.chip ?? d.chip_name ?? '');

      const file = d.img || d.pic_name || '';
      const src  = Utils.buildImgSrc(imgBase, file);

      tr.innerHTML = `
        <td>${i+1}</td>
        <td>${x}</td>
        <td>${y}</td>
        <td>${sz}</td>
        <td>${tp}</td>
        <td>${chip}</td>
        <td class="img-cell"><img loading="lazy" src="${src}" alt="" /></td>
      `;
      // 點列 → 加到同 key 的分組畫廊
      tr.addEventListener('click', ()=>{
        addToGallery(key, {src, idx:i+1});
      });
      tbody.appendChild(tr);
    });

    tbl.appendChild(tbody);
    wrap.appendChild(tbl);
    return wrap;
  }

  function ensureGalleryGroup(key){
    const grid = document.getElementById(galleryId);
    if(!grid) return null;
    let grp = grid.querySelector(`.gallery-group[data-key="${key}"]`);
    if(!grp){
      grp = document.createElement('section');
      grp.className = 'gallery-group';
      grp.dataset.key = key;
      grp.innerHTML = `
        <header class="gg-title">${key}</header>
        <div class="gg-body"></div>
      `;
      grid.appendChild(grp);
    }
    return grp.querySelector('.gg-body');
  }

  function addToGallery(key, {src, idx}){
    const body = ensureGalleryGroup(key);
    if(!body) return;
    const fig = document.createElement('figure');
    fig.className = 'gallery-item';
    fig.innerHTML = `
      <div class="idx">${idx}</div>
      <img loading="lazy" src="${src}" alt="" />
    `;
    body.appendChild(fig);
  }

  function renderAll(){
    const cont = document.getElementById(contId);
    if(!cont) return;
    cont.innerHTML = '';

    const keys = State.selectedKeys.slice();
    keys.forEach(k=>{
      const defects = State.DefectCache[k] || [];
      cont.appendChild(buildTableForKey(k, defects));
    });

    const c = document.getElementById(countId);
    if(c) c.textContent = String(keys.length);
  }

  // 事件
  Bus.on('defect-refresh', renderAll);
  Bus.on('selection-changed', renderAll);

  // 清空畫廊
  document.getElementById('btnClearGallery')?.addEventListener('click', ()=>{
    const grid = document.getElementById(galleryId);
    if(grid) grid.innerHTML = '';
  });
})();
