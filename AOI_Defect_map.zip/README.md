ROOT: AOI_Defect_map/
    #BACKEND
    main.py
    routers/
            aoi_defect_map.py
    #FRONTEND
    indx.html
    static/
        js/
        css/

#前端模擬資料:static/js/mock_data.js
