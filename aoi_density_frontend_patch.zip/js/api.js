export async function resetSummaryFilter({ dates = null, filters = {} } = {}) {
  const qs = new URLSearchParams();
  if (dates && dates.length === 2) {
    qs.set("dates", dates[0]);
    qs.append("dates", dates[1]);
  }
  if (filters && Object.keys(filters).length > 0) {
    qs.set("filter_ask_keys", JSON.stringify(filters));
  }
  const res = await fetch(`/api/reset_summary_filter?${qs.toString()}`);
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}

export async function defectMap(filters = {}) {
  const qs = new URLSearchParams();
  if (filters && Object.keys(filters).length > 0) {
    qs.set("filter_ask_keys", JSON.stringify(filters));
  }
  const res = await fetch(`/api/defect_map?${qs.toString()}`);
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}
