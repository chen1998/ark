// static/js/bus.js
(function () {
  const listeners = {};
  window.Bus = {
    on(evt, fn) {
      (listeners[evt] ||= []).push(fn);
    },
    emit(evt, payload) {
      (listeners[evt] || []).forEach((fn) => {
        try { fn(payload); } catch (e) { console.error('[Bus]', evt, e); }
      });
    }
  };

  // 全域 State（保持你原本結構，但補齊預設）
  window.State = window.State || {};
  State.filters        = State.filters        || { dateFrom: '', dateTo: '', glassORrecipe: '' };
  // 子篩選：空集合 = 全部顯示
  State.subFilter      = State.subFilter      || { types: new Set(), sizes: new Set() };
  State.selectedKeys   = Array.isArray(State.selectedKeys) ? State.selectedKeys : [];
  State.currentLine    = State.currentLine || null;

  // Cache 統一保證存在（用一般物件即可）
  if (!State.DefectCache)  State.DefectCache  = {};  // key -> defects[]
  if (!State.imgBaseByKey) State.imgBaseByKey = {};  // key -> image base url prefix

  // 簡易 toast
  window.toast = function (msg) {
    let t = document.querySelector('.toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1600);
  };
})();