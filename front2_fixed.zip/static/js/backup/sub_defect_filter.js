// static/js/sub_defect_filter.js
(function(){
  window.State = window.State || {};
  State.subFilter = State.subFilter || { types: new Set(), sizes: new Set() };
  State.fullOptions = State.fullOptions || { types: new Set(), sizes: new Set() };

  const sec = document.getElementById('sub-defect-filter-section');

  function collectOptionsFromMock(){
    const dict = (window.MockData && MockData.sheet_defect_dict) || {};
    const tset = new Set(), sset = new Set();
    Object.keys(dict).forEach(sid=>{
      const g = dict[sid] || {};
      ['A','B'].forEach(k=>{
        (g[k]||[]).forEach(d=>{
          if(d && d.type) tset.add(d.type);
          if(d && d.size) sset.add(d.size);
        });
      });
    });
    if(tset.size===0) ['Dot','Particle','Line','Butterfly'].forEach(x=>tset.add(x));
    if(sset.size===0) ['S','M','L','O'].forEach(x=>sset.add(x));
    State.fullOptions = { types:tset, sizes:sset };

    // 預設全選
    State.subFilter.types = new Set(tset);
    State.subFilter.sizes = new Set(sset);
  }

  function listToDisplay(curSet, fullSet){
    if(curSet.size === 0) return 'None';
    if(fullSet && curSet.size === fullSet.size) return 'ALL';
    return Array.from(curSet).join(', ');
  }

  function updateActiveFiltersView(){
    const el = document.getElementById('active-filters');
    if(!el) return;
    const fullT = State.fullOptions.types, fullS = State.fullOptions.sizes;
    const curT  = State.subFilter.types,   curS  = State.subFilter.sizes;
    el.innerHTML = [
      `<div><b>篩選：</b></div>`,
      `<div><b>type：</b>${listToDisplay(curT, fullT)}</div>`,
      `<div><b>size：</b>${listToDisplay(curS, fullS)}</div>`
    ].join('');
  }

  function render(){
    if(!sec) return;
    sec.innerHTML = '';

    // 內部 grid：第一行 Type/Size，第二行 Actions
    const grid = document.createElement('div');
    grid.className = 'subfilter-grid';

    // 群組建構
    [
      { key:'types', label:'Type', opts:[...State.fullOptions.types].sort() },
      { key:'sizes', label:'Size', opts:[...State.fullOptions.sizes].sort() }
    ].forEach(g=>{
      const box = document.createElement('div');
      box.className = 'subfilter-group';

      const head = document.createElement('div');
      head.className = 'subfilter-head';
      head.textContent = g.label;
      box.appendChild(head);

      const body = document.createElement('div');
      body.className = 'subfilter-body';

      g.opts.forEach(opt=>{
        const id = `sf_${g.key}_${opt}`;
        const lbl = document.createElement('label');
        lbl.className = 'chip';
        lbl.setAttribute('for', id);

        const cb = document.createElement('input');
        cb.type='checkbox';
        cb.id=id; cb.value=opt;
        cb.checked = State.subFilter[g.key].has(opt);
        cb.addEventListener('change', ()=>{
          if(cb.checked) State.subFilter[g.key].add(opt);
          else State.subFilter[g.key].delete(opt);
          updateActiveFiltersView(); // 即時更新三行
        });

        const txt = document.createElement('span');
        txt.textContent = opt;

        lbl.appendChild(cb);
        lbl.appendChild(txt);
        body.appendChild(lbl);
      });

      box.appendChild(body);
      grid.appendChild(box);
    });

    // 第二行：按鈕
    const actions = document.createElement('div');
    actions.className = 'subfilter-actions';

    const btnApply = document.createElement('button');
    btnApply.className = 'btn';
    btnApply.textContent = '套用';
    btnApply.addEventListener('click', ()=>{
      // 正式套用：觸發重繪
      Bus.emit('sub-filter-changed', {
        types: new Set(State.subFilter.types),
        sizes: new Set(State.subFilter.sizes)
      });
    });

    const btnClear = document.createElement('button');
    btnClear.className = 'btn btn-secondary';
    btnClear.textContent = '清空';
    btnClear.addEventListener('click', ()=>{
      State.subFilter.types.clear();
      State.subFilter.sizes.clear();
      sec.querySelectorAll('input[type="checkbox"]').forEach(cb=> cb.checked=false);
      updateActiveFiltersView();
    });

    // 組裝
    sec.appendChild(grid);
    actions.appendChild(btnApply);
    actions.appendChild(btnClear);
    sec.appendChild(actions);

    // 初始顯示
    updateActiveFiltersView();
  }

  Bus.on('init-data', ()=>{
    collectOptionsFromMock();
    render();
  });

  // 若之後需要重建
  Bus.on('rebuild-sub-filter', ()=>{
    collectOptionsFromMock();
    render();
  });
})();

