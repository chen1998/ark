(function(){
  const PALETTE = [
    '#ff6b6b','#4dabf7','#51cf66','#fcc419',
    '#845ef7','#40c057','#ffa94d','#22b8cf',
    '#e64980','#94d82d','#748ffc','#f59f00'
  ];
  const keyColorMap = Object.create(null);
  let colorIdx = 0;

  function colorForKey(key){
    if(!keyColorMap[key]) keyColorMap[key] = PALETTE[(colorIdx++) % PALETTE.length];
    return keyColorMap[key];
  }

  function keyFromRow(r){
    const t = String(r.scantime || '').replace(' ', 'T');
    return `${t}|${r.glass_id}|${r.recipe_id}`;
  }

  function parseKey(key){
    const [scantime, glass_id, recipe_id] = String(key).split('|');
    return { scantime, glass_id, recipe_id };
  }

  function ensureSlash(s){
    if(!s) return '';
    return s.endsWith('/') ? s : (s + '/');
  }

  // 檔名沒有 .jpg 的話自動補上
  function withJpg(file){
    if(!file) return file;
    const f = String(file).toLowerCase();
    if(f.endsWith('.jpg') || f.endsWith('.jpeg') || f.endsWith('.png')) return file;
    return file + '.jpg';
  }

  function buildImgSrc(base, file){
    return ensureSlash(base) + withJpg(file || '');
  }

  function dist(a,b,c,d){
    const dx = (+a) - (+c);
    const dy = (+b) - (+d);
    return Math.sqrt(dx*dx + dy*dy);
  }

  function cmpNum(a,b){ return (a||0)-(b||0); }

  window.Utils = { colorForKey, keyFromRow, parseKey, buildImgSrc, dist, cmpNum };
})();