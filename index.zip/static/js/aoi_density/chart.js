// static/js/aoi_density/chart.js
(function () {
  const MOD = (window.AOI_DENSITY = window.AOI_DENSITY || {});
  MOD.Charts = MOD.Charts || {};

  const $ = (sel, root = document) => root.querySelector(sel);

  function fmtYYMMDDHH(d) {
    if (!(d instanceof Date) || isNaN(d)) return "";
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const hh = String(d.getHours()).padStart(2, "0");
    return `${yy}-${mm}-${dd} ${hh}`;
  }
  function parsePiHourKeyToDate(key) {
    const d = new Date(String(key).replace(" ", "T"));
    return isNaN(d) ? null : d;
  }
  function buildGlobalRowOrder(rows){
    const byLine = new Map();
    (rows||[]).forEach(r=>{
      if(!r?.line_id || !r?.model) return;
      if(!byLine.has(r.line_id)) byLine.set(r.line_id, new Set());
      byLine.get(r.line_id).add(r.model);
    });
    const lines = Array.from(byLine.keys()).sort(); // 若要自訂順序，可改成你的清單
    const order = [];
    lines.forEach(line=>{
      const models = Array.from(byLine.get(line)).sort();
      models.forEach(m=> order.push({ line_id: line, model: m }));
    });
  
    // 供畫分隔線/標籤使用
    const lineGroups = [];
    let i = 0;
    while(i < order.length){
      const line = order[i].line_id;
      const start = i;
      while(i < order.length && order[i].line_id === line) i++;
      lineGroups.push({ line_id: line, start, end: i-1 });
    }
    return { order, lineGroups };
  }

  function dateSortKey(k) {
    return new Date("20" + String(k).replace(" ", "T")).getTime();
  }

  // === 關鍵改動：以 (AOI, ai_code_1) 當「水平欄」 ===
  // columns = [{ aoi, code, xTicks, rows:[… 全部依 globalOrder 排好且補齊 …] }]
  function buildColumnsByAoiCode(rows, globalOrder){
    const agg = {};                 // agg[aoi][code][line][model][tick] = {g,r}
    const ticksByAoiCode = {};      // ticksByAoiCode[aoi|code] = Set(ticks)

    (rows || []).forEach((r) => {
      const { aoi, ai_code_1: code, line_id, model, pi_hour, n_rows, n_glasses } = r || {};
      if (!aoi || !code || !line_id || !model || !pi_hour) return;

      const d = parsePiHourKeyToDate("20" + pi_hour);
      const tick = d ? fmtYYMMDDHH(d) : pi_hour;

      const key = `${aoi}|${code}`;
      (ticksByAoiCode[key] = ticksByAoiCode[key] || new Set()).add(tick);

      const A = (agg[aoi] = agg[aoi] || {});
      const C = (A[code] = A[code] || {});
      const L = (C[line_id] = C[line_id] || {});
      const M = (L[model] = L[model] || {});
      const T = (M[tick] = M[tick] || { g: 0, r: 0 });
      T.g += Number(n_glasses || 0);
      T.r += Number(n_rows || 0);
    });

    const columns = [];
    Object.keys(agg).sort().forEach((aoi) => {
      const perCode = agg[aoi];
      Object.keys(perCode).sort().forEach((code) => {
        const xTicks = Array.from(ticksByAoiCode[`${aoi}|${code}`] || [])
          .sort((a,b)=> new Date("20"+a.replace(" ","T")) - new Date("20"+b.replace(" ","T")));

        // 依「全域順序」逐一產生 row；沒有資料的欄位也補 0/null 占位，確保對齊
        const rowsOut = globalOrder.map(({line_id, model})=>{
          const bucket = (((agg[aoi]||{})[code]||{})[line_id]||{})[model] || {};
          const glasses = xTicks.map(tk => (bucket[tk]?.g) || 0);
          const density = xTicks.map(tk => {
            const v = bucket[tk]; return v && v.g>0 ? v.r/v.g : null;
          });
          return {
            aoi, code, line_id, model,
            glasses, density,
            maxG: Math.max(0, ...glasses),
            maxD: Math.max(0, ...density.filter(x=>x!=null))
          };
        });

        columns.push({ aoi, code, xTicks, rows: rowsOut });
      });
    });

    return columns;
  }


  function ensureHost() {
    const host = $("#aoi_density-facet");
    if (!host) return null;
    host.innerHTML = "";
    host.classList.add("aoi-density-grid");
    const chartDiv = document.createElement("div");
    chartDiv.className = "aoi-bigchart";
    chartDiv.style.height = "320px";
    host.appendChild(chartDiv);
    return chartDiv;
  }

  // 互動狀態
  const interopState = {
    selectedTicks: new Set(),     // key = idx|aoi|code
    focusRowKey: null             // key = aoi|code|rowLocalIndex
  };

  function calcOpacity(aoi, code, rowKey, xIdx) {
    let passTick = true;
    if (interopState.selectedTicks.size > 0) {
      passTick = interopState.selectedTicks.has(`${xIdx}|${aoi}|${code}`);
    }
    let passRow = true;
    if (interopState.focusRowKey && interopState.focusRowKey !== rowKey) {
      passRow = false;
    }
    if (passTick && passRow) return 1;
    if (!passTick) return 0.18;
    if (!passRow) return 0.28;
    return 1;
  }

  // 單一 ECharts 大圖（水平欄 = (AOI, ai_code_1)）
  function renderBigChart(dom, columns, global) {
    const ec = window.echarts;
    if (!ec) return;

    // 佈局
    const padTop = 42;  // 上方要放雙層抬頭：第一層 AOI、第二層 ai_code_1
    const padBottom = 44;
    const leftMargin = 64, rightMargin = 56;
    const colGap = 24;
    const rowH = 118, rowGap = 10;

    // 最高欄的 row 數，用來決定高度
    const maxRows = Math.max(1, global.order.length);

    const totalH = padTop + maxRows * rowH + (maxRows - 1) * rowGap + padBottom + 60;
    dom.style.height = totalH + "px";

    const width = dom.clientWidth || 1200;
    const nCols = Math.max(1, columns.length);
    const colWidth = Math.max(
      260,
      Math.floor((width - leftMargin - rightMargin - (nCols - 1) * colGap) / nCols)
    );

    const inst = ec.init(dom);

    // 先計算 AOI 分組（畫群組抬頭需要）
    const groups = []; // [{aoi,startCol,count}]
    let curAoi = null, start = 0;
    columns.forEach((c, idx) => {
      if (c.aoi !== curAoi) {
        if (curAoi != null) groups.push({ aoi: curAoi, startCol: start, count: idx - start });
        curAoi = c.aoi;
        start = idx;
      }
      if (idx === columns.length - 1) {
        groups.push({ aoi: c.aoi, startCol: start, count: idx - start + 1 });
      }
    });

    function buildOption() {
      const grids = [], xAxes = [], yAxes = [], series = [], graphics = [], dataZoom = [];
    
      let xAxisCountSoFar = 0; // 用於事件反推「這個 xAxis 屬於第幾欄」
      const colAxisIndexRange = []; // [{colIndex, aoi, code, xStart, xEnd}]
    
      // === 每一欄（AOI × ai_code_1） ===
      columns.forEach((col, colIdx) => {
        const { aoi, code, xTicks, rows } = col;
        const colLeft = leftMargin + colIdx * (colWidth + colGap);
        const hasRows = rows.length > 0;
    
        // 第二層抬頭：ai_code_1
        graphics.push({
          type: "text",
          left: colLeft + colWidth / 2,
          top: 2,
          style: { text: code, fill: "#d4e0ff", fontWeight: 700, fontSize: 12, textAlign: "center" }
        });
    
        // 欄內每個 row
        let curTop = padTop;
        rows.forEach((row, rIdx) => {
          const isBottom = (rIdx === rows.length - 1);
    
          // grid
          const gridIndex = grids.length;
          grids.push({ left: colLeft, top: curTop, width: colWidth, height: rowH });
    
          // xAxis（只在最底 row 顯示刻度）
          const xAxisIndex = xAxes.length;
          xAxes.push({
            type: "category",
            gridIndex,
            data: xTicks,
            axisTick: { alignWithLabel: true },
            axisLabel: { show: isBottom, rotate: 90, margin: 12 },
            axisLine: { onZero: false },
            triggerEvent: true
          });
    
          // yLeft（片數）
          const gMax = Math.max(1, Math.ceil((row.maxG || 1) * 1.2));
          const yLeftIndex = yAxes.length;
          yAxes.push({
            type: "value",
            gridIndex,
            min: 0, max: gMax,
            name: `${row.line_id} • ${row.model}`,
            nameTextStyle: { padding: [0,0,8,0], fontWeight: 600 },
            splitLine: { show: true },
            triggerEvent: true
          });
    
          // yRight（密度）
          const dMax = Math.max(1, (row.maxD || 0) * 1.4);
          const yRightIndex = yAxes.length;
          yAxes.push({ type: "value", gridIndex, min: 0, max: dMax, splitLine: { show: false } });
    
          const rowKey = `${aoi}|${code}|${rIdx}`;
          const barId = `bar:${aoi}:${code}:${rIdx}`;
          const scId  = `sc:${aoi}:${code}:${rIdx}`;
    
          // bar：片數
          series.push({
            id: barId,
            name: "n_glasses",
            type: "bar",
            xAxisIndex,
            yAxisIndex: yLeftIndex,
            barMaxWidth: 14,
            itemStyle: { color: "#FFA62B", opacity: 1 },
            label: { show: true, position: "top", formatter: p => (p.value > 0 ? p.value : ""), fontSize: 10 },
            data: row.glasses.map((v, i) => ({ value: v, itemStyle: { opacity: calcOpacity(aoi, code, rowKey, i) } })),
            universalTransition: true
          });
    
          // scatter：密度
          series.push({
            id: scId,
            name: "density",
            type: "scatter",
            xAxisIndex,
            yAxisIndex: yRightIndex,
            symbolSize: 7,
            itemStyle: { color: "#4C7FFF", opacity: 1 },
            label: { show: true, position: "top", formatter: p => (p.data == null ? "" : Number(p.data).toFixed(2)), fontSize: 10 },
            data: row.density.map((v, i) => ({ value: v, itemStyle: { opacity: (v == null) ? 0 : calcOpacity(aoi, code, rowKey, i) } })),
            connectNulls: false,
            universalTransition: true
          });
    
          curTop += rowH + (isBottom ? 0 : rowGap);
        });
    
        // 記錄此欄 xAxis 索引範圍
        const xStart = xAxisCountSoFar;
        const xEnd = xStart + rows.length; // 每個 row 1 條 xAxis
        colAxisIndexRange.push({ colIndex: colIdx, aoi, code, xStart, xEnd });
        xAxisCountSoFar = xEnd;
    
        // 每欄 dataZoom（inside + slider）
        if (hasRows) {
          const xIdxs = Array.from({ length: rows.length }, (_, i) => xStart + i);
          dataZoom.push(
            { type: "inside", xAxisIndex: xIdxs, filterMode: "filter" },
            { type: "slider", xAxisIndex: xIdxs, left: colLeft, bottom: 8, width: colWidth, height: 16, brushSelect: false }
          );
        }
    
        // ✅ 在「欄」的範圍內畫 line 群組標籤與分隔線（這裡有 colLeft）
        (global.lineGroups || []).forEach(gp=>{
          const top = padTop + gp.start * (rowH + rowGap);
          const bottom = padTop + gp.end * (rowH + rowGap) + rowH;
    
          // 左側旋轉 line_id 標籤
          graphics.push({
            type: "text",
            left: colLeft - 6,
            top: (top + bottom) / 2,
            rotation: -Math.PI/2,
            style: { text: gp.line_id, fill: "#f38aff", fontWeight: 700, fontSize: 12, textAlign: "center" }
          });
    
          // 分隔線（群組上緣）
          if (gp.start > 0) {
            graphics.push({
              type: "line",
              shape: { x1: colLeft, y1: top - rowGap/2, x2: colLeft + colWidth, y2: top - rowGap/2 },
              style: { stroke: "rgba(255,255,255,0.10)" }
            });
          }
        });
      });
    
      // === AOI 跨欄抬頭（只畫文字，不再用到 colLeft） ===
      groups.forEach(g => {
        const left = leftMargin + g.startCol * (colWidth + colGap);
        const right = left + g.count * colWidth + (g.count - 1) * colGap;
        graphics.push({
          type: "text",
          left: (left + right) / 2,
          top: 18,
          style: { text: g.aoi, fill: "#89a6ff", fontWeight: 800, fontSize: 13, textAlign: "center" }
        });
      });
    
      return {
        animation: true,
        legend: { top: 0, right: 10, data: ["n_glasses", "density"] },
        tooltip: { trigger: "axis", axisPointer: { type: "cross", snap: true } },
        axisPointer: { link: [] },
        brush: {
          toolbox: [],
          brushMode: "single",
          brushType: "lineX",
          xAxisIndex: Array.from({length: xAxisCountSoFar}, (_,i)=>i)
        },
        grid: grids,
        xAxis: xAxes,
        yAxis: yAxes,
        series,
        graphic: graphics,
        dataZoom,
        __colAxisIndexRange: colAxisIndexRange
      };
    }

    let option = buildOption();
    inst.setOption(option);

    // 點 X 軸刻度 → 高亮該 tick（限定在被點欄位）
    inst.off("click");
    inst.on("click", function (ev) {
      if (ev?.componentType === "xAxis") {
        const xAxisIndex = ev?.xAxisIndex ?? ev?.axisIndex ?? 0;
        const ranges = inst.getOption().__colAxisIndexRange || [];
        let found = null;
        for (const r of ranges) {
          if (xAxisIndex >= r.xStart && xAxisIndex < r.xEnd) { found = r; break; }
        }
        if (!found) return;

        const { aoi, code } = found;
        // 找到此欄的本地 tick 索引
        const col = columns[found.colIndex];
        const localIdx = col.xTicks.indexOf(String(ev.value));
        if (localIdx < 0) return;

        const key = `${localIdx}|${aoi}|${code}`;
        if (interopState.selectedTicks.has(key)) interopState.selectedTicks.delete(key);
        else interopState.selectedTicks.add(key);
        refreshOpacity(inst, columns);
      } else if (ev?.componentType === "yAxis") {
        const yIdx = ev?.yAxisIndex;
        if (yIdx == null) return;
        // 由 yAxis 名稱反推 row
        const yAxes = inst.getOption().yAxis || [];
        const ya = yAxes[yIdx];
        if (!ya || !ya.name) return;

        // 找出是哪個 (aoi,code) 欄的哪一個 row
        let hit = null;
        columns.some((col) =>
          col.rows.some((row, i) => {
            const nm = `${row.line_id} • ${row.model}`;
            if (nm === ya.name) { hit = { aoi: col.aoi, code: col.code, local: i }; return true; }
            return false;
          })
        );
        if (!hit) return;
        const key = `${hit.aoi}|${hit.code}|${hit.local}`;
        interopState.focusRowKey = (interopState.focusRowKey === key) ? null : key;
        refreshOpacity(inst, columns);
      }
    });

    // 刷選 → 記錄該欄 tick 區間
    inst.off("brushselected");
    inst.on("brushselected", function (params) {
      interopState.selectedTicks.clear();
      const sel = params.batch?.[0]?.selected || [];
      const ranges = inst.getOption().__colAxisIndexRange || [];

      sel.forEach((s) => {
        const axisIndex = s.xAxisIndex;   // 單值
        const idxRange = s.dataIndex;     // [start,end]
        if (!Array.isArray(idxRange) || idxRange.length < 2) return;

        let found = null;
        for (const r of ranges) {
          if (axisIndex >= r.xStart && axisIndex < r.xEnd) { found = r; break; }
        }
        if (!found) return;

        const { aoi, code } = found;
        const [sidx, eidx] = idxRange;
        const lo = Math.min(sidx, eidx), hi = Math.max(sidx, eidx);
        for (let i = lo; i <= hi; i++) {
          interopState.selectedTicks.add(`${i}|${aoi}|${code}`);
        }
      });

      refreshOpacity(inst, columns);
    });

    // 視窗縮放 → 重新排版
    window.addEventListener("resize", () => {
      inst.resize();
      const op = buildOption();
      inst.setOption(op, true, true);
      refreshOpacity(inst, columns);
    });
  }

  // 依互動狀態更新透明度（以 series id 精準更新）
  function refreshOpacity(inst, columns) {
    const updates = [];
    columns.forEach((col) => {
      const { aoi, code, rows } = col;
      rows.forEach((row, rIdx) => {
        const rowKey = `${aoi}|${code}|${rIdx}`;

        const barId = `bar:${aoi}:${code}:${rIdx}`;
        const newBarData = (row.glasses || []).map((v, i) => ({
          value: v,
          itemStyle: { opacity: calcOpacity(aoi, code, rowKey, i) }
        }));
        updates.push({ id: barId, data: newBarData });

        const scId = `sc:${aoi}:${code}:${rIdx}`;
        const newScData = (row.density || []).map((v, i) => ({
          value: v,
          itemStyle: { opacity: v == null ? 0 : calcOpacity(aoi, code, rowKey, i) }
        }));
        updates.push({ id: scId, data: newScData });
      });
    });
    if (updates.length) inst.setOption({ series: updates }, false, false);
  }

  // 對外：渲染入口
  MOD.Charts.render = function (rows, _paramDict) {
    const dom = ensureHost();
    if (!dom) return;
    const global = buildGlobalRowOrder(rows || []);
    const columns = buildColumnsByAoiCode(rows || [], global.order);
    if (!columns.length) { dom.innerHTML = "<div class='muted'>沒有資料</div>"; return; }
    renderBigChart(dom, columns, global); // ← 多帶 global
  };
  
})();
