// static/js/defect_map.js
(function(){
  const DEBUG = true;
  //const log = (...a)=>{ if(DEBUG) console.log('[MAP]', ...a); };

  const MAP_W = (window.MockData && MockData.MAP_W) || 1850;
  const MAP_H = (window.MockData && MockData.MAP_H) || 1500;

  // ---- DOM ----
  const mapSection   = document.getElementById('defect-map-section') || document.body;
  const mapContainer = document.getElementById('defect-map-container') || mapSection;

  // 若缺少 selection-summary / defect tables，這裡自動補上
  function ensureEl(id, parent, klass){
    let el = document.getElementById(id);
    if(!el){
      el = document.createElement('div');
      el.id = id;
      if(klass) el.className = klass;
      (parent||mapSection).appendChild(el);
      log('auto-created', id);
    }
    return el;
  }
  //const selSummaryEl = ensureEl('selection-summary', mapSection, 'selection-summary');
  const tablesSection= document.getElementById('defect-tables-section');
  const contA        = document.getElementById('defect-table-A') ;
  const contB        = document.getElementById('defect-table-B') ;

  const activeFilterEl = document.getElementById('active-filters');

  // ---- Canvas ----
  let canvas = document.getElementById('defect-canvas');
  if(!canvas){ canvas = document.createElement('canvas'); canvas.id = 'defect-canvas'; mapContainer.appendChild(canvas); }
  const ctx = canvas.getContext('2d');

  // ---- View ----
  let vw = 800, vh = 600;                 // 會由 ResizeObserver 覆寫
  const view = { sx:0, sy:0, scale:1 };
  let isPanning = false, lastX=0, lastY=0;
  let boxZoomMode=false, boxStart=null, boxRect=null;

  // ---- Utils ----
  const worldToScreen=(x,y)=>({x:(x-view.sx)*view.scale, y:(y-view.sy)*view.scale});
  const screenToWorld=(x,y)=>({x:x/view.scale+view.sx, y:y/view.scale+view.sy});
  const radiusForSize=(s)=>({S:2,M:3,L:4,O:6}[s]||3);

  // defect_map.js 內，替換整個 renderActiveFilterText()
  /*
  function renderActiveFilterText(){
    const el = document.getElementById('active-filters');
    if(!el) return;

    // 計算顯示字串（ALL/None/逗號串接）
    const fullT = State.fullOptions?.types || new Set();
    const fullS = State.fullOptions?.sizes || new Set();
    const curT  = State.subFilter?.types || new Set();
    const curS  = State.subFilter?.sizes || new Set();

    const listToDisplay = (curSet, fullSet)=>{
      if(curSet.size === 0) return 'None';
      if(fullSet && curSet.size === fullSet.size) return 'ALL';
      return Array.from(curSet).join(', ');
    };

    const typesStr = listToDisplay(curT, fullT);
    const sizesStr = listToDisplay(curS, fullS);

    el.innerHTML = [
      `<div><b>篩選：</b></div>`,
      `<div><b>type：</b>${typesStr}</div>`,
      `<div><b>size：</b>${sizesStr}</div>`
    ].join('');
  }
    */

  function passFilter(x){
    const types = State.subFilter?.types || new Set();
    const sizes = State.subFilter?.sizes || new Set();
    return (!types.size || types.has(x.type)) && (!sizes.size || sizes.has(x.size));
  }

  function getCompareData(){
    const [kA, kB] = State.selectedKeys || [];
    const rawA = kA ? LR.defectsForKey(kA) : [];
    const rawB = kB ? LR.defectsForKey(kB) : [];
    const A = rawA.filter(passFilter);
    const B = rawB.filter(passFilter);
    log('getCompareData', {keys: State.selectedKeys, a: A.length, b: B.length});
    return [A,B];
  }

  function drawGrid(){
    const p1=screenToWorld(0,0), p2=screenToWorld(vw,vh);
    const wx1=Math.max(0,Math.min(p1.x,p2.x)), wy1=Math.max(0,Math.min(p1.y,p2.y));
    const wx2=Math.min(MAP_W,Math.max(p1.x,p2.x)), wy2=Math.min(MAP_H,Math.max(p1.y,p2.y));
    const minor=50, major=200;
    const sxm=Math.floor(wx1/minor)*minor, sym=Math.floor(wy1/minor)*minor;
    const sxM=Math.floor(wx1/major)*major, syM=Math.floor(wy1/major)*major;

    ctx.save(); ctx.lineWidth=1; ctx.strokeStyle='rgba(60,86,126,0.25)';
    for(let x=sxm;x<=wx2;x+=minor){ const sx=worldToScreen(x,0).x; ctx.beginPath(); ctx.moveTo(sx,worldToScreen(0,wy1).y); ctx.lineTo(sx,worldToScreen(0,wy2).y); ctx.stroke(); }
    for(let y=sym;y<=wy2;y+=minor){ const sy=worldToScreen(0,y).y; ctx.beginPath(); ctx.moveTo(worldToScreen(wx1,0).x,sy); ctx.lineTo(worldToScreen(wx2,0).x,sy); ctx.stroke(); }
    ctx.restore();

    ctx.save(); ctx.lineWidth=1; ctx.strokeStyle='rgba(120,160,220,0.35)';
    for(let x=sxM;x<=wx2;x+=major){ const sx=worldToScreen(x,0).x; ctx.beginPath(); ctx.moveTo(sx,worldToScreen(0,wy1).y); ctx.lineTo(sx,worldToScreen(0,wy2).y); ctx.stroke(); }
    for(let y=syM;y<=wy2;y+=major){ const sy=worldToScreen(0,y).y; ctx.beginPath(); ctx.moveTo(worldToScreen(wx1,0).x,sy); ctx.lineTo(worldToScreen(wx2,0).x,sy); ctx.stroke(); }
    ctx.restore();

    ctx.save(); ctx.fillStyle='#9fb0d8'; ctx.font='10px sans-serif';
    for(let x=sxM;x<=wx2;x+=major){ const p=worldToScreen(x,wy1); ctx.fillText(String(x), p.x+2, worldToScreen(0,wy1).y + 12); }
    for(let y=syM;y<=wy2;y+=major){ const p=worldToScreen(wx1,y); ctx.fillText(String(y), worldToScreen(wx1,0).x + 4, p.y - 2); }
    ctx.restore();
  }

  function matchClose(aList,bList,eps=4){
    const grid=new Map(); const key=(x,y)=>`${Math.round(x/eps)}|${Math.round(y/eps)}`;
    bList.forEach(b=>{ const k=key(b.x,b.y); (grid.get(k)||grid.set(k,[]).get(k)).push(b); });
    const matched=[]; aList.forEach(a=>{ const k=key(a.x,a.y); const arr=grid.get(k); if(arr&&arr.length) matched.push({x:a.x,y:a.y}); });
    return matched;
  }

  function draw(){
    ctx.clearRect(0,0,vw,vh);
    drawGrid();

    // 外框
    ctx.save(); ctx.strokeStyle='#23324d'; ctx.lineWidth=1;
    const tl=worldToScreen(0,0), br=worldToScreen(MAP_W,MAP_H);
    ctx.strokeRect(tl.x,tl.y,br.x-tl.x, br.y-tl.y);
    ctx.restore();

    const [A,B] = getCompareData();

    // A
    ctx.fillStyle='#6aa6ff';
    for(const d of A){ const p=worldToScreen(d.x,d.y); ctx.beginPath(); ctx.arc(p.x,p.y,radiusForSize(d.size),0,Math.PI*2); ctx.fill(); }

    // B
    ctx.fillStyle='#9E7BFF';
    for(const d of B){ const p=worldToScreen(d.x,d.y); ctx.beginPath(); ctx.arc(p.x,p.y,radiusForSize(d.size),0,Math.PI*2); ctx.fill(); }

    // overlap
    const same=matchClose(A,B,4);
    ctx.fillStyle='#35d49a';
    for(const pt of same){ const p=worldToScreen(pt.x,pt.y); ctx.beginPath(); ctx.arc(p.x,p.y,2.5,0,Math.PI*2); ctx.fill(); }

    if(boxRect){
      ctx.save(); ctx.strokeStyle='#8fb3ff'; ctx.setLineDash([4,3]); ctx.strokeRect(boxRect.x,boxRect.y,boxRect.w,boxRect.h); ctx.restore();
    }
  }

  // ---- 互動 ----
  function zoomFit(){ const sx=vw/MAP_W, sy=vh/MAP_H; view.scale=Math.min(sx,sy); view.sx=0; view.sy=0; draw(); }
  function zoomAt(cx,cy,f){ const b=screenToWorld(cx,cy); view.scale*=f; const a=screenToWorld(cx,cy); view.sx+=(b.x-a.x); view.sy+=(b.y-a.y); draw(); }

  canvas.addEventListener('wheel', e=>{ e.preventDefault(); zoomAt(e.offsetX,e.offsetY, e.deltaY<0?1.15:1/1.15); });
  canvas.addEventListener('mousedown', e=>{
    if(boxZoomMode){ boxStart={x:e.offsetX,y:e.offsetY}; boxRect={x:boxStart.x,y:boxStart.y,w:0,h:0}; draw(); return; }
    isPanning=true; lastX=e.offsetX; lastY=e.offsetY;
  });
  canvas.addEventListener('mousemove', e=>{
    if(boxStart){ boxRect.w=e.offsetX-boxStart.x; boxRect.h=e.offsetY-boxStart.y; draw(); return; }
    if(isPanning){
      const dx=(e.offsetX-lastX)/view.scale, dy=(e.offsetY-lastY)/view.scale;
      view.sx-=dx; view.sy-=dy; lastX=e.offsetX; lastY=e.offsetY; draw(); return;
    }
  });
  window.addEventListener('mouseup', ()=>{
    if(isPanning) isPanning=false;
    if(boxStart){
      const x1=Math.min(boxStart.x, boxStart.x+boxRect.w), y1=Math.min(boxStart.y, boxStart.y+boxRect.h);
      const x2=Math.max(boxStart.x, boxStart.x+boxRect.w), y2=Math.max(boxStart.y, boxStart.y+boxRect.h);
      const w=x2-x1, h=y2-y1;
      if(w>10 && h>10){
        const p1=screenToWorld(x1,y1), p2=screenToWorld(x2,y2);
        const s=Math.min(vw/(p2.x-p1.x), vh/(p2.y-p1.y));
        view.scale=s; view.sx=p1.x; view.sy=p1.y;
      }
      boxStart=null; boxRect=null; boxZoomMode=false; draw();
    }
  });
  canvas.addEventListener('dblclick', zoomFit);

  // 控制鈕（若有）
  const btn=(id,fn)=>{ const el=document.getElementById(id); if(el) el.addEventListener('click', fn); };
  btn('map-zoom-fit', zoomFit);
  btn('map-zoom-in', ()=>zoomAt(vw/2,vh/2,1.25));
  btn('map-zoom-out',()=>zoomAt(vw/2,vh/2,0.8));
  btn('map-box-zoom',()=>{ boxZoomMode=true; toast && toast('框選放大：在畫面上拖拉矩形'); });

  // ---- Resize ----
  const ro=new ResizeObserver(entries=>{
    for(const entry of entries){
      const cw=entry.contentRect.width, ch=entry.contentRect.height;
      const idealH=Math.round(cw*(MAP_H/MAP_W));
      const useH=Math.min(ch||idealH, idealH);
      canvas.width=vw=Math.max(400, Math.round(cw-2));
      canvas.height=vh=Math.max(300, useH);
      zoomFit();
    }
  });
  ro.observe(mapContainer);

  // ---- Defect tables & summary ----
  function buildTable(container, title, arr){
    container.innerHTML = "";

    const headBar=document.createElement('div');
    headBar.className='section-title';
    const titleSpan=document.createElement('span'); titleSpan.textContent=title||'';
    const stats=document.createElement('span'); stats.className='stats-badges';
    stats.innerHTML=`<span class="badge">筆數 <b>${arr.length}</b></span>`;
    headBar.appendChild(titleSpan); headBar.appendChild(stats);
    container.appendChild(headBar);

    const wrap=document.createElement('div'); wrap.className='table-wrap';
    const table=document.createElement('table'); table.className='table';

    const thead=document.createElement('thead'); const trh=document.createElement('tr');
    ["Type","Size","Value","X","Y"].forEach(n=>{ const th=document.createElement('th'); th.textContent=n; trh.appendChild(th); });
    thead.appendChild(trh); table.appendChild(thead);

    const tbody=document.createElement('tbody');
    arr.forEach(r=>{
      const tr=document.createElement('tr');
      [r.type, r.size, r.value, r.x.toFixed(1), r.y.toFixed(1)].forEach(val=>{
        const td=document.createElement('td'); td.textContent=val; tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);

    wrap.appendChild(table);
    container.appendChild(wrap);
  }

  function renderDefectTablesAndSummary(){
    const [kA,kB] = State.selectedKeys || [];
    const rawA = kA ? LR.defectsForKey(kA) : [];
    const rawB = kB ? LR.defectsForKey(kB) : [];
    const A = rawA.filter(passFilter);
    const B = rawB.filter(passFilter);

    const titleA = (()=>{
      if(!kA) return "第一筆：未選";
      const r=LR.rowForKey(kA); return `${r.measure_time}｜Sheet:${r.sheet_id}｜Recipe:${r.recipe_id}`;
    })();
    const titleB = (()=>{
      if(!kB) return "第二筆：未選";
      const r=LR.rowForKey(kB); return `${r.measure_time}｜Sheet:${r.sheet_id}｜Recipe:${r.recipe_id}`;
    })();

    buildTable(contA, titleA, A);
    buildTable(contB, titleB, B);

    // 同步 selection summary
    /*
    if(selSummaryEl){
      const fmt=(k,lbl)=>{
        if(!k) return `<div class="sel-card empty">${lbl}：未選</div>`;
        const r=LR.rowForKey(k);
        return `<div class="sel-card"><b>${lbl}</b>｜${r.measure_time}｜Sheet:${r.sheet_id}｜Recipe:${r.recipe_id}</div>`;
      };
      selSummaryEl.innerHTML = fmt(kA,'第一筆') + fmt(kB,'第二筆');
    }
    */
    log('render tables', {A:A.length, B:B.length});
  }

  function refreshAll(){
    //renderActiveFilterText();
    renderDefectTablesAndSummary();
    draw();
  }

  // ---- Bus ----
  Bus.on('init-data', refreshAll);
  Bus.on('compare-selection-changed', refreshAll);
  Bus.on('sub-filter-changed', refreshAll);
})();