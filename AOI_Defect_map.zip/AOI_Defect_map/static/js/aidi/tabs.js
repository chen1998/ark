// 上方 aidi tabs（UPI/SPOT…）
(function(){
    const ns = window.AIDI;
  
    ns.renderTopTabs = function(){
      const host = ns.qs('#all-tab-container'); if(!host) return;
      const tabs = ['UPI Hourly','SPOT Hourly','UPI Hourly BY Line','SPOT Hourly BY Line','SPEC','異常說明'];
      const row = ns.el('div',{class:'tabs-row'});
      tabs.forEach((name, idx)=>{
        const b = ns.el('button',{class:'tab-btn'}); b.textContent = name;
        if ((ns.state.currentTab==null && idx===0) || ns.state.currentTab===name) { b.classList.add('active'); ns.state.currentTab = name; }
        b.addEventListener('click',()=>{
          ns.qsa('.tabs-row .tab-btn', row).forEach(x=>x.classList.remove('active'));
          b.classList.add('active'); ns.state.currentTab = name;
          ns.renderCharts(); ns.renderTable();
        });
        row.appendChild(b);
      });
      if (ns.state.tabsCacheHTML==null) ns.state.tabsCacheHTML = host.innerHTML;
      host.innerHTML = ''; host.appendChild(row);
    };
  })();