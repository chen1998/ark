// static/js/api1.js
(function () {
  // --- 保險初始化：就算 bus.js 還沒跑也不會噴錯 ---
  window.AppData = window.AppData || { lineTabs: [], allRunInfo: {}, currentLine: null };
  window.State   = window.State   || {}; // bus.js 會補齊其他欄位，這邊先確保不為 undefined

  const API = {};
  window.API = API;

  const API_BASE = window.API_BASE || '';

  async function fetchJSON(url) {
    // 若後端 CORS 啟用 credentials，需確保 allow-origin 是實際來源且 allow-credentials=true
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`${url} ${res.status}`);
    return res.json();
  }

  // 取全部 run-info（首頁）
  API.fetchAllRunInfo = async function () {
    return fetchJSON(`${API_BASE}/api/run-info`);
  };

  // 依 line + 日期區間取 run-info
  API.fetchRunInfoByLine = async function (lineId, start, end) {
    const u = new URL(`${API_BASE}/api/run-info`, window.location.origin);
    if (lineId) u.searchParams.set('line_id', lineId);
    if (start)  u.searchParams.set('start', start);
    if (end)    u.searchParams.set('end', end);
    return fetchJSON(u.toString());
  };

  // 取缺陷明細：回傳一定是陣列，並把快取寫入 State.DefectCache（同時寫入 'T' 與 ' ' 兩種 key）
  API.fetchDefects = async function (key, lineId) {
    const nkey = Utils.normalizeKey(key);
    const u = new URL(`${API_BASE}/api/defect-data`, window.location.origin);
    u.searchParams.set('key', nkey);
    if (lineId) u.searchParams.set('line_id', lineId);
    const data = await fetchJSON(u.toString());

    // 轉成純陣列
    const arr = Array.isArray(data)
      ? data
      : (Array.isArray(data.defects) ? data.defects
        : (data.defects && Array.isArray(data.defects.defects) ? data.defects.defects : []));
    
    // 寫入兩種別名（T/空白）
    Utils.aliasKeys(nkey).forEach(kk => {
      //console.log(kk,arr);
      State.DefectCache[kk] = arr;
    });

    // 通知地圖、Defect tables 重畫
    Bus.emit('defect-refresh');
    return arr;
  };

  // ====== UI 綁定 ======
  function buildTabs(lineTabs, allRunInfo) {
    const cont = document.getElementById('all-tab-container');
    if (!cont) return;
    cont.innerHTML = '';

    const row = document.createElement('div');
    row.className = 'tabs-row';

    lineTabs.forEach((line, i) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn';
      btn.textContent = line;
      if (i === 0) btn.classList.add('active');
      btn.addEventListener('click', () => {
        row.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        State.currentLine = line;

        const dict = allRunInfo[line] || {};
        const rows = Object.values(dict);
        Bus.emit('render-run-info', rows);

        // 更新日期區間顯示
        updateDateRangeFromRows(rows);
      });
      row.appendChild(btn);
    });

    cont.appendChild(row);
  }

  function updateDateRangeFromRows(rows) {
    if (!rows || !rows.length) return;
    // 優先用 run_day，否則從 scantime 取日期
    const days = rows.map(r => {
      if (r.run_day)   return String(r.run_day).slice(0, 10);
      if (r.scantime)  return String(r.scantime).slice(0, 10);
      return null;
    }).filter(Boolean);

    if (!days.length) return;
    days.sort();
    const from = days[0];
    const to   = days[days.length - 1];
    const f = document.getElementById('fDateFrom');
    const t = document.getElementById('fDateTo');
    if (f) f.value = from;
    if (t) t.value = to;
  }

  function bindTopControls() {
    const f = document.getElementById('fQuery');
    const btnApplyQ = document.getElementById('applyQuery');
    const btnClearQ = document.getElementById('clearQuery');
    if (btnApplyQ) btnApplyQ.addEventListener('click', () => {
      State.filters.glassORrecipe = (f && f.value || '').trim();
      Bus.emit('filters-changed');
    });
    if (btnClearQ) btnClearQ.addEventListener('click', () => {
      if (f) f.value = '';
      State.filters.glassORrecipe = '';
      Bus.emit('filters-changed');
    });

    const dFrom = document.getElementById('fDateFrom');
    const dTo   = document.getElementById('fDateTo');
    const btnApplyD = document.getElementById('applyDates');
    const btnClearD = document.getElementById('clearDates');

    if (btnApplyD) btnApplyD.addEventListener('click', async () => {
      const line = State.currentLine;
      if (!line) { toast('請先選擇 Line'); return; }
      const start = dFrom && dFrom.value ? dFrom.value : '';
      const end   = dTo   && dTo.value   ? dTo.value   : '';
      try {
        const data = await API.fetchRunInfoByLine(line, start, end);
        if (data.UniRunInfoTableData) {
          // 更新 AppData、重畫
          AppData.allRunInfo[line] = data.UniRunInfoTableData;
          const rows = Object.values(data.UniRunInfoTableData);
          Bus.emit('render-run-info', rows);
          updateDateRangeFromRows(rows);
        }
      } catch (e) {
        console.error(e); toast('日期查詢失敗');
      }
    });

    if (btnClearD) btnClearD.addEventListener('click', () => {
      if (dFrom) dFrom.value = '';
      if (dTo)   dTo.value   = '';
    });
  }

  // 勾選後，run_info_table 會 emit 'request-defects'
  Bus.on('request-defects', async (keys) => {
    const list = Array.isArray(keys) ? keys : [];
    for (const k of list) {
      const nk = Utils.normalizeKey(k);
      // 已有就跳過
      if (State.DefectCache[nk]) continue;
      try { await API.fetchDefects(nk, State.currentLine); }
      catch (e) { console.error('[request-defects] fetchDefects', e); }
    }
  });

  // 初始化：拉 AllRunInfo + 建 tabs + 渲染第一個 line
  async function init() {
    try {
      const payload = await API.fetchAllRunInfo();
      AppData.lineTabs  = payload.AllLineTabs || [];
      AppData.allRunInfo= payload.AllRunInfoTableData || {};
      buildTabs(AppData.lineTabs, AppData.allRunInfo);

      if (AppData.lineTabs.length) {
        const line = AppData.lineTabs[0];
        State.currentLine = line;
        const dict = AppData.allRunInfo[line] || {};
        const rows = Object.values(dict);
        Bus.emit('render-run-info', rows);
        updateDateRangeFromRows(rows);
      }

      bindTopControls();
    } catch (e) {
      console.error('[api.js] init error:', e);
      toast('初始化資料失敗');
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();