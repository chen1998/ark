// static/js/utils.js
(function(){
  window.Utils = window.Utils || {};

  // 由 row 產生統一 key：時間強制帶 'T'
  Utils.keyFromRow = function(r){
    const t = String(r.scantime || '').replace(' ', 'T');
    return `${t}|${r.glass_id}|${r.recipe_id}`;
  };

  // 解析 key
  Utils.parseKey = function(k){
    const [t,g,r] = (k||'').split('|');
    return { scantime: t, glass_id: g, recipe_id: r };
  };

  // 將 key 統一為 'T' 格式
  Utils.normalizeKey = function(k){
    if(!k || typeof k !== 'string') return '';
    const ps = k.split('|');
    if(ps.length < 3) return k;
    ps[0] = ps[0].replace(' ', 'T');
    return ps.join('|');
  };

  // 回傳 'T' 與 ' ' 兩種別名（同時存 cache，避免模組彼此找不到）
  Utils.aliasKeys = function(k){
    const n = Utils.normalizeKey(k);
    return [ n, n.replace('T',' ') ];
  };

  // 日期字串安全轉 Date
  Utils.toDate = function(s){
    if(!s) return new Date(0);
    return new Date(String(s).replace(' ', 'T'));
  };
})();
