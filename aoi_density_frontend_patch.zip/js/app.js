import { resetSummaryFilter } from './api.js';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  dates: null,            // [startISO, endISO]
  filters: {},            // { line_id:[], aoi:[], ... }
  lastChartData: null,
  paramDict: null,
};

function toISO(dtLocalValue) {
  // dtLocalValue like '2025-09-16T15:00'
  if (!dtLocalValue) return null;
  return dtLocalValue.replace('T', ' ') + ':00';
}

function unique(arr) { return Array.from(new Set(arr)).sort(); }

function fillSelect($sel, values) {
  const old = new Set(Array.from($sel.selectedOptions).map(o => o.value));
  $sel.innerHTML = '';
  values.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    if (old.has(v)) opt.selected = true;
    $sel.appendChild(opt);
  });
}

function extractFilterOptions(filterData) {
  const keys = ['line_id','aoi','model','glass_type','ai_code_1','pi_hour'];
  const colVals = Object.fromEntries(keys.map(k => [k, new Set()]));
  for (const row of filterData) {
    for (const k of keys) {
      if (row[k] != null && row[k] !== '') colVals[k].add(k === 'pi_hour' ? (row[k].slice(2,16)) : row[k]);
    }
  }
  return Object.fromEntries(Object.entries(colVals).map(([k,v]) => [k, Array.from(v).sort()]));
}

// Flatten ChartDataDict into panels [ {line_id,aoi, seriesData, hours} ]
function flattenChartData(chartDict) {
  const panels = []; // { line_id, aoi, modelSet, codeSet, hours, series: {S,M,L,O,UNK,n_glasses} }
  if (!chartDict) return panels;
  for (const [line_id, byAoi] of Object.entries(chartDict)) {
    for (const [aoi, byModel] of Object.entries(byAoi)) {
      const hourMap = new Map(); // hour -> {S,M,L,O,UNK,n_glasses}
      const modelSet = new Set();
      const codeSet = new Set();
      for (const [model, bySide] of Object.entries(byModel)) {
        modelSet.add(model);
        for (const [side, byCode] of Object.entries(bySide)) {
          for (const [code, byHour] of Object.entries(byCode)) {
            codeSet.add(code);
            for (const [hour, v] of Object.entries(byHour)) {
              const key = hour;
              if (!hourMap.has(key)) {
                hourMap.set(key, { S:0, M:0, L:0, O:0, UNK:0, n_glasses:0 });
              }
              const agg = hourMap.get(key);
              agg.S += v.small_defect_count || 0;
              agg.M += v.middle_defect_count || 0;
              agg.L += v.large_defect_count || 0;
              agg.O += v.over_defect_count || 0;
              agg.UNK += v.unknown_defect_count || 0;
              agg.n_glasses += v.n_glasses || 0;
            }
          }
        }
      }
      const hours = Array.from(hourMap.keys()).sort();
      const series = {
        S: hours.map(h => hourMap.get(h).S),
        M: hours.map(h => hourMap.get(h).M),
        L: hours.map(h => hourMap.get(h).L),
        O: hours.map(h => hourMap.get(h).O),
        UNK: hours.map(h => hourMap.get(h).UNK),
        n_glasses: hours.map(h => hourMap.get(h).n_glasses),
      };
      panels.push({ line_id, aoi, hours, series, modelSet: Array.from(modelSet), codeSet: Array.from(codeSet) });
    }
  }
  // Order panels by line then aoi
  panels.sort((a,b)=> (a.line_id+a.aoi).localeCompare(b.line_id+b.aoi));
  return panels;
}

function mountPanels(panels) {
  const grid = $('#chartsGrid');
  grid.innerHTML = '';
  if (!panels.length) {
    grid.innerHTML = '<div class="muted" style="padding:12px">No data</div>';
    return;
  }
  for (const p of panels) {
    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.innerHTML = \`
      <div class="panel-head">
        <div><b>\${p.line_id}</b> · <span>\${p.aoi}</span></div>
        <div class="muted">Models: \${p.modelSet.join(', ')} | AI Codes: \${p.codeSet.join(', ')}</div>
      </div>
      <div class="chart"></div>
    \`;
    grid.appendChild(panel);
    makeChart(panel.querySelector('.chart'), p);
  }
}

function makeChart(el, p) {
  const chart = echarts.init(el);
  const hoursLabel = p.hours.map(h => h.slice(2,16)); // show YY-MM-DD HH
  const option = {
    animation: false,
    tooltip: { trigger:'axis' },
    grid: { left: 40, right: 14, top: 22, bottom: 26 },
    legend: { top: 0, data: ['S','M','L','O','UNK','n_glasses'] },
    xAxis: { type:'category', data: hoursLabel, axisLabel:{ interval: hoursLabel.length>24?3:0, rotate:45 } },
    yAxis: [
      { type:'value', name:'defects (count)', position:'left' },
      { type:'value', name:'n_glasses', position:'right', splitLine:{show:false} }
    ],
    series: [
      { type:'bar', name:'S', stack:'sizes', data:p.series.S },
      { type:'bar', name:'M', stack:'sizes', data:p.series.M },
      { type:'bar', name:'L', stack:'sizes', data:p.series.L },
      { type:'bar', name:'O', stack:'sizes', data:p.series.O },
      { type:'bar', name:'UNK', stack:'sizes', data:p.series.UNK, tooltip:{valueFormatter:x=>x} },
      { type:'line', name:'n_glasses', yAxisIndex:1, data:p.series.n_glasses, symbol:'circle' }
    ]
  };
  chart.setOption(option);
  new ResizeObserver(()=>chart.resize()).observe(el);
}

function getSelected($sel) {
  return Array.from($sel.selectedOptions).map(o => o.value);
}

function buildFiltersFromUI() {
  const filters = {};
  const add = (key, arr) => { if (arr && arr.length) filters[key] = arr; }
  add('line_id', getSelected($('#selLine')));
  add('aoi', getSelected($('#selAoi')));
  add('model', getSelected($('#selModel')));
  add('glass_type', getSelected($('#selSide')));
  add('ai_code_1', getSelected($('#selCode')));
  add('defect_size', getSelected($('#selSize')));
  const piHours = getSelected($('#selPiHour'));
  if (piHours.length) filters['pi_hour'] = piHours; // backend accepts 'yy-mm-dd hh'
  return filters;
}

function fillUIOptions(filterOptions) {
  fillSelect($('#selLine'), filterOptions.line_id || []);
  fillSelect($('#selAoi'), filterOptions.aoi || []);
  fillSelect($('#selModel'), filterOptions.model || []);
  fillSelect($('#selSide'), filterOptions.glass_type || []);
  fillSelect($('#selCode'), filterOptions.ai_code_1 || []);
  fillSelect($('#selPiHour'), filterOptions.pi_hour || []);
}

async function reload(fromButton=false) {
  try {
    $('#status').textContent = 'loading...';
    const dates = (() => {
      const s = toISO($('#dtStart').value);
      const e = toISO($('#dtEnd').value);
      if (s && e) return [s, e];
      return null;
    })();
    const filters = buildFiltersFromUI();
    const data = await resetSummaryFilter({ dates, filters });
    state.lastChartData = data.ChartDataDict;
    state.paramDict = data.ParamDict;
    // update filter options from FilterData
    const fo = extractFilterOptions(data.FilterData || []);
    fillUIOptions(fo);
    // draw charts
    const panels = flattenChartData(state.lastChartData);
    mountPanels(panels);
    const nRows = (data.FilterData||[]).length;
    $('#footNote').textContent = `rows: ${nRows} | panels: ${panels.length}`;
  } catch (err) {
    console.error(err);
    alert('Load failed: ' + err.message);
  } finally {
    $('#status').textContent = '';
  }
}

window.addEventListener('DOMContentLoaded', () => {
  $('#btnRefresh').addEventListener('click', () => reload(true));
  $('#btnApply').addEventListener('click', () => reload(true));
  reload();
});
