// AIDI 服務：修正 API 路徑（帶 /api 前綴）
(function(){
  const ns = window.AIDI = window.AIDI || {};
  const API = `${window.API_BASE}/aidi`;

  ns.fetchAIDIData = async function(params={}){
    const usp = new URLSearchParams({ days:'7', reload:'false', ...params });
    const r = await fetch(`${API}/hourly?${usp.toString()}`);
    if(!r.ok){ throw new Error(`${API} /hourly 失敗`); }
    return r.json();
  };

  ns.fetchHourlyPoints = async function({ time, line_id, aoi_id, model_id, defect_codes=[], sizes=[] }){
    const usp = new URLSearchParams({ time, line_id, aoi_id, model_id, output: 'points' });
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    if (sizes.length) usp.set('sizes', sizes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(points)`);
    return r.json();
  };

  ns.fetchRunsUnderHourGroup = async function({ time, line_id, aoi_id, model_id, defect_codes=[] }){
    const usp = new URLSearchParams({ time, line_id, aoi_id, model_id, output:'runs' });
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(runs)`);
    return r.json();
  };

  ns.fetchPointsByRun = async function({ scantime, glass_id, recipe_id, aoi_id, line_id=null, defect_codes=[], sizes=[] }){
    const usp = new URLSearchParams({ scantime, glass_id, recipe_id, aoi_id, output:'points' });
    if (line_id) usp.set('line_id', line_id);
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    if (sizes.length) usp.set('sizes', sizes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(points-run)`);
    return r.json();
  };
})();

/*
根據service2.js中現有的連線API程式及後端API程式
在table.js中新增功能
1.在觸發展開btn時detail-title水平右側新增一容器,該容器內新增全選及清空按鈕,兩按鈕水平排列
2.在sub table最左側新增一列勾選box,讓使用者可勾選特定多個glass row(同defect_map的runinfo table勾選功能)
3.在觸發第一點時要連線defects_query傳遞match keys的dict {
        line_id: rowData.line_id,
        aoi_id: rowData.aoi_id,
        model_id: rowData.model_id,
        bytimehour: getHour(rowData),
      }
4.在觸發sub table的勾選時要連線defects_query傳遞傳遞line_id, aoi_id, scantime,glass_id,recipe_id

第三點要求資料為整批run貨資訊(多片glass)的defect資料
第四點要求資料為單片glass對應的defect資料
解析js/defect_map中的所有功能程式檔案 現在要在aidi上建立的table展開及sub table勾選後取得defect_rows是
為了在aidi中的map-viewport有選擇性地疊加顯示defect座標,同Defect map基本概念相同
給我增加新功能的table.js及可以傳遞參數給api連線要求資料的程式
並檢查density_char.py與前端連線設定是否保持移置可正常要求資料,不行的話依照原有程式的邏輯去修改回傳完整資料
*/