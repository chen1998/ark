// static/js/defect_map1.js
(function () {
  const cvs = document.getElementById('defect-map-canvas');
  if (!cvs) return;
  const ctx = cvs.getContext('2d');

  // ---------- State ----------
  window.State = window.State || {};
  // 相容兩種形態：Map 或 物件
  State.DefectCache = State.DefectCache || new Map();
  State.imgBaseByKey = State.imgBaseByKey || {};
  State.ColorKeyMap = State.ColorKeyMap || new Map(); // key -> color
  State.MapFilter = State.MapFilter || { sizes: new Set(), types: new Set() }; // 空集合 = 全部
  State.currentLine = State.currentLine || null;

  // ---------- Canvas / View ----------
  const DPR = Math.max(1, Math.floor(window.devicePixelRatio || 1));
  let W = 1000, H = 620; // 視窗內分配的實際畫布 UI 大小
  let padding = 30;
  const view = {
    base: { sx: 1, sy: 1, tx: 0, ty: 0 }, // 自動 fit 的基礎轉換
    zoom: 1,
    pan: { x: 0, y: 0 },
  };

  // 互動暫態
  let isPanning = false;
  let last = { x: 0, y: 0 };
  let boxing = false;
  let boxStart = null;
  let boxEnd = null;

  // ---------- 顏色 & 尺寸 ----------
  const PALETTE = [
    '#2563eb', '#ef4444', '#10b981', '#f59e0b',
    '#8b5cf6', '#06b6d4', '#e11d48', '#22c55e',
    '#9333ea', '#0ea5e9', '#f97316', '#16a34a'
  ];
  let colorIdx = 0;
  function colorForKey(k) {
    if (!State.ColorKeyMap.has(k)) {
      State.ColorKeyMap.set(k, PALETTE[colorIdx % PALETTE.length]);
      colorIdx++;
    }
    return State.ColorKeyMap.get(k);
  }

  // API 有時是 S/M/L/O，有時是數字 defect_size，統一轉成 S/M/L/O
  function normalizeSize(d) {
    const s = d.size ?? d.defect_size;
    if (s == null) return 'S';
    if (typeof s === 'string') {
      // 已是 S/M/L/O？
      const up = s.toUpperCase();
      if (/^[SMLO]$/.test(up)) return up;
      // 可能是數字字串
      const n = +s;
      if (!isNaN(n)) return sizeFromNumber(n);
      return 'S';
    }
    if (typeof s === 'number') return sizeFromNumber(s);
    return 'S';
  }
  function sizeFromNumber(n) {
    // 可按你實際規則調整
    if (n <= 10) return 'S';
    if (n <= 20) return 'M';
    if (n <= 30) return 'L';
    return 'O';
  }
  const RADIUS = { S: 2.2, M: 3.5, L: 5.0, O: 6.5 };

  // ---------- 取 defects（相容 Map or Object） ----------
  function getDefects(key) {
    const C = State.DefectCache;
    if (!C) return [];
    // Map
    if (typeof C.get === 'function') {
      return C.get(key) || [];
    }
    // Object
    return C[key] || [];
  }

  // ---------- Points 組合 ----------
  function allPoints() {
    const pts = [];
    (State.selectedKeys || []).forEach((k) => {
      const color = colorForKey(k);
      const arr = getDefects(k);
      if (!arr || !arr.length) return;
      arr.forEach((d) => {
        let x = +d.x, y = +d.y;
        if (Number.isNaN(x) || Number.isNaN(y)) return;

        const sz = normalizeSize(d);
        const tp = d.type ?? d.predict_code ?? ''; // 型別字
        pts.push({ key: k, color, x, y, size: sz, type: tp });
      });
    });
    return pts;
  }

  // ---------- Filters（尺寸 / 類型） ----------
  function passFilters(points) {
    const fs = State.MapFilter.sizes;
    const ft = State.MapFilter.types;
    return points.filter((p) => {
      const okSize = fs.size ? fs.has(p.size) : true;
      const okType = ft.size ? ft.has(String(p.type)) : true;
      return okSize && okType;
    });
  }

  // ---------- Bounds & Fit ----------
  function computeBounds(points) {
    if (!points.length) {
      return { minX: 0, maxX: 1, minY: 0, maxY: 1 };
    }
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    points.forEach((p) => {
      if (p.x < minX) minX = p.x;
      if (p.x > maxX) maxX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.y > maxY) maxY = p.y;
    });
    if (minX === maxX) { minX -= 1; maxX += 1; }
    if (minY === maxY) { minY -= 1; maxY += 1; }
    return { minX, maxX, minY, maxY };
  }

  function fitBase(bounds) {
    const ww = bounds.maxX - bounds.minX;
    const hh = bounds.maxY - bounds.minY;
    const vw = W - padding * 2;
    const vh = H - padding * 2;
    const sx = vw / ww;
    const sy = vh / hh;
    const s = Math.min(sx, sy);

    // 把 (minX,minY) 對齊到畫布 padding 位置
    const tx = padding - bounds.minX * s;
    const ty = padding - bounds.minY * s;

    view.base.sx = s;
    view.base.sy = s;
    view.base.tx = tx;
    view.base.ty = ty;
  }

  // world → screen
  function toScreen(x, y) {
    const s = view.base.sx * view.zoom;
    const tX = view.base.tx + view.pan.x;
    const tY = view.base.ty + view.pan.y;
    return { x: x * s + tX, y: y * s + tY };
  }
  // screen → world
  function toWorld(px, py) {
    const s = view.base.sx * view.zoom;
    const tX = view.base.tx + view.pan.x;
    const tY = view.base.ty + view.pan.y;
    return { x: (px - tX) / s, y: (py - tY) / s };
  }

  // ---------- Axis ticks ----------
  function niceStep(range) {
    const rough = range / 6; // 6 ticks
    const pow = Math.pow(10, Math.floor(Math.log10(rough)));
    const base = rough / pow;
    let nice;
    if (base < 1.5) nice = 1;
    else if (base < 3) nice = 2;
    else if (base < 7) nice = 5;
    else nice = 10;
    return nice * pow;
  }
  function drawAxes(bounds) {
    ctx.save();
    ctx.fillStyle = '#6b7280';
    ctx.strokeStyle = '#9ca3af';
    ctx.lineWidth = 1;

    // X 方向
    const xr = bounds.maxX - bounds.minX;
    const xs = niceStep(xr);
    for (let v = Math.ceil(bounds.minX / xs) * xs; v <= bounds.maxX; v += xs) {
      const p = toScreen(v, bounds.minY);
      ctx.beginPath();
      ctx.moveTo(p.x, H - padding + 4);
      ctx.lineTo(p.x, H - padding + 10);
      ctx.stroke();

      ctx.font = '11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(String(Math.round(v)), p.x, H - padding + 22);
    }
    // X 軸線
    ctx.beginPath();
    ctx.moveTo(padding, H - padding);
    ctx.lineTo(W - padding, H - padding);
    ctx.stroke();

    // Y 方向（標在左側）
    const yr = bounds.maxY - bounds.minY;
    const ys = niceStep(yr);
    for (let v = Math.ceil(bounds.minY / ys) * ys; v <= bounds.maxY; v += ys) {
      const p = toScreen(bounds.minX, v);
      ctx.beginPath();
      ctx.moveTo(padding - 4, p.y);
      ctx.lineTo(padding - 10, p.y);
      ctx.stroke();

      ctx.font = '11px system-ui, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(String(Math.round(v)), padding - 12, p.y + 4);
    }
    // Y 軸線
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, H - padding);
    ctx.stroke();

    ctx.restore();
  }

  // ---------- Draw ----------
  function drawAll() {
    // resize canvas backing store
    const rect = cvs.getBoundingClientRect();
    W = Math.max(600, Math.floor(rect.width));
    H = Math.max(360, Math.floor(rect.height));
    cvs.width = W * DPR;
    cvs.height = H * DPR;
    cvs.style.width = W + 'px';
    cvs.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0b1020';
    ctx.fillRect(0, 0, W, H);

    // 組資料
    const pts0 = allPoints();
    const pts = passFilters(pts0);
    const bounds = computeBounds(pts.length ? pts : pts0);

    // 如果 base 未初始化或選取變更，重新 fit
    fitBase(bounds);

    // 背景格線/軸
    drawAxes(bounds);

    // 畫點
    ctx.save();
    pts.forEach((p) => {
      const r = RADIUS[p.size] || 3;
      const sc = toScreen(p.x, p.y);
      ctx.beginPath();
      ctx.fillStyle = p.color;
      ctx.globalAlpha = 0.9;
      ctx.arc(sc.x, sc.y, r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();

    // 若在框選，畫橡皮框
    if (boxing && boxStart && boxEnd) {
      ctx.save();
      ctx.strokeStyle = '#f59e0b';
      ctx.setLineDash([6, 4]);
      ctx.lineWidth = 2;
      const x = Math.min(boxStart.x, boxEnd.x);
      const y = Math.min(boxStart.y, boxEnd.y);
      const w = Math.abs(boxEnd.x - boxStart.x);
      const h = Math.abs(boxEnd.y - boxStart.y);
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
    }

    // legend
    renderLegend();
  }

  function renderLegend() {
    const box = document.getElementById('map-legend');
    if (!box) return;
    const keys = (State.selectedKeys || []).slice();
    if (!keys.length) {
      box.innerHTML = '<div class="legend-empty">未選取</div>';
      return;
    }
    const html = keys.map((k) => {
      const c = colorForKey(k);
      // 只顯示簡短
      const parts = k.split('|');
      const label = parts.length === 3 ? `${parts[0]}｜${parts[1]}｜${parts[2]}` : k;
      return `<div class="legend-item"><i style="background:${c}"></i><span>${label}</span></div>`;
    }).join('');
    box.innerHTML = html;
  }

  // ---------- Controls（Zoom/Reset + Filters） ----------
  function ensureControls() {
    const ctr = document.querySelector('.map-controls');
    if (!ctr) return;
    // 若已建立就不重複
    if (ctr.dataset.enhanced === '1') return;
    
    const frag = document.createElement('div');
    frag.className = 'map-ctrls-row';
    frag.innerHTML = `
      <div class="btn-group">
        <button id="btnZoomIn" class="btn btn-xs">＋</button>
        <button id="btnZoomOut" class="btn btn-xs">－</button>
        <button id="btnResetView" class="btn btn-xs btn-secondary">重置</button>
      </div>
      <div class="filters">
        <span class="label">尺寸</span>
        <label><input type="checkbox" class="sz" value="S" checked>S</label>
        <label><input type="checkbox" class="sz" value="M" checked>M</label>
        <label><input type="checkbox" class="sz" value="L" checked>L</label>
        <label><input type="checkbox" class="sz" value="O" checked>O</label>
        <span class="label">類型</span>
        <span id="type-box"></span>
      </div>
    `;
    ctr.appendChild(frag);
    ctr.dataset.enhanced = '1';

    // 初始化尺寸篩選
    State.MapFilter.sizes = new Set(['S', 'M', 'L', 'O']);
    ctr.querySelectorAll('input.sz').forEach((cb) => {
      cb.addEventListener('change', () => {
        const set = new Set();
        ctr.querySelectorAll('input.sz:checked').forEach((c) => set.add(c.value));
        State.MapFilter.sizes = set;
        drawAll();
      });
    });

    // Zoom buttons
    document.getElementById('btnZoomIn').addEventListener('click', () => {
      zoomAt(W / 2, H / 2, 1.25);
      drawAll();
    });
    document.getElementById('btnZoomOut').addEventListener('click', () => {
      zoomAt(W / 2, H / 2, 0.8);
      drawAll();
    });
    document.getElementById('btnResetView').addEventListener('click', () => {
      view.zoom = 1;
      view.pan.x = 0;
      view.pan.y = 0;
      drawAll();
    });
  }

  function refreshTypeFilters() {
    const box = document.getElementById('type-box');
    if (!box) return;
    // 依當前選取的 defects 產生所有類型
    const types = new Set();
    (State.selectedKeys || []).forEach((k) => {
      const arr = getDefects(k) || [];
      arr.forEach((d) => {
        const t = String(d.type ?? d.predict_code ?? '').trim();
        if (t) types.add(t);
      });
    });
    const cur = State.MapFilter.types || new Set();
    const html = [...types].sort().map((t) => {
      const ck = cur.size === 0 || cur.has(t) ? 'checked' : '';
      return `<label><input type="checkbox" class="tp" value="${t}" ${ck}>${t}</label>`;
    }).join('');
    box.innerHTML = html || '<span class="muted">（無）</span>';

    box.querySelectorAll('input.tp').forEach((cb) => {
      cb.addEventListener('change', () => {
        const set = new Set();
        box.querySelectorAll('input.tp:checked').forEach((c) => set.add(c.value));
        // 若全勾選或全不勾 -> 視為顯示全部（Set 空）
        State.MapFilter.types = set.size === types.size || set.size === 0 ? new Set() : set;
        drawAll();
      });
    });
  }

  // ---------- Zoom/Pan 互動 ----------
  function zoomAt(cx, cy, factor) {
    // 以畫面點(cx,cy)為中心縮放
    const before = toWorld(cx, cy);
    view.zoom *= factor;
    const after = toWorld(cx, cy);
    // 調整 pan 讓該世界點維持在同一畫面座標
    view.pan.x += (cx - (after.x * view.base.sx * view.zoom + view.base.tx)) -
                  (cx - (before.x * view.base.sx * (view.zoom / factor) + view.base.tx));
    view.pan.y += (cy - (after.y * view.base.sy * view.zoom + view.base.ty)) -
                  (cy - (before.y * view.base.sy * (view.zoom / factor) + view.base.ty));
  }

  cvs.addEventListener('wheel', (ev) => {
    ev.preventDefault();
    const factor = ev.deltaY < 0 ? 1.1 : 0.9;
    const rect = cvs.getBoundingClientRect();
    const cx = ev.clientX - rect.left;
    const cy = ev.clientY - rect.top;
    zoomAt(cx, cy, factor);
    drawAll();
  }, { passive: false });

  cvs.addEventListener('mousedown', (ev) => {
    const rect = cvs.getBoundingClientRect();
    const x = ev.clientX - rect.left;
    const y = ev.clientY - rect.top;
    if (ev.shiftKey) {
      boxing = true; boxStart = { x, y }; boxEnd = { x, y };
    } else {
      isPanning = true; last.x = x; last.y = y;
    }
  });
  window.addEventListener('mousemove', (ev) => {
    if (!isPanning && !boxing) return;
    const rect = cvs.getBoundingClientRect();
    const x = ev.clientX - rect.left;
    const y = ev.clientY - rect.top;
    if (isPanning) {
      view.pan.x += (x - last.x);
      view.pan.y += (y - last.y);
      last.x = x; last.y = y;
      drawAll();
    } else if (boxing) {
      boxEnd = { x, y };
      drawAll();
    }
  });
  window.addEventListener('mouseup', () => {
    if (isPanning) isPanning = false;
    if (boxing) {
      // 以框選區域作重新 fit
      const x0 = Math.min(boxStart.x, boxEnd.x);
      const y0 = Math.min(boxStart.y, boxEnd.y);
      const x1 = Math.max(boxStart.x, boxEnd.x);
      const y1 = Math.max(boxStart.y, boxEnd.y);
      const wld0 = toWorld(x0, y0);
      const wld1 = toWorld(x1, y1);
      // 更新 base 為選框
      const bounds = {
        minX: Math.min(wld0.x, wld1.x),
        maxX: Math.max(wld0.x, wld1.x),
        minY: Math.min(wld0.y, wld1.y),
        maxY: Math.max(wld0.y, wld1.y)
      };
      fitBase(bounds);
      view.zoom = 1; view.pan.x = 0; view.pan.y = 0;
      boxing = false; boxStart = boxEnd = null;
      drawAll();
    }
  });

  // ---------- Resize ----------
  function handleResize() { drawAll(); }
  window.addEventListener('resize', handleResize);

  // ---------- Bus wiring ----------
  Bus.on('selection-changed', () => {
    ensureControls();
    refreshTypeFilters();
    drawAll();
  });
  Bus.on('defect-refresh', () => {
    ensureControls();
    refreshTypeFilters();
    drawAll();
  });

  // 初始
  ensureControls();
  drawAll();
})();