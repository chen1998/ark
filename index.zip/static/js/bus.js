// 簡易事件匯流排 + 全域 State
(function () {
  const listeners = {};
  window.Bus = {
    on(evt, fn) {
      (listeners[evt] ||= []).push(fn);
    },
    emit(evt, payload) {
      (listeners[evt] || []).forEach(fn => {
        try { fn(payload); } catch (e) { console.error('[Bus]', evt, e); }
      });
    }
  };

  // 全域狀態
  window.State = window.State || {};
  State.filters = State.filters || {
    dateFrom: '', dateTo: '', glassORrecipe: '',
    matchSameGlass: true
  };
  State.selectedKeys = State.selectedKeys || []; // ["2025-09-02T08:25:45|GLASS|RID", ...]
  State.DefectCache = State.DefectCache || Object.create(null); // key -> defects[]
  State.imgBaseByKey = State.imgBaseByKey || Object.create(null); // key -> imgBase

  State.Map = State.Map || {
    panX: 0, panY: 0, scale: 1,
    box: null, boxMode: false,
    sizeFilter: new Set(['S','M','L','O']),
    typeFilter: new Set(), // 動態補
    offset: 5
  };

  window.toast = function (msg) {
    let t = document.querySelector('.toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1400);
  };
})();