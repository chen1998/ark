/* static/js/aidi/table.js  (AIDI sub table points overlay patch)
 * 規則對齊：
 * - 展開：Sub table 只顯示 allSummary 篩出的 rows；同時（可選）以 hour key 打 defects_query(output=points) 做快取。
 * - 勾選：以 per-glass keys（scantime, glass_id, recipe_id, aoi_id, line_id）打 defects_query(output=points)，
 *         取得的 defect_rows 只用於地圖疊加，不作為 Sub table 顯示來源。
 */
(function(){
  const ns = window.AIDI = window.AIDI || {};

  // ------------------ state & helpers ------------------
  ns.state = ns.state || {};
  ns.state._hourPointsCache   = ns.state._hourPointsCache   || {}; // {hourKey: points[]}
  ns.state._selectedRunKeys   = ns.state._selectedRunKeys   || {}; // {hourKey: Set(runKey)}
  ns.state._selectedRunPoints = ns.state._selectedRunPoints || {}; // {hourKey: {runKey: points[]}}

  function el(tag, attrs={}, text){
    const e = document.createElement(tag);
    for (const k in attrs){ if (attrs[k] != null) e.setAttribute(k, attrs[k]); }
    if (text!=null) e.textContent = text;
    return e;
  }
  function getHour(row){ return row.bytimehour || row.time || row.hour || ""; }
  function normHourStr(h){
    if (!h) return "";
    const t = String(h).trim();
    const m = t.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2})/);
    if (m) return `${m[1]} ${m[2]}:00`;
    return t;
  }
  function parseRows(json){
    // 兼容 {defect_rows}|{points}|{rows}
    const rows = json?.defect_rows || json?.points || json?.rows || [];
    return Array.isArray(rows) ? rows : [];
  }
  function runKeyOf(scantime, glass_id, recipe_id){
    return `${scantime}|${glass_id}|${recipe_id}`;
  }
  function updateMapOverlay(hourKey){
    const selected = ns.state._selectedRunKeys[hourKey];
    const perRun   = ns.state._selectedRunPoints[hourKey];
    const merged = [];
    if (selected && perRun){
      selected.forEach(k => {
        const pts = perRun[k];
        if (Array.isArray(pts)) merged.push(...pts);
      });
    }
    if (typeof ns.setDefectOverlay === "function"){
      ns.setDefectOverlay(merged);
    }else{
      const vp = document.getElementById("map-viewport");
      if (vp){
        vp.dispatchEvent(new CustomEvent("aidi:defect-overlay", { detail: { points: merged } }));
      }
    }
  }

  // ------------------ service adapters ------------------
  ns.api = ns.api || {};
  // 若現有 service2.js 已提供同名方法，不覆蓋
  if (!ns.api.defectsQueryPointsByHour){
    ns.api.defectsQueryPointsByHour = async function({ line_id, aoi_id, model_id, bytimehour, defect_codes }){
      const time = normHourStr(bytimehour);
      const params = new URLSearchParams({ line_id, aoi_id, model_id, time, output:"points" });
      if (Array.isArray(defect_codes) && defect_codes.length) params.append("defect_codes", defect_codes.join(","));
      const url = (ns.API_BASE || "") + "/aidi/defects_query?" + params.toString();
      const r = await fetch(url);
      if (!r.ok) throw new Error("defects_query(hour) " + r.status);
      return r.json();
    };
  }
  if (!ns.api.defectsQueryPointsByRun){
    ns.api.defectsQueryPointsByRun = async function({ scantime, glass_id, recipe_id, aoi_id, line_id, defect_codes }){
      const params = new URLSearchParams({ scantime, glass_id, recipe_id, aoi_id, line_id, output:"points" });
      if (Array.isArray(defect_codes) && defect_codes.length) params.append("defect_codes", defect_codes.join(","));
      const url = (ns.API_BASE || "") + "/aidi/defects_query?" + params.toString();
      const r = await fetch(url);
      if (!r.ok) throw new Error("defects_query(run) " + r.status);
      return r.json();
    };
  }

  // ------------------ UI builders ------------------
  function buildActionContainer(titleHost){
    const box = el("div", {
      class: "detail-actions",
      style: "margin-left:auto; display:flex; gap:8px; align-items:center;"
    });
    const btnAll = el("button", { class:"btn btn-xxs aidi-select-all" }, "全選");
    const btnClr = el("button", { class:"btn btn-xxs aidi-clear-all" }, "清空");
    box.appendChild(btnAll);
    box.appendChild(btnClr);
    titleHost.appendChild(box);
    return { btnAll, btnClr };
  }

  function renderSubTable(rows, ctx){
    // ctx: { container, hourKey, line_id, aoi_id, model_id, actions }
    const tbl = el("table", { class:"aidi-sub-table" });
    const thead = el("thead");
    const trh = el("tr");
    ["", "scantime", "glass", "recipe", "defects"].forEach(h=> trh.appendChild(el("th",{},h)));
    thead.appendChild(trh);
    const tbody = el("tbody");

    rows.forEach(r => {
      const tr = el("tr");
      const td0 = el("td");
      const cb = el("input", { type:"checkbox", class:"aidi-row-select" });
      cb.dataset.scantime = r.scantime;
      cb.dataset.glass_id = r.glass_id;
      cb.dataset.recipe_id = r.recipe_id;
      cb.dataset.aoi_id = ctx.aoi_id;
      cb.dataset.line_id = ctx.line_id;
      td0.appendChild(cb);
      tr.appendChild(td0);

      tr.appendChild(el("td",{}, r.scantime ?? ""));
      tr.appendChild(el("td",{}, r.glass_id ?? ""));
      tr.appendChild(el("td",{}, r.recipe_id ?? ""));
      tr.appendChild(el("td",{}, String(r.defect_count ?? r.defects ?? r.n ?? 0)));
      tbody.appendChild(tr);
    });

    tbl.appendChild(thead);
    tbl.appendChild(tbody);
    ctx.container.innerHTML = "";
    ctx.container.appendChild(tbl);

    // 事件：勾選單片 -> per-glass defects_query(output=points)
    tbody.addEventListener("change", async (ev)=>{
      const t = ev.target;
      if (!(t instanceof HTMLInputElement) || t.type !== "checkbox") return;
      const scantime  = t.dataset.scantime;
      const glass_id  = t.dataset.glass_id;
      const recipe_id = t.dataset.recipe_id;
      const aoi_id    = t.dataset.aoi_id;
      const line_id   = t.dataset.line_id;
      const key       = runKeyOf(scantime, glass_id, recipe_id);

      ns.state._selectedRunKeys[ctx.hourKey]   = ns.state._selectedRunKeys[ctx.hourKey]   || new Set();
      ns.state._selectedRunPoints[ctx.hourKey] = ns.state._selectedRunPoints[ctx.hourKey] || {};

      if (t.checked){
        try{
          const res = await ns.api.defectsQueryPointsByRun({ scantime, glass_id, recipe_id, aoi_id, line_id });
          const pts = parseRows(res);
          ns.state._selectedRunKeys[ctx.hourKey].add(key);
          ns.state._selectedRunPoints[ctx.hourKey][key] = pts;
        }catch(e){
          console.error("[per-glass] defects_query failed", e);
          t.checked = false;
        }
      }else{
        ns.state._selectedRunKeys[ctx.hourKey].delete(key);
        delete ns.state._selectedRunPoints[ctx.hourKey][key];
      }
      updateMapOverlay(ctx.hourKey);
    });

    // 全選 / 清空
    const actions = ctx.actions;
    if (actions){
      actions.btnAll.onclick = async ()=>{
        const boxes = Array.from(tbody.querySelectorAll('input.aidi-row-select'));
        for (const b of boxes){
          if (b.checked) continue;
          b.checked = true;
          const scantime  = b.dataset.scantime;
          const glass_id  = b.dataset.glass_id;
          const recipe_id = b.dataset.recipe_id;
          const aoi_id    = b.dataset.aoi_id;
          const line_id   = b.dataset.line_id;
          const key       = runKeyOf(scantime, glass_id, recipe_id);
          try{
            const res = await ns.api.defectsQueryPointsByRun({ scantime, glass_id, recipe_id, aoi_id, line_id });
            const pts = parseRows(res);
            ns.state._selectedRunKeys[ctx.hourKey].add(key);
            ns.state._selectedRunPoints[ctx.hourKey][key] = pts;
          }catch(e){
            console.error("[select-all] per-glass failed", key, e);
            b.checked = false;
          }
        }
        updateMapOverlay(ctx.hourKey);
      };
      actions.btnClr.onclick = ()=>{
        tbody.querySelectorAll('input.aidi-row-select:checked').forEach(b=> b.checked=false);
        ns.state._selectedRunKeys[ctx.hourKey]?.clear();
        ns.state._selectedRunPoints[ctx.hourKey] = {};
        updateMapOverlay(ctx.hourKey);
      };
    }
  }

  // ------------------ entry: expand master row ------------------
  // elements: { detailTitleEl, detailBodyEl }
  ns.renderDetailForRow = async function(row, elements){
    const line_id    = row.line_id;
    const aoi_id     = row.aoi_id;
    const model_id   = row.model_id;
    const bytimehour = getHour(row);
    const hourKey    = normHourStr(bytimehour);

    // 標題右側動作列
    const actions = buildActionContainer(elements.detailTitleEl);

    // Sub table 僅用 allSummary 篩選顯示
    const dict  = ns.state.all_summary_dict || {};
    // all_summary_dict 結構差異容錯
    let group = [];
    if (Array.isArray(dict[line_id])){
      group = dict[line_id];
    }else if (dict[line_id]){
      const v = dict[line_id];
      group = Array.isArray(v) ? v : Object.values(v).flat();
    }
    const filtered = group.filter(r =>
      String(r.aoi_id)   === String(aoi_id) &&
      String(r.model_id) === String(model_id) &&
      normHourStr(r.bytimehour || r.time || r.hour) === hourKey
    );

    renderSubTable(filtered, {
      container: elements.detailBodyEl,
      hourKey, line_id, aoi_id, model_id, actions
    });

    // （可選）展開時預取 hour 層級 points 做快取，不影響正確性
    try{
      const res = await ns.api.defectsQueryPointsByHour({ line_id, aoi_id, model_id, bytimehour });
      ns.state._hourPointsCache[hourKey] = parseRows(res);
    }catch(e){
      console.warn("[expand] hour-level points prefetch failed", e);
    }
  };

})();
