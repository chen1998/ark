(function(){
  window.AppData = window.AppData || { lineTabs: [], allRunInfo: {}, currentLine: null };

  async function fetchJSON(url){
    const res = await fetch(url, { method:'GET' });
    if(!res.ok) throw new Error(`${url} ${res.status}`);
    return res.json();
  }

  async function fetchAllRunInfo(){
    const url = `${window.API_BASE}/api/run-info`;
    return fetchJSON(url);
  }

  async function fetchRunInfoByLine(lineId, start, end){
    const u = new URL(`${window.API_BASE}/api/run-info`);
    u.searchParams.set('line_id', lineId);
    if(start) u.searchParams.set('start', start);
    if(end)   u.searchParams.set('end',   end);
    return fetchJSON(u.toString());
  }

  async function fetchDefectsByKey(key, lineId){
    const u = new URL(`${window.API_BASE}/api/defect-data`);
    u.searchParams.set('key', key);
    if(lineId) u.searchParams.set('line_id', lineId);
    const data = await fetchJSON(u.toString());
    return data;
  }

  function buildTabs(lineTabs){
    const cont = document.getElementById('all-tab-container');
    if(!cont) return;
    cont.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'tabs-row';

    lineTabs.forEach((line, i)=>{
      const btn = document.createElement('button');
      btn.className = 'tab-btn';
      btn.textContent = line;
      if(i===0) btn.classList.add('active');
      btn.addEventListener('click', async ()=>{
        row.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        AppData.currentLine = line;

        // 預設用現有 allRunInfo 的資料渲染
        const dictRows = AppData.allRunInfo[line] || {};
        Bus.emit('render-run-info', Object.values(dictRows));
      });
      row.appendChild(btn);
    });
    cont.appendChild(row);
  }

  function setInitialDatesFromPayload(payload){
    // 從 AllRunInfo 取最小/最大 scantime
    const all = [];
    const dict = payload.AllRunInfoTableData || {};
    Object.values(dict).forEach(rowsDict=>{
      Object.values(rowsDict).forEach(r=> all.push(r));
    });
    if(!all.length) return;
    const ts = all.map(r=> new Date(String(r.scantime).replace(' ','T')));
    const minD = new Date(Math.min.apply(null, ts));
    const maxD = new Date(Math.max.apply(null, ts));
    const f = (d)=> d.toISOString().slice(0,10);
    const fDateFrom = document.getElementById('fDateFrom');
    const fDateTo   = document.getElementById('fDateTo');
    if(fDateFrom) fDateFrom.value = f(minD);
    if(fDateTo)   fDateTo.value   = f(maxD);
  }

  async function init(){
    try{
      const payload = await fetchAllRunInfo();
      AppData.lineTabs = payload.AllLineTabs || [];
      AppData.allRunInfo = payload.AllRunInfoTableData || {};
      buildTabs(AppData.lineTabs);
      setInitialDatesFromPayload(payload);
      if(AppData.lineTabs.length){
        AppData.currentLine = AppData.lineTabs[0];
        const dictRows = AppData.allRunInfo[AppData.currentLine] || {};
        Bus.emit('render-run-info', Object.values(dictRows));
      }
    }catch(e){
      console.error('[api] init', e);
      toast('無法載入初始資料');
    }
  }

  // 對外：run-info 勾選後拉 defects
  Bus.on('request-defects', async (keys)=>{
    if(!keys || !keys.length) { Bus.emit('defect-refresh'); return; }
    const lineId = AppData.currentLine;
    await Promise.all(keys.map(async (k)=>{
      if(Array.isArray(State.DefectCache[k]) && State.DefectCache[k].length) return; // 已有
      try{
        const data = await fetchDefectsByKey(k, lineId);
        const rows = Array.isArray(data.defects) ? data.defects : [];
        State.DefectCache[k] = rows;
      }catch(e){
        console.error('[api] defect-data', e);
        State.DefectCache[k] = [];
      }
    }));
    // 補 Type 篩選集合（動態）
    const types = new Set(State.Map.typeFilter);
    keys.forEach(k=>{
      (State.DefectCache[k]||[]).forEach(d=>{
        const t = String(d.type ?? d.predict_code ?? '').trim();
        if(t) types.add(t);
      });
    });
    State.Map.typeFilter = types; // 初次全開
    Bus.emit('rebuild-type-filters'); // 重建 Type checkbox
    Bus.emit('defect-refresh');
  });

  // 日期套用
  document.getElementById('applyDates')?.addEventListener('click', async ()=>{
    const line = AppData.currentLine;
    if(!line) return;
    const s = document.getElementById('fDateFrom').value || '';
    const e = document.getElementById('fDateTo').value || '';
    try{
      const data = await fetchRunInfoByLine(line, s, e);
      if(data.UniRunInfoTableData){
        AppData.allRunInfo[line] = data.UniRunInfoTableData;
        Bus.emit('render-run-info', Object.values(data.UniRunInfoTableData));
      }
    }catch(err){
      console.error('[api] applyDates', err);
    }
  });

  document.getElementById('clearDates')?.addEventListener('click', async ()=>{
    const line = AppData.currentLine;
    if(!line) return;
    try{
      const data = await fetchRunInfoByLine(line, '', '');
      if(data.UniRunInfoTableData){
        AppData.allRunInfo[line] = data.UniRunInfoTableData;
        Bus.emit('render-run-info', Object.values(data.UniRunInfoTableData));
      }
    }catch(err){ console.error('[api] clearDates', err); }
  });

  document.addEventListener('DOMContentLoaded', init);
})();
