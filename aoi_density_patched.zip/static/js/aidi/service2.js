// AIDI 服務：修正 API 路徑（帶 /api 前綴）
(function(){
  const ns = window.AIDI = window.AIDI || {};
  const API = `${window.API_BASE}/aoi_density/api`;

  ns.fetchAIDIData = async function(params={}){
    const usp = new URLSearchParams({ days:'7', reload:'false', ...params });
    const r = await fetch(`${API}/?${usp.toString()}`);
    if(!r.ok){ throw new Error(`${API} /hourly 失敗`); }
    return r.json();
  };

  ns.fetchHourlyPoints = async function({ time, line_id, aoi_id, model_id, defect_codes=[], sizes=[] }){
    const usp = new URLSearchParams({ time, line_id, aoi_id, model_id, output: 'points' });
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    if (sizes.length) usp.set('sizes', sizes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(points)`);
    return r.json();
  };

  ns.fetchRunsUnderHourGroup = async function({ time, line_id, aoi_id, model_id, defect_codes=[] }){
    const usp = new URLSearchParams({ time, line_id, aoi_id, model_id, output:'runs' });
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(runs)`);
    return r.json();
  };

  ns.fetchPointsByRun = async function({ scantime, glass_id, recipe_id, aoi_id, line_id=null, defect_codes=[], sizes=[] }){
    const usp = new URLSearchParams({ scantime, glass_id, recipe_id, aoi_id, output:'points' });
    if (line_id) usp.set('line_id', line_id);
    if (defect_codes.length) usp.set('defect_codes', defect_codes.join(','));
    if (sizes.length) usp.set('sizes', sizes.join(','));
    const r = await fetch(`${API}/defects_query?${usp.toString()}`);
    if (!r.ok) throw new Error(`${API}/defects_query 失敗(points-run)`);
    return r.json();
  };
})();

/*
點擊展開btn後顯示在sub table上的資料是篩選allSummary的資料顯示 + 取得童該筆資料一樣的
line_id, aoi_id, bytimehour, model_id
回傳的defect_rows是要話point的不是要顯示在sub table的
勾選sub table才是傳遞scantime, glass_id, recipe_id, aoi_id, line_id,回傳的defect_rows還是用來畫座標點的
*/