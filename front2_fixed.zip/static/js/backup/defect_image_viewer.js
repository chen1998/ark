// static/js/defect_image_viewer.js
(function(){
  const imgA=document.getElementById('imgA');
  const imgB=document.getElementById('imgB');
  function render(){
    const [kA,kB]=State.selectedKeys;
    if(imgA){ const url= kA ? LR.imageForKey(kA) : null; imgA.src = url || 'https://placehold.co/600x360?text=No+Image+A'; }
    if(imgB){ const url= kB ? LR.imageForKey(kB) : null; imgB.src = url || 'https://placehold.co/600x360?text=No+Image+B'; }
  }
  document.querySelectorAll('.img-reset').forEach(btn=> btn.addEventListener('click', render));
  Bus.on('init-data', render);
  Bus.on('compare-selection-changed', render);
})();