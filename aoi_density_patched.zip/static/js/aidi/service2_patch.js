/* static/js/aidi/service2_patch.js (optional)
 * 只有在你的 service2.js 沒有 defectsQueryPointsByHour/Run 兩個方法時才需要載入。
 */
(function(){
  const ns = window.AIDI = window.AIDI || {};
  ns.api = ns.api || {};
  // 這裡留空，主要實作已在 table.js 內部提供同名方法（會檢查存在才定義）。
})();
