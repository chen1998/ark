// run_info_table.js — 渲染 Run Info 表格（多選）
(function(){
  const theadCols = [
    {text:'選'},
    {text:'時間', key:'scantime'},
    {text:'Recipe', key:'recipe_id'},
    {text:'Glass', key:'glass_id'},
    {text:'Model', key:'model'},
    {text:'Chips', key:'chips'},
    {text:'S', key:'small_defect_count'},
    {text:'M', key:'middle_defect_count'},
    {text:'L', key:'large_defect_count'},
    {text:'O', key:'over_defect_count'},
    {text:'總', key:'defect_count'}
  ];

  function passFilters(rows){
    const q = (State.filters.glassORrecipe || '').toLowerCase();
    if(!q) return rows;
    return rows.filter(r => String(r.glass_id||'').toLowerCase().includes(q) || String(r.recipe_id||'').toLowerCase().includes(q));
  }

  function renderHead(thead){
    thead.innerHTML = '';
    const tr = document.createElement('tr');
    theadCols.forEach(c=>{
      const th = document.createElement('th');
      th.textContent = c.text;
      tr.appendChild(th);
    });
    thead.appendChild(tr);
  }

  function renderBody(tbody, rows){
    tbody.innerHTML = '';
    rows.forEach((r)=>{
      const tr = document.createElement('tr');
      const key = Utils.keyFromRow(r);
      tr.dataset.key = key;

      // 欄位缺陷小計可能包在 defect_summary 中（後端給的格式），若沒有就直接使用平面欄位
      const ds = r.defect_summary || {};
      const s = +(r.small_defect_count ?? ds.small_defect_count ?? 0);
      const m = +(r.middle_defect_count ?? ds.middle_defect_count ?? 0);
      const l = +(r.large_defect_count  ?? ds.large_defect_count  ?? 0);
      const o = +(r.over_defect_count   ?? ds.over_defect_count   ?? 0);
      const total = +(r.defect_count     ?? ds.defect_count        ?? (s+m+l+o));

      if(State.selectedKeys.includes(key)) tr.classList.add('selected');

      // checkbox
      const tdSel = document.createElement('td');
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.className = 'sel';
      cb.checked = State.selectedKeys.includes(key);
      tdSel.appendChild(cb);
      tr.appendChild(tdSel);

      const cols = [
        r.scantime, r.recipe_id, r.glass_id, r.model, r.chips, s, m, l, o, total
      ];

      cols.forEach(val=>{
        const td = document.createElement('td');
        td.textContent = (val==null?'':val);
        tr.appendChild(td);
      });

      function toggle(checked){
        const exists = State.selectedKeys.includes(key);
        if(checked && !exists){
          State.selectedKeys.push(key);
        }else if(!checked && exists){
          State.selectedKeys = State.selectedKeys.filter(k=>k!==key);
        }
        // 更新選取數
        document.getElementById('sel-count').textContent = String(State.selectedKeys.length||0);
        tr.classList.toggle('selected', checked);
        // 請缺陷資料 + 通知地圖
        Bus.emit('request-defects', State.selectedKeys.slice());
        Bus.emit('selection-changed', State.selectedKeys.slice());
      }

      tr.addEventListener('click', (ev)=>{
        if(ev.target && ev.target.classList.contains('sel')) return;
        cb.checked = !cb.checked; toggle(cb.checked);
      });
      cb.addEventListener('change', ()=> toggle(cb.checked));

      tbody.appendChild(tr);
    });
    // 更新筆數
    const el = document.querySelector('#run-stats .badge b');
    if(el) el.textContent = String(rows.length);
  }

  function render(rows){
    const cont  = document.getElementById('run-info-table-container');
    if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-info-tbody');
    renderHead(thead);
    renderBody(tbody, passFilters(rows));
  }

  Bus.on('render-run-info', (rows)=> render(rows||[]));
  Bus.on('filters-changed', ()=>{
    // 重新抓當前 line 的 rows
    const rows = State.AllRunInfo[State.currentLine] || [];
    const tbody = document.querySelector('#run-info-tbody');
    if(tbody){
      tbody.innerHTML = '';
      render(rows);
    }
  });

  // 清除選取
  document.getElementById('btnClearSel').addEventListener('click', ()=>{
    State.selectedKeys = [];
    document.getElementById('sel-count').textContent = '0';
    Bus.emit('selection-changed', []);
    // 取消打勾 UI
    document.querySelectorAll('#run-info-tbody input.sel').forEach(cb => cb.checked = false);
    document.querySelectorAll('#run-info-tbody tr').forEach(tr => tr.classList.remove('selected'));
  });
})();
