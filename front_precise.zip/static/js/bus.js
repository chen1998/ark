// bus.js — 簡易事件匯流排 + 全域 State
(function () {
  const listeners = {};
  window.Bus = {
    on(evt, fn) { (listeners[evt] ||= []).push(fn); },
    emit(evt, payload) { (listeners[evt] || []).forEach(fn => { try{ fn(payload); }catch(e){ console.error('[Bus]', evt, e);} }); }
  };

  // 全域 State
  window.State = window.State || {};
  State.filters = State.filters || { dateFrom: '', dateTo: '', glassORrecipe: '' };
  State.selectedKeys = State.selectedKeys || []; // ['time|glass|recipe']
  State.currentLine = State.currentLine || null;
  State.AllRunInfo = State.AllRunInfo || {};     // { line: [rows] }
  State.LineTabs = State.LineTabs || [];
  State.DefectCache = State.DefectCache || {};   // key -> defects[]
  State.imgBaseByKey = State.imgBaseByKey || {}; // key -> img base
  State.ColorForKey = State.ColorForKey || {};   // key -> color
  State.Map = State.Map || { scale:1, ox:0, oy:0, boxZoom:false };
  State.TypeFilter = new Set(['1','!','A','B','C']);
  State.SizeFilter = new Set(['S','M','L','O']);

  window.toast = function (msg) {
    let t = document.querySelector('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'), 1300);
  };
})();
