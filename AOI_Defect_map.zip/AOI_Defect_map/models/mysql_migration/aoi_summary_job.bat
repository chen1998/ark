@echo off
cd /d D:\A0_Project\AOI_Defect_map\models\mysql_migration
call ..\..\..\.venv\Scripts\activate
python aoi_summary_job.py
pause