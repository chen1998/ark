from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, Dict
#from models.oracle_dbhander import or
router = APIRouter()

# 假資料
lot_info_dict = {...}
lot_defect_dict = {...}
lot_chip_dict = {...}
lot_chip_defct = {...}

# 請求 run info 資料 模型
class RunInfoRequest(BaseModel):
    lot_id: Optional[str] = ""
    date: Optional[str] = ""
    ask: Optional[str] = ""
    ask_info: Optional[Dict[str, str]] = {}

@router.post("/run_info_api")
async def get_run_info(request: RunInfoRequest):
    # 根據 request.lot_id 等去篩選資料
    print(f" Received: lot_id={request.lot_id}, date={request.date}, ask_info={request.ask_info}")

    return JSONResponse(
        content={
            "lot_info_dict": lot_info_dict,
            "lot_defect_dict": lot_defect_dict
        }
    )


# 請求 defect相關資料 模型
class DefectRequest(BaseModel):
    lot_id: Optional[str] = ""
    date: Optional[str] = ""
    ask: Optional[str] = ""
    ask_info: Optional[Dict[str, str]] = {}

@router.post("/defect_data_api")
async def get_defect_data(request: DefectRequest):
    return JSONResponse(
        content={
            "lot_chip_dict": lot_chip_dict,
            "lot_chip_defct": lot_chip_defct
        }
    )