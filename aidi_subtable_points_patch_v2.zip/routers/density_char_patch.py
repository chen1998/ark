# routers/density_char_patch.py  (optional example)
# 若你現有的 density_char.py 已支援這兩種 query 形態，則不必使用這個範例。
from fastapi import APIRouter, Query
from typing import Optional, List, Dict, Any

router = APIRouter()

@router.get("/aidi/defects_query")
def defects_query(
    line_id: Optional[str] = None,
    aoi_id: Optional[str] = None,
    model_id: Optional[str] = None,
    time: Optional[str] = Query(None, description="YYYY-MM-DD HH:00 for hour bucket"),
    scantime: Optional[str] = None,
    glass_id: Optional[str] = None,
    recipe_id: Optional[str] = None,
    output: str = "points",
    defect_codes: Optional[str] = None
):
    # NOTE: 下方為示意，請依你原有 DB/邏輯改寫
    # 模式 A：hour 層級 points（展開時可預取）
    if time and line_id and aoi_id and model_id and output == "points":
      # TODO: query your storage by hour bucket -> list of points
      # points 欄位至少要含 run keys (scantime/glass_id/recipe_id) 與 (x,y)
      return {
        "defect_rows": [
          # {"scantime": "...", "glass_id": "...", "recipe_id": "...", "x": 100, "y": 200, "code": "D01", "size": 2.5},
        ]
      }

    # 模式 B：per-glass points（勾選時）
    if scantime and glass_id and recipe_id and aoi_id and line_id and output == "points":
      # TODO: query by exact run keys -> list of points
      return {
        "defect_rows": [
          # {"scantime": scantime, "glass_id": glass_id, "recipe_id": recipe_id, "x": 101, "y": 205}
        ]
      }

    # 其他模式：可依需求返回 runs 等
    return {"defect_rows": []}
