(function(){
  const ns = window.AIDI;

  ns.ensureInit = async function(){
    if(ns.state.inited) return;
    await ns.ensureD3();

    const root = ns.qs('#aidi-root'); if(root){ root.style.display=''; root.style.gridColumn='1 / -1'; }

    const payload = await ns.fetchAIDIData();
    ns.state.full = payload || { series:[], filters:{}, time_bins:[] };

    ns.buildFilterWidgets();
    ns.fillDateFromBins();
    ns.renderTopTabs();

    ns.qs('#aidiApply')?.addEventListener('click', ()=>{
      ns.renderCharts(); ns.renderTable();
      // AIDI -> AOI
      window.Bus?.emit('aidi:filter', ns.collectCurrentFilter());
    });

    ns.qs('#aidiClear')?.addEventListener('click', ()=>{
      Object.values(ns.state.mdd).forEach(inst => inst && inst.clear());
      ns.fillDateFromBins();
      ns.renderCharts(); ns.renderTable();
      // AIDI -> AOI（清空）
      window.Bus?.emit('aidi:filter', ns.collectCurrentFilter());
    });

    ns.state.inited = true;
    ns.renderCharts(); ns.renderTable();
  };

  ns.show = function(){
    ns.ensureInit();
    ['#defect-map-section', '#run-info-block', '#defect-lists', '#defect-gallery'].forEach(id=>{
      const x = ns.qs(id); if (x) x.style.display='none';
    });
    ns.qs('#aidi-root')?.style && (ns.qs('#aidi-root').style.display='');

    // 顯示 AIDI 畫面時，同步一次現有條件（避免 AOI 還停在舊狀態）
    window.Bus?.emit('aidi:filter', ns.collectCurrentFilter());
  };

  ns.hide = function(){
    const holder = ns.qs('#all-tab-container');
    if (holder && ns.state.tabsCacheHTML!=null) holder.innerHTML = ns.state.tabsCacheHTML;
    ['#defect-map-section', '#run-info-block', '#defect-lists', '#defect-gallery'].forEach(id=>{
      const x = ns.qs(id); if (x) x.style.display='';
    });
    ns.qs('#aidi-root')?.style && (ns.qs('#aidi-root').style.display='none');
  };

  function bindSystemTabs(){
    ns.qsa('.sys-tab').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        ns.qsa('.sys-tab').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const view = btn.getAttribute('data-view');
        if (view==='aidi') ns.show(); else ns.hide();
      });
    });
  }

  document.addEventListener('DOMContentLoaded', bindSystemTabs);
})();