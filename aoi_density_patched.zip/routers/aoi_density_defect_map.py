from fastapi import APIRouter, Query
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from collections import defaultdict
import pandas as pd
import json
import re
from models.sql_db_connect import MySQLConnet
router = APIRouter()

class Config:
    def __init__(self):
        # ================================================= datetime =================================================
        now = datetime.now()
        ym = now.strftime("%Y%m")
        print(f"連線時間: {now}({ym})")
        one_mon_ago = now - timedelta(days=30)
        # ================================================= 資料設定  =================================================
        # === PI Line & AOI Tool  ====
        self.uni_aoi_names = [f'aoi{i}00' for i in range(1,4,1)]
        self.uni_pi_names = [f'pi{i}00' for i in range(1,8,1)]
        # === particle type & defect code ====
        self.uni_UPI_defect_codes = ['Polymer', 'SSIU_Polymer']
        self.uni_SPOT_defect_codes = ['PI_Spot_NP', 'PIS With Particle']
        self.uni_defect_types = ['Particle', 'PISpot']
        # ==== defect size config  ===
        self.uni_defect_sizes = ['S', 'M', 'L', 'O']
        self.rawdata_defect_size_col = 'defect_size'
        self.defect_size_rules = {
            "S": lambda x: x <= 20,
            "M": lambda x: 21 <= x <= 100,
            "L": lambda x: 101 <= x <= 400,
            "O": lambda x: x >= 401,
        }
        # === Glass side  ===
        self.glass_sides = ['CF', 'TFT']

        # =================================================  UPI/SPOT Default config  ================================================= 
        self.tab_filter_config = {
            'Particle': {'defect_code': self.uni_UPI_defect_codes,
                         'defect_size': self.uni_defect_sizes
                         },
            'PISpot': {'defect_code': self.uni_SPOT_defect_codes,
                       'defect_size': self.uni_defect_sizes[-2:]
                       }
        }
        # ================================================= MySQL AOI Density 資料表設定 ================================================= 
        self.aoi_pidensit_summary_tbn = f'pidensity_{ym}'
        self.aoi_pi_density_tbns = [f'{aoi}_pidensity_yyyymm_{pi}' for aoi in self.uni_aoi_names for pi in self.uni_pi_names]
        self.aoi_pidensity_spec_tbn = 'aoi_spec_for_aoimonitor'
        print('預設讀取:',self.aoi_pidensit_summary_tbn)


        self.aoi_pidensity_spec_cols = ['NO', 'MODEL_ID', 'MODEL_TYPE', 'DEFECT_CODE', 'PROCESS_TYPE', 'SIZE_TYPE', 'OOC', 'OOS']
        self.aoi_density_summary_sql_cols = ['pi_hour', 'aoi', 'pi', 'line_id', 'model', 'glass_type', 'recipe_id','defect_type', 'ai_code_1', 
                                             'n_rows', 'n_glasses', 'small_defect_count','middle_defect_count', 'large_defect_count', 'over_defect_count',
                                             'unknown_defect_count', 'glass']
        
        self.aoi_density_rawdata_sql_cols = ['scan_time', 'line_id', 'model', 'glass_type', 'recipe_id', 'glass_id',
       'pic_name', 'x', 'y', 'predict_code', 'judge_code', 'mark', 'hour','dayhour', 'day', 'year', 'month', 'season', 'week', 'yearmonth',
       'defect_count', 'defect_size', 'open_status', 'ai_code_1', 'ai_code_2','ai_code_3', 'ai_code_4', 'ai_code_5', 'gray_name', 'ip_num',
       'first_code', 'chip_name', 'defect_seq']
        
        self.sql_group_keys = ['line_id', 'aoi', 'model', 'glass_type', 'recipe_id','defect_type', 'ai_code_1','pi_hour'  ]
        
        # ================================================= 前端網頁CONFIG ================================================= 
        self.chart_table_coldict = {
                                    'line_id': 'PI Line',
                                    'model': 'Model', 
                                    'glass_type': 'glass_side',
                                    'pi_hour': 'Hourly',
                                    'n_glasses': 'Hourly Defect count', 
                                    'adc_def_code': 'defect code', 
                                    'glass_id': 'glass', #list ,group中的所有glass
                                    'glass_defect_count': 'glass_defect_count'} #dict, group中的所有glass_id對應單片glass defect
                                
                                                
        self.chart_group_dict = {
            'out':['line_id','aoi', 'pi_hour'],
            'mid': ['model', 'ai_code_1'] ,
            'in':['n_glasses', 'density']}
        
        self.uni_glass_row_info_dict = {'glass_id': 'glass', 
                                        'glass_defect_count':'glass_defect_count',  
                                        'small_defect_count': 'S',
                                        'middle_defect_count': 'M', 
                                        'large_defect_count': 'L', 
                                        'over_defect_count': 'O'}
        self.defect_group_coldict = {
            'x': 'x',
            'y': 'y',
            'chip_name': 'chip',
            'pic_name':'img'}
        
        self.front_config = {
            'chartKeyDict': self.chart_group_dict,
            'hourlyTable': self.chart_table_coldict,
            'uniGlassInfo': self.uni_glass_row_info_dict,
            'uniGlassDefectTable': self.defect_group_coldict
        }

# -------- 小工具 --------
def _parse_dt(s: str) -> datetime:
    s = s.strip().replace("T", " ")
    fmts = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"]
    for f in fmts:
        try:
            return datetime.strptime(s, f)
        except ValueError:
            continue
    raise ValueError(f"Bad datetime: {s}")

def _month_span(start: datetime, end: datetime) -> List[str]:
    ym = []
    cur = datetime(start.year, start.month, 1)
    last = datetime(end.year, end.month, 1)
    while cur <= last:
        ym.append(cur.strftime("%Y%m"))
        # 下一個月
        nxt = (cur.replace(day=28) + timedelta(days=4)).replace(day=1)
        cur = nxt
    return ym

def _try_get_table(dbhandler, tbn: str) -> Optional[pd.DataFrame]:
    try:
        df = dbhandler.get_table(tbn)
        if df is not None and len(df) > 0:
            return df
    except Exception:
        pass
    # 試試大寫
    try:
        df = dbhandler.get_table(tbn.upper())
        if df is not None and len(df) > 0:
            return df
    except Exception:
        pass
    return None

def _apply_filters(df: pd.DataFrame, filters: Dict[str, List[str]]) -> pd.DataFrame:
    if df.empty or not filters:
        return df

    df2 = df.copy()

    # 通用等值過濾
    for key in ["line_id", "aoi", "model", "glass_type", "ai_code_1", "pi", "recipe_id", "defect_type"]:
        if key in filters and filters[key]:
            if key in df2.columns:
                df2 = df2[df2[key].isin(filters[key])]

    # pi_hour：支援 小時 等值 / 日期整天 / 區間(~、|、,)
    if "pi_hour" in filters and filters["pi_hour"]:
        df2["pi_hour"] = pd.to_datetime(df2["pi_hour"])
        parts = []
        for raw in filters["pi_hour"]:
            if not isinstance(raw, str) or not raw.strip():
                continue
            s = raw.strip()
            # 區間
            if any(sep in s for sep in ("~", "|", ",")):
                for sep in ("~", "|", ","):
                    if sep in s:
                        a, b = [x.strip() for x in s.split(sep, 1)]
                        break
                start = _parse_dt(a)
                end   = _parse_dt(b)
                if end < start:
                    start, end = end, start
                # 區間含當小時
                m = (df2["pi_hour"] >= start) & (df2["pi_hour"] <= end)
                parts.append(m)
            else:
                # 單點：日期或小時
                dt = _parse_dt(s)
                if len(s) <= 10:  # 只有 YYYY-MM-DD
                    day0 = datetime(dt.year, dt.month, dt.day)
                    day1 = day0 + timedelta(days=1) - timedelta(seconds=1)
                    m = (df2["pi_hour"] >= day0) & (df2["pi_hour"] <= day1)
                else:
                    m = (df2["pi_hour"] == dt)
                parts.append(m)
        if parts:
            mask = parts[0]
            for m in parts[1:]:
                mask = mask | m
            df2 = df2[mask]

    # glass_id：聚合字串包含任一
    if "glass_id" in filters and filters["glass_id"] and "glass" in df2.columns:
        wanted = set([s.strip() for s in filters["glass_id"] if s and isinstance(s, str)])
        if wanted:
            def has_any_glass(cell: Any) -> bool:
                if pd.isna(cell) or not str(cell).strip():
                    return False
                items = [x.strip() for x in str(cell).split(",") if x.strip()]
                return bool(set(items) & wanted)
            df2 = df2[df2["glass"].apply(has_any_glass)]

    # defect_size：S/M/L/O 任何一種 >0
    if "defect_size" in filters and filters["defect_size"]:
        m = {"S": "small_defect_count", "M": "middle_defect_count",
             "L": "large_defect_count", "O": "over_defect_count"}
        cols = [m[s] for s in filters["defect_size"] if s in m and m[s] in df2.columns]
        if cols:
            df2 = df2[df2[cols].fillna(0).sum(axis=1) > 0]

    return df2

def _sorted_unique_glasses(glass_cell: Any) -> List[str]:
    if pd.isna(glass_cell) or not str(glass_cell).strip():
        return []
    items = [x.strip() for x in str(glass_cell).split(",") if x.strip()]
    return sorted(set(items))

def _build_chart_dict(df: pd.DataFrame) -> Dict[str, Any]:
    """
    結構：
    chart[line_id][aoi][model][glass_type][ai_code_1][pi_hour_str] = {
        'defect_type': ..,
        'n_rows': ..,
        'n_glasses': ..,       # 以 glass 去重後的計數
        'small_defect_count': ...,
        'middle_defect_count': ...,
        'large_defect_count': ...,
        'over_defect_count': ...,
        'unknown_defect_count': ...,
        'glass': 'g1,g2,...'   # 去重後排序串接
    }
    * 若同一分群同一 pi_hour 有多列（例如不同 recipe_id），自動合併數值並 glass 取聯集。
    """
    if df.empty:
        return {}

    # 確保型別
    work = df.copy()
    work["pi_hour"] = pd.to_datetime(work["pi_hour"])
    for c in ["n_rows", "small_defect_count", "middle_defect_count", "large_defect_count",
              "over_defect_count", "unknown_defect_count"]:
        if c in work.columns:
            work[c] = pd.to_numeric(work[c], errors="coerce").fillna(0).astype(int)
    # 準備容器
    chart: Dict[str, Any] = {}

    # 我們把 recipe 維度併掉（你要的巢狀鍵不包含 recipe_id）
    key_cols = ["line_id", "aoi", "model", "glass_type", "ai_code_1", "defect_type", "pi_hour"]

    # 逐列累加
    for _, r in work.iterrows():
        line_id = r.get("line_id", "")
        aoi     = r.get("aoi", "")
        model   = r.get("model", "")
        gside   = r.get("glass_type", "")
        code    = r.get("ai_code_1", "") or ""
        dtype   = r.get("defect_type", "") or ""
        ts      = r["pi_hour"]
        ts_key  = ts.strftime("%Y-%m-%d %H:%M:%S")

        glist = _sorted_unique_glasses(r.get("glass", ""))

        # 取到節點
        d1 = chart.setdefault(line_id, {})
        d2 = d1.setdefault(aoi, {})
        d3 = d2.setdefault(model, {})
        d4 = d3.setdefault(gside, {})
        d5 = d4.setdefault(code, {})

        node = d5.get(ts_key)
        if node is None:
            d5[ts_key] = {
                "defect_type": dtype,
                "n_rows": int(r.get("n_rows", 0)),
                "n_glasses": len(glist),  # 先用當列的，後面合併會更新
                "small_defect_count": int(r.get("small_defect_count", 0)),
                "middle_defect_count": int(r.get("middle_defect_count", 0)),
                "large_defect_count": int(r.get("large_defect_count", 0)),
                "over_defect_count": int(r.get("over_defect_count", 0)),
                "unknown_defect_count": int(r.get("unknown_defect_count", 0)),
                "_glass_set": set(glist),   # 內部用，最後會轉字串
            }
        else:
            node["n_rows"] += int(r.get("n_rows", 0))
            node["small_defect_count"]  += int(r.get("small_defect_count", 0))
            node["middle_defect_count"] += int(r.get("middle_defect_count", 0))
            node["large_defect_count"]  += int(r.get("large_defect_count", 0))
            node["over_defect_count"]   += int(r.get("over_defect_count", 0))
            node["unknown_defect_count"]+= int(r.get("unknown_defect_count", 0))
            node["_glass_set"].update(glist)

    # 收尾：把 _glass_set 轉為 glass 串、並更新 n_glasses
    def _finalize(d: Any):
        if isinstance(d, dict):
            keys = list(d.keys())
            for k in keys:
                v = d[k]
                if isinstance(v, dict) and "_glass_set" in v:
                    gset = v.pop("_glass_set")
                    glass_list = sorted(gset)
                    d[k]["glass"] = ",".join(glass_list)
                    d[k]["n_glasses"] = len(glass_list)
                else:
                    _finalize(v)
    _finalize(chart)
    return chart



# ===== defect map helpers =====
def _hour_bounds(ht: datetime) -> (datetime, datetime):
    start = datetime(ht.year, ht.month, ht.day, ht.hour, 0, 0)
    end = start + timedelta(hours=1)
    return start, end

def _size_bucket(v) -> Optional[str]:
    try:
        x = int(v)
    except Exception:
        return None
    if x >= 401: return "O"
    if 101 <= x <= 400: return "L"
    if 21  <= x <= 100: return "M"
    if x <= 20: return "S"
    return None

def _filter_raw_for_group(raw: pd.DataFrame, row: Dict[str, Any],
                          glass_ids: List[str],
                          size_wanted: Optional[List[str]] = None) -> pd.DataFrame:
    if raw is None or raw.empty:
        return raw.iloc[0:0]

    r = row
    # 標準欄位準備
    raw = raw.copy()
    if "scan_time" in raw.columns:
        raw["scan_time"] = pd.to_datetime(raw["scan_time"], errors="coerce")
        raw["pi_hour_calc"] = raw["scan_time"].dt.floor("H")
    elif "dayhour" in raw.columns:
        # 允許 'YYYY-MM-DD HH' 或 'YYYY-MM-DD HH:00:00'
        raw["pi_hour_calc"] = pd.to_datetime(raw["dayhour"].astype(str).str.replace(r"(\d{4}-\d{2}-\d{2}\s\d{2})(?!:)", r"\1:00:00", regex=True),
                                             errors="coerce")
    elif {"day","hour"}.issubset(set(raw.columns)):
        raw["pi_hour_calc"] = pd.to_datetime(raw["day"].astype(str) + " " + raw["hour"].astype(str).str.zfill(2) + ":00:00",
                                             errors="coerce")
    else:
        raw["pi_hour_calc"] = pd.NaT

    # 各式條件
    pi_hour = pd.to_datetime(r["pi_hour"])
    aoi = str(r["aoi"]).upper()
    line_id = r["line_id"]
    model = r["model"]
    gside = r["glass_type"]
    recipe_pref = str(r["recipe_id"])
    ai1 = (r.get("ai_code_1") or "").strip()

    # 比對欄位
    mask = pd.Series(True, index=raw.index)
    if "line_id" in raw:    mask &= (raw["line_id"] == line_id)
    if "model" in raw:      mask &= (raw["model"] == model)
    if "glass_type" in raw: mask &= (raw["glass_type"] == gside)

    # recipe_id prefix 比對（LEFT(recipe_id, len)==prefix）
    if "recipe_id" in raw:
        mask &= raw["recipe_id"].astype(str).str[:len(recipe_pref)] == recipe_pref

    # ai_code_1 清理比對
    if "ai_code_1" in raw:
        raw["_ai1"] = raw["ai_code_1"].fillna("").astype(str).str.strip()
        mask &= (raw["_ai1"] == ai1)

    # 小時比對
    mask &= (raw["pi_hour_calc"] == pi_hour)

    # glass 限定
    if "glass_id" in raw:
        mask &= raw["glass_id"].astype(str).isin(glass_ids)

    out = raw[mask].copy()

    # defect_size 過濾（S/M/L/O）
    if size_wanted:
        out["_bucket"] = out["defect_size"].apply(_size_bucket)
        out = out[out["_bucket"].isin(size_wanted)]

    return out

@router.get("/api/defect_map")
async def defect_map(
    filter_ask_keys: Optional[str] = Query(None, description="JSON 物件字串：{'line_id': [...], 'aoi': [...], 'model': [...], 'glass_type': [...], 'ai_code_1': [...], 'glass_id': [...], 'defect_size': ['S','M','L','O'], 'pi_hour': [...]}")
):
    cfg = Config()
    dbhandler = MySQLConnet('l6a01_project')

    # 解析 filters
    try:
        filters: Dict[str, List[str]] = json.loads(filter_ask_keys) if filter_ask_keys else {}
        if not isinstance(filters, dict):
            filters = {}
    except Exception:
        filters = {}

    # 依 pi_hour 決定要載入哪些月份的 summary 表；若沒給就用當月
    months: List[str] = []
    if "pi_hour" in filters and filters["pi_hour"]:
        # 找到最小與最大的時間以覆蓋跨月
        mins, maxs = [], []
        for s in filters["pi_hour"]:
            if not isinstance(s, str) or not s.strip():
                continue
            if any(sep in s for sep in ("~", "|", ",")):
                for sep in ("~", "|", ","):
                    if sep in s:
                        a, b = [x.strip() for x in s.split(sep, 1)]
                        break
                mins.append(_parse_dt(a)); maxs.append(_parse_dt(b))
            else:
                dt = _parse_dt(s)
                if len(s.strip()) <= 10:  # 只有日期
                    day0 = datetime(dt.year, dt.month, dt.day)
                    day1 = day0 + timedelta(days=1) - timedelta(seconds=1)
                    mins.append(day0); maxs.append(day1)
                else:
                    mins.append(dt);  maxs.append(dt)
        if mins and maxs:
            start, end = min(mins), max(maxs)
            months = _month_span(start, end)

    if not months:
        now = datetime.now()
        months = [now.strftime("%Y%m")]

    # 載入 summary（合併跨月）
    frames: List[pd.DataFrame] = []
    for ym in months:
        tbn = f"pidensity_{ym}"
        df = _try_get_table(dbhandler, tbn)
        if df is None or df.empty:
            continue
        keep_cols = [c for c in cfg.aoi_density_summary_sql_cols if c in df.columns]
        df = df[keep_cols].copy()
        df["pi_hour"] = pd.to_datetime(df["pi_hour"])
        frames.append(df)

    if frames:
        df_all = pd.concat(frames, ignore_index=True)
    else:
        return {"DefectGroupDict": {}, "ParamDict": cfg.front_config}

    # 先用 filters 過 summary
    df_filtered = _apply_filters(df_all, filters)

    if df_filtered.empty:
        return {"DefectGroupDict": {}, "ParamDict": cfg.front_config}

    # 解析欲保留的 defect_size（用在 raw 過濾）
    size_wanted = None
    if "defect_size" in filters and filters["defect_size"]:
        allow = {"S", "M", "L", "O"}
        size_wanted = [s for s in filters["defect_size"] if s in allow]
        if not size_wanted:
            size_wanted = None

    # 讀 raw 表快取
    raw_cache: Dict[str, pd.DataFrame] = {}

    def _get_raw(aoi: str, pi: str, ym: str) -> Optional[pd.DataFrame]:
        tname = f"{aoi.lower()}_pidensity_{ym}_{pi.lower()}"
        if tname not in raw_cache:
            raw_cache[tname] = _try_get_table(dbhandler, tname) or pd.DataFrame()
        return raw_cache[tname]

    # 輸出結構：line_id → aoi → model → glass_type → ai_code_1 → pi_hour → { ... }
    result: Dict[str, Any] = {}

    for _, r in df_filtered.iterrows():
        pi_hour = pd.to_datetime(r["pi_hour"])
        ym = pi_hour.strftime("%Y%m")
        aoi = str(r["aoi"]).upper()
        pi  = str(r["pi"]).upper()

        raw = _get_raw(aoi, pi, ym)
        if raw is None or raw.empty:
            # 試試大寫表名（避免大小寫差異）
            tname2 = f"{aoi}_pidensity_{ym}_{pi}"
            if tname2 not in raw_cache:
                raw_cache[tname2] = _try_get_table(dbhandler, tname2) or pd.DataFrame()
            raw = raw_cache[tname2]
            if raw is None or raw.empty:
                continue

        glass_ids = _sorted_unique_glasses(r.get("glass", ""))

        sub = _filter_raw_for_group(raw, r, glass_ids, size_wanted=size_wanted)
        if sub.empty:
            continue

        # 分 glass 統計 + 缺陷點位
        sub["_bucket"] = sub["defect_size"].apply(_size_bucket)
        by_glass = {}
        for gid, gdf in sub.groupby(sub["glass_id"].astype(str)):
            s = int((gdf["_bucket"] == "S").sum())
            m = int((gdf["_bucket"] == "M").sum())
            l = int((gdf["_bucket"] == "L").sum())
            o = int((gdf["_bucket"] == "O").sum())
            rows = gdf[["x", "y", "chip_name", "pic_name", "defect_size"]].fillna("").to_dict(orient="records")
            by_glass[gid] = {
                "glass_id": gid,
                "glass_defect_count": len(gdf),
                "small_defect_count": s,
                "middle_defect_count": m,
                "large_defect_count": l,
                "over_defect_count": o,
                "rows": rows
            }

        # 塞入巢狀結構
        line_id = r["line_id"]; model = r["model"]; gside = r["glass_type"]
        code    = (r.get("ai_code_1") or "").strip()
        dtype   = (r.get("defect_type") or "").strip()
        ts_key  = pi_hour.strftime("%Y-%m-%d %H:%M:%S")

        d1 = result.setdefault(line_id, {})
        d2 = d1.setdefault(aoi, {})
        d3 = d2.setdefault(model, {})
        d4 = d3.setdefault(gside, {})
        d5 = d4.setdefault(code, {})
        d6 = d5.setdefault(ts_key, {"defect_type": dtype, "glasses": {}})

        # 合併同 group 的 glass（避免同 group 多列）
        for gid, payload in by_glass.items():
            if gid in d6["glasses"]:
                # 合併數量與 rows
                old = d6["glasses"][gid]
                old["glass_defect_count"] += payload["glass_defect_count"]
                old["small_defect_count"]  += payload["small_defect_count"]
                old["middle_defect_count"] += payload["middle_defect_count"]
                old["large_defect_count"]  += payload["large_defect_count"]
                old["over_defect_count"]   += payload["over_defect_count"]
                old["rows"].extend(payload["rows"])
            else:
                d6["glasses"][gid] = payload

    return {
        "DefectGroupDict": result,
        "ParamDict": cfg.front_config
    }