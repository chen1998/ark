(function(){
  let allRows = [];
  let sortKey = null;

  window.State = window.State || {};
  State.selectedKeys = State.selectedKeys || []; // ['ts|glass|recipe']

  const asDate = (s)=> new Date(String(s).replace(' ','T'));

  function makeKeyFromRow(r){
    // 後端 /api-run-info 已提供這三欄
    return `${r.scantime}|${r.glass_id}|${r.recipe_id}`;
  }

  async function fetchDefectsIfNeeded(row){
    const key = makeKeyFromRow(row);

    // 若有 LR 快取且已有資料就跳過
    if (window.LR && typeof LR.defectsForKey === 'function') {
      const exists = LR.defectsForKey(key);
      if (exists && exists.length) return;
    }
    const url = `/api/defect_data?line_id=${encodeURIComponent(row.line_id)}&key=${encodeURIComponent(key)}`;
    try{
      const res = await fetch(url);
      const j = await res.json();
      const defects = Array.isArray(j.defects) ? j.defects : [];
      if (window.LR && typeof LR.putDefects === 'function') {
        LR.putDefects(key, defects);
      }
      // 明細到位，通知地圖/表格更新
      if (window.Bus && typeof Bus.emit === 'function') {
        Bus.emit('defects-loaded', { key, count: defects.length });
      }
    }catch(err){
      console.error('[run_sheet_table] fetchDefectsIfNeeded error:', err);
    }
  }

  function renderTable(rows){
    const cont  = document.querySelector('#run-sheet-table-container');
    if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-tbody');
    if (!thead || !tbody) return;
    thead.innerHTML = ""; tbody.innerHTML = "";

    // 表頭
    const trHead = document.createElement("tr");
    [
      {text:"選"},{text:"時間",sort:"time"},
      {text:"Recipe",sort:"recipe"},
      {text:"Glass",sort:"sheet"},
      {text:"Model"},
      /*{text:"Line"},
      {text:"Chips"}*/
    ].forEach(col=>{
      const th = document.createElement("th");
      th.textContent = col.text;
      if(col.sort){
        const span = document.createElement("span");
        span.className = "sort-btn";
        span.dataset.sort = col.sort;
        span.textContent = "↕";
        th.appendChild(document.createTextNode(" "));
        th.appendChild(span);
      }
      trHead.appendChild(th);
    });
    thead.appendChild(trHead);

    // 內容
    rows.forEach((r)=>{
      const tr  = document.createElement("tr");
      const key = makeKeyFromRow(r);
      tr.dataset.key = key;

      const selected = State.selectedKeys.includes(key);
      if(selected) tr.classList.add('selected');

      // checkbox
      const tdSel = document.createElement("td");
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.className = "sel"; cb.checked = selected;
      tdSel.appendChild(cb); tr.appendChild(tdSel);

      // 欄位
      const cols = [
        r.scantime, r.recipe_id, r.glass_id, r.model, //r.line_id, (r.chips || '')
      ];
      cols.forEach(val=>{
        const td = document.createElement("td");
        td.textContent = (val != null ? String(val) : "");
        tr.appendChild(td);
      });

      function toggle(want){
        const exists = State.selectedKeys.includes(key);
        if(want){
          if(exists) return true;
          if(State.selectedKeys.length>=2){ if(window.toast) toast('最多選兩筆做比對'); return false; }
          State.selectedKeys.push(key);
          // 取明細（如果沒有快取）
          fetchDefectsIfNeeded(r);
        }else{
          if(!exists) return true;
          State.selectedKeys = State.selectedKeys.filter(k=>k!==key);
        }
        // 通知其它模組（地圖/summary/影像）
        if (window.Bus && typeof Bus.emit === 'function') {
          Bus.emit('compare-selection-changed', { keys: [...State.selectedKeys] });
        }
        return true;
      }

      tr.addEventListener('click',(ev)=>{
        if(ev.target && ev.target.classList.contains('sel')) return;
        cb.checked = !cb.checked;
        if(!toggle(cb.checked)) cb.checked = !cb.checked;
        tr.classList.toggle('selected', cb.checked);
      });
      cb.addEventListener('change', ()=>{
        if(!toggle(cb.checked)) cb.checked = !cb.checked;
        tr.classList.toggle('selected', cb.checked);
      });

      tbody.appendChild(tr);
    });

    // 排序
    thead.querySelectorAll(".sort-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const t = btn.dataset.sort;
        sortKey = t;
        if(t==="time")   rows.sort((a,b)=> asDate(b.scantime) - asDate(a.scantime));
        if(t==="recipe") rows.sort((a,b)=> String(a.recipe_id).localeCompare(String(b.recipe_id)));
        if(t==="sheet")  rows.sort((a,b)=> String(a.glass_id).localeCompare(String(b.glass_id)));
        renderTable(rows);
      });
    });
  }

  // 對外：由 api.js 呼叫
  window.renderRunSheetTable = function(rows){
    allRows = rows || [];
    renderTable(allRows);
  };
})();