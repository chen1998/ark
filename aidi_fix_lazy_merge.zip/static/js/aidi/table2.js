// AIDI 表格（lazy 展開、共通欄位合併、細項點擊取點/取消）
(function(){
  const ns = window.AIDI = window.AIDI || {};

  const selectedRuns = new Map(); // key = `${scantime}|${glass_id}|${recipe_id}`
  const groupCache = new Map();    // key = groupKey -> {runs: [...]}

  function runKey(r){ return `${r.scantime}|${r.glass_id}|${r.recipe_id}`; }

  function redrawMiniMapFromSelection(){
    const allPts = [];
    selectedRuns.forEach(v => (v.points||[]).forEach(p => allPts.push(p)));
    if (!ns._miniMap) {
      if (ns.MiniMap) ns._miniMap = new ns.MiniMap('#aidi-mini-map');
      else return;
    }
    const xs = allPts.map(p=>p.x), ys = allPts.map(p=>p.y);
    const bbox = allPts.length ? { xmin: Math.min(...xs), xmax: Math.max(...xs), ymin: Math.min(...ys), ymax: Math.max(...ys) } : null;
    ns._miniMap.setData(allPts, bbox);
  }

  function hourStrOf(r){
    const t = (r.time||'').slice(0,13);
    return t ? (t + ':00') : '';
  }

  function groupKey(r){
    return [
      r.line_id,
      r.aoi_id,
      r.model_id,
      r.defect_code || '',
      isFinite(+r.density) ? (+r.density).toFixed(3) : '',
      hourStrOf(r)
    ].join('||');
  }

  function makeGroups(data){
    const map = new Map();
    data.forEach(r=>{
      const k = groupKey(r);
      if (!map.has(k)) map.set(k, { head: r, key: k });
    });
    return Array.from(map.values()).sort((a,b)=>{
      const ah = hourStrOf(a.head), bh = hourStrOf(b.head);
      if (ah<bh) return -1; if (ah>bh) return 1;
      if (a.head.line_id<b.head.line_id) return -1;
      if (a.head.line_id>b.head.line_id) return 1;
      if (a.head.aoi_id<b.head.aoi_id) return -1;
      if (a.head.aoi_id>b.head.aoi_id) return 1;
      if (a.head.model_id<b.head.model_id) return -1;
      if (a.head.model_id>b.head.model_id) return 1;
      return 0;
    });
  }

  function buildGroupRow(g, tbody){
    const h = g.head;
    const tr = ns.el('tr', {'data-group-key': g.key, class:'group-row'});
    const cells = {
      line:   ns.el('td', {class:'g-line'}), 
      aoi:    ns.el('td', {class:'g-aoi'}),
      model:  ns.el('td', {class:'g-model'}),
      code:   ns.el('td', {class:'g-code'}),
      dens:   ns.el('td', {class:'g-density'}),
      hour:   ns.el('td', {class:'g-hour'}),
      action: ns.el('td', {class:'g-action'})
    };
    cells.line.textContent  = h.line_id;
    cells.aoi.textContent   = h.aoi_id;
    cells.model.textContent = h.model_id;
    cells.code.textContent  = h.defect_code || '';
    cells.dens.textContent  = (isFinite(+h.density)?(+h.density).toFixed(3):'');
    cells.hour.textContent  = hourStrOf(h);

    const btn = ns.el('button', {class:'btn btn-xs'});
    btn.textContent = '展開';
    btn.addEventListener('click', async ()=>{
      const opened = tr.classList.toggle('is-open');
      btn.textContent = opened ? '收合' : '展開';
      if (opened){
        await expandGroup(g, tr, tbody);
      }else{
        collapseGroup(tr, tbody);
      }
    });
    cells.action.appendChild(btn);

    Object.values(cells).forEach(td=> tr.appendChild(td));
    tbody.appendChild(tr);
  }

  async function expandGroup(g, trHead, tbody){
    const h = g.head;
    const hour = hourStrOf(h);
    const line = h.line_id, aoi = h.aoi_id, model = h.model_id;
    let runs = groupCache.get(g.key)?.runs;
    if (!runs){
      try{
        const codeSel = ns.getSel ? ns.getSel('aidiCode') : [];
        const resp = await ns.fetchRunsUnderHourGroup({ time: hour, line_id: line, aoi_id: aoi, model_id: model, defect_codes: codeSel });
        runs = resp.runs || [];
        groupCache.set(g.key, { runs });
      }catch(e){ console.error(e); runs = []; }
    }
    if (!runs.length){
      const tr = ns.el('tr', {'data-parent': g.key, class:'detail-empty'});
      const td = ns.el('td', {colspan:'4'});
      td.textContent = '（此群組無細項）';
      tr.appendChild(td);
      setRowspanForHead(trHead, 1);
      tbody.insertBefore(tr, trHead.nextSibling);
      return;
    }
    runs.forEach((r)=>{
      const tr = ns.el('tr', {'data-parent': g.key, class:'detail-row'});
      const t1 = detailCell(r.scantime);
      const t2 = detailCell(r.glass_id);
      const t3 = detailCell(r.recipe_id);
      const t4 = detailCell(String(r.defect_count));
      [t1,t2,t3,t4].forEach(td => {
        td.addEventListener('click', async ()=>{
          const payload = { scantime: r.scantime, glass_id: r.glass_id, recipe_id: r.recipe_id, aoi_id: aoi, line_id: line };
          const k = `${r.scantime}|${r.glass_id}|${r.recipe_id}`;
          const toggled = td.classList.toggle('is-selected');
          [t1,t2,t3,t4].forEach(x=> toggled ? x.classList.add('is-selected') : x.classList.remove('is-selected'));
          if (toggled){
            try{
              const codeSel = ns.getSel ? ns.getSel('aidiCode') : [];
              const { points } = await ns.fetchPointsByRun({ ...payload, defect_codes: codeSel });
              selectedRuns.set(k, { meta: payload, points: points||[] });
            }catch(e){ console.error(e); selectedRuns.delete(k); }
          }else{
            selectedRuns.delete(k);
          }
          redrawMiniMapFromSelection();
        });
      });
      tr.appendChild(t1); tr.appendChild(t2); tr.appendChild(t3); tr.appendChild(t4);
      tbody.insertBefore(tr, trHead.nextSibling);
    });
    setRowspanForHead(trHead, runs.length);
  }

  function collapseGroup(trHead, tbody){
    const gkey = trHead.getAttribute('data-group-key');
    Array.from(tbody.querySelectorAll(`tr[data-parent="${gkey}"]`)).forEach(tr => {
      if (tr.classList.contains('detail-row')){
        const [sc, gi, ri] = Array.from(tr.querySelectorAll('.detail-cell')).map(td=>td.textContent);
        const k = `${sc}|${gi}|${ri}`;
        selectedRuns.delete(k);
      }
      tr.remove();
    });
    setRowspanForHead(trHead, 1);
    redrawMiniMapFromSelection();
  }

  function setRowspanForHead(trHead, n){
    const tds = trHead.querySelectorAll('td.g-line, td.g-aoi, td.g-model, td.g-code, td.g-density, td.g-hour');
    tds.forEach(td => td.setAttribute('rowspan', String(Math.max(1,n))));
  }

  function detailCell(text){
    const td = ns.el('td', {class:'detail-cell'});
    td.textContent = text==null?'':String(text);
    td.title = '點擊切換選取/取消，並載入/移除地圖點位';
    return td;
  }

  ns.renderTable = async function(){
    const host = ns.qs('#aidi-table'); if(!host) return;
    const data = ns.getFiltered();
    if(!data.length){
      host.innerHTML = '<div class="table-placeholder">（無資料）</div>';
      return;
    }
    const wrap = ns.el('div');
    const toolRow = ns.el('div', {class:'aidi-table-toolbar'});
    const btnClear = ns.el('button', {class:'btn btn-xs btn-secondary'});
    btnClear.textContent = '清空選取 & 清空地圖';
    btnClear.addEventListener('click', ()=>{
      Array.from(document.querySelectorAll('.aidi-table .detail-cell.is-selected')).forEach(td=> td.classList.remove('is-selected'));
      selectedRuns.clear();
      redrawMiniMapFromSelection();
    });
    toolRow.appendChild(btnClear);
    wrap.appendChild(toolRow);

    const tbl = ns.el('table',{class:'table aidi-table'});
    const thead = ns.el('thead');
    thead.innerHTML = `
      <tr>
        <th>Line</th>
        <th>AOI</th>
        <th>Model</th>
        <th>Defect Code</th>
        <th>Density</th>
        <th>Hour</th>
        <th colspan="4">Details (Scantime / Glass / Recipe / Defect Count)</th>
        <th>操作</th>
      </tr>`;
    const tbody = ns.el('tbody');
    tbl.appendChild(thead); tbl.appendChild(tbody);
    wrap.appendChild(tbl);
    host.innerHTML = ''; host.appendChild(wrap);

    const groups = makeGroups(data);
    groups.forEach(g => buildGroupRow(g, tbody));
  };

})();