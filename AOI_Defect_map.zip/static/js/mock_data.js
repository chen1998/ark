// static/js/mock_data.js
// ---------- Mock Data ----------
const MockData = {
  MAP_W: 1850,
  MAP_H: 1500,
  run_sheet_list: [],         // rows for run table
  sheet_defect_dict: {},      // { sheet_id: {A:[...], B:[...] } }
  images: {}                  // key: sheet_id|A or sheet_id|B -> url
};

(function gen(){
  const types = ["Dot","Particle","Line","Butterfly"];
  const sizes = ["S","M","L","O"];
  const tools = ["CCAOI202", "CCAOI203"];
  const recipes = ["R101","R102"]; // R101=製程/清洗前, R102=製程/清洗後
  const now = new Date();

  const pad = n=> String(n).padStart(2,'0');
  const fmt = (d)=> `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;

  // 在最近 30 天內分散時間
  const withinMonth = (dayShift, hourShift=0)=>{
    const d = new Date(now);
    d.setDate(d.getDate() - dayShift);
    d.setHours(d.getHours() - hourShift);
    return fmt(d);
  };

  // 生成一組「基底 defects」再分 A/B 做抖動
  function genBaseDefects(n=260){
    const arr = [];
    for(let i=0;i<n;i++){
      arr.push({
        x: Math.random()*MockData.MAP_W,
        y: Math.random()*MockData.MAP_H,
        type: types[Math.floor(Math.random()*types.length)],
        size: sizes[Math.floor(Math.random()*sizes.length)],
        value: +(Math.random()*1.0).toFixed(2)
      });
    }
    return arr;
  }
  function jitter(pt, mag=6){
    return {
      x: Math.max(0, Math.min(MockData.MAP_W, pt.x + (Math.random()*2-1)*mag)),
      y: Math.max(0, Math.min(MockData.MAP_H, pt.y + (Math.random()*2-1)*mag)),
      type: pt.type,
      size: pt.size,
      value: +(pt.value + (Math.random()*0.1-0.05)).toFixed(2)
    };
  }

  const N = 10; // 10 張 sheet
  for(let i=1;i<=N;i++){
    const sheet = "S" + String(i).padStart(3,'0');
    const lot   = "L" + String(200 + (i%5));
    const chip  = "C" + String(1 + (i%3));
    const tool  = tools[i%tools.length];

    // === 缺料來源：確保 A/B 一定存在 ===
    const base = genBaseDefects(220 + Math.floor(Math.random()*120)); // 220~340
    const A = base.map(b=>jitter(b, 4));
    // B 有些消失 & 一些新增
    const B = base
      .filter(()=> Math.random() > 0.08)   // 約 8% 消失
      .map(b=>jitter(b, 6))
      .concat( genBaseDefects(20).map(b=>({ ...b })) ); // 新增 ~20 顆

    MockData.sheet_defect_dict[sheet] = { A, B };
    MockData.images[`${sheet}|A`] = `http://10.97.139.98:1454/CAAOI202/CA038501/YD5A7NA2A/PCS1/20250728021055/CaptureImage/RV1_1645179_1444405_32.JPG`;
    MockData.images[`${sheet}|B`] = `https://placehold.co/640x360?text=${sheet}+POST`;

    // === 產出 run rows（兩種工程情境）
    // 1) 同 sheet、同 recipe（清洗前/後，時間早晚不同）
    const t1 = withinMonth(2*i + 10, 3);  // 早
    const t2 = withinMonth(2*i + 5,  2);  // 晚
    MockData.run_sheet_list.push({ measure_time: t1, recipe_id: recipes[0], sheet_id: sheet, chip, lot_id: lot, tool });
    MockData.run_sheet_list.push({ measure_time: t2, recipe_id: recipes[0], sheet_id: sheet, chip, lot_id: lot, tool });

    // 2) 同 sheet、不同 recipe（製程前/後）
    const t3 = withinMonth(2*i + 4,  6);  // 早（製程前）
    const t4 = withinMonth(2*i + 1,  1);  // 晚（製程後）
    MockData.run_sheet_list.push({ measure_time: t3, recipe_id: recipes[0], sheet_id: sheet, chip, lot_id: lot, tool });
    MockData.run_sheet_list.push({ measure_time: t4, recipe_id: recipes[1], sheet_id: sheet, chip, lot_id: lot, tool });
  }
})();

// 初始化
window.addEventListener('DOMContentLoaded', ()=>{
  Bus.emit('init-data', {mock: MockData});
});
