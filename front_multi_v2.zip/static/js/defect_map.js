// defect_map.js — 繪製多筆疊加點位 + 點擊顯示圖片
(function(){
  const canvas = document.getElementById('defect-map-canvas');
  const legend = document.getElementById('map-legend');
  const gallery = document.getElementById('gallery-grid');

  let ctx, W, H;
  function resize(){
    if(!canvas) return;
    const rect = canvas.getBoundingClientRect();
    canvas.width  = Math.max(200, rect.width);
    canvas.height = Math.max(200, rect.height);
    W = canvas.width; H = canvas.height;
    ctx = canvas.getContext('2d');
  }
  resize();
  window.addEventListener('resize', ()=>{ resize(); drawAll(); });

  function getDefects(key){ return State.DefectCache.get(key) || []; }

  function allPoints(){
    const pts = [];
    (State.selectedKeys||[]).forEach(k => {
      const arr = getDefects(k);
      arr.forEach(p => pts.push(p));
    });
    return pts;
  }

  function computeBounds(){
    const pts = allPoints();
    if(pts.length===0) return {minX:0, minY:0, maxX:1, maxY:1};
    let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
    for(const p of pts){
      const x = +p.x, y = +p.y;
      if(isFinite(x) && isFinite(y)){
        if(x<minX) minX=x; if(y<minY) minY=y;
        if(x>maxX) maxX=x; if(y>maxY) maxY=y;
      }
    }
    if(!isFinite(minX) || !isFinite(minY) || !isFinite(maxX) || !isFinite(maxY)){
      return {minX:0, minY:0, maxX:1, maxY:1};
    }
    // padding
    const padX = (maxX-minX)*0.05 || 1;
    const padY = (maxY-minY)*0.05 || 1;
    return { minX:minX-padX, minY:minY-padY, maxX:maxX+padX, maxY:maxY+padY };
  }

  function toScreen(x, y, bounds){
    const sx = (x - bounds.minX) / (bounds.maxX - bounds.minX + 1e-6);
    const sy = (y - bounds.minY) / (bounds.maxY - bounds.minY + 1e-6);
    // y 軸向下，所以要翻轉
    return { X: sx * W, Y: H - (sy * H) };
  }

  function sizeToRadius(size){
    // 支援字串等級或數字，做個大概映射
    const s = String(size||'').toUpperCase();
    if(s==='S') return 2;
    if(s==='M') return 3;
    if(s==='L') return 4;
    if(s==='O') return 5;
    const n = parseFloat(s);
    if(!isNaN(n)){
      if(n<10) return 2;
      if(n<20) return 3;
      if(n<30) return 4;
      return 5;
    }
    return 3;
  }

  function drawAll(){
    if(!ctx) return;
    ctx.clearRect(0,0,W,H);
    const bounds = computeBounds();

    // 畫每一筆 key
    (State.selectedKeys||[]).forEach((k, idx)=>{
      if(!State.ColorForKey.has(k)) State.ColorForKey.set(k, Utils.getColor(idx));
      const color = State.ColorForKey.get(k);
      const arr = getDefects(k);

      ctx.fillStyle = color;
      ctx.globalAlpha = 0.85;
      for(const p of arr){
        const x = +p.x, y = +p.y;
        if(!isFinite(x) || !isFinite(y)) continue;
        const {X,Y} = toScreen(x,y,bounds);
        const r = sizeToRadius(p.size || p.defect_size);
        ctx.beginPath(); ctx.arc(X,Y,r,0,Math.PI*2); ctx.fill();
      }
      ctx.globalAlpha = 1.0;
    });

    // 更新圖例
    legend.innerHTML = '';
    (State.selectedKeys||[]).forEach((k, idx)=>{
      const el = document.createElement('div');
      el.className = 'legend-item';
      const dot = document.createElement('span');
      dot.className = 'legend-dot';
      const color = State.ColorForKey.get(k) || Utils.getColor(idx);
      dot.style.background = color;
      const meta = Utils.parseKey(k);
      const label = document.createElement('span');
      label.textContent = `${meta.glass_id}/${meta.recipe_id} @ ${meta.scantime}`;
      el.appendChild(dot); el.appendChild(label);
      legend.appendChild(el);
    });
  }

  // 點擊 → 新增圖片卡
  function addImageCard(imgUrl, meta){
    if(!imgUrl) return;
    const card = document.createElement('div');
    card.className = 'img-card';
    const cap = document.createElement('div');
    cap.className = 'cap';
    cap.textContent = `${meta.glass_id}/${meta.recipe_id}`;
    const img = document.createElement('img');
    img.src = imgUrl;
    const metaDiv = document.createElement('div');
    metaDiv.className = 'meta';
    metaDiv.textContent = `chip:${meta.chip || '-'} type:${meta.type || '-'} x:${meta.x} y:${meta.y}`;
    card.appendChild(cap); card.appendChild(img); card.appendChild(metaDiv);
    gallery.prepend(card);
  }

  function handleClick(ev){
    const rect = canvas.getBoundingClientRect();
    const mx = ev.clientX - rect.left;
    const my = ev.clientY - rect.top;

    const bounds = computeBounds();
    let nearest = null, bestD = Infinity, bestKey = null;
    (State.selectedKeys||[]).forEach(k=>{
      const arr = getDefects(k);
      const color = State.ColorForKey.get(k) || '#fff';
      for(const p of arr){
        const pos = toScreen(+p.x, +p.y, bounds);
        const dx = pos.X - mx, dy = pos.Y - my;
        const d2 = dx*dx + dy*dy;
        if(d2 < bestD){
          bestD = d2; nearest = p; bestKey = k;
        }
      }
    });
    if(nearest && bestD < 100){ // 半徑 10 內
      const meta = { ...Utils.parseKey(bestKey), chip: nearest.chip, type: nearest.type, x:nearest.x, y:nearest.y };
      const url = nearest.img || nearest.pic_name || '';
      addImageCard(url, meta);
    }
  }

  canvas.addEventListener('click', handleClick);

  // 監聽資料變更
  Bus.on('selection-changed', ()=> drawAll());
  Bus.on('defect-data-loaded', ()=> drawAll());

  // 清空畫廊按鈕
  document.getElementById('btnClearGallery').addEventListener('click', ()=> gallery.innerHTML = '');
  document.getElementById('btnClearGallery2').addEventListener('click', ()=> gallery.innerHTML = '');
})();
