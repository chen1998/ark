(function () {
  let sortKey = null;

  const asDate = (str) => new Date(str.replace(' ', 'T'));

  function updateStats(rows) {
    const el = document.getElementById('run-stats');
    if (!el) return;
    const badges = el.querySelectorAll('.badge b');
    if (badges.length >= 2) {
      badges[0].textContent = rows.length;                           // 筆數
      badges[1].textContent = new Set(rows.map(r => r.glass_id)).size; // 唯一 Glass
    }
  }

  function renderSelectionSummary() {
    const el = document.getElementById('selection-summary');
    if (!el) return;
    const [kA, kB] = State.selectedKeys;

    const fmt = (k, label) => {
      if (!k) return `<div class="sel-card empty">${label}：未選</div>`;
      const r = LR.rowForKey(k);
      if (!r) return `<div class="sel-card empty">${label}：無資料</div>`;
      return `<div class="sel-card"><b>${label}</b>｜${r.scantime}｜Glass:${r.glass_id}｜Recipe:${r.recipe_id}</div>`;
    };

    el.innerHTML = fmt(kA, '第一筆') + fmt(kB, '第二筆');
  }

  // 對外暴露：渲染表格
  window.renderRunSheetTable = function (rowsInput) {
    const rows = (rowsInput || []).slice();
    const cont = document.querySelector('#run-sheet-table-container');
    if (!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-tbody');
    if (!thead || !tbody) return;

    thead.innerHTML = '';
    tbody.innerHTML = '';

    // head
    const trHead = document.createElement('tr');
    [
      { text: '選' },
      { text: '時間', sort: 'time' },
      { text: 'Recipe', sort: 'recipe' },
      { text: 'Glass', sort: 'glass' },
      { text: 'Model' },
      /*{ text: 'Chips' },
      { text: 'Defects' }*/
    ].forEach(col => {
      const th = document.createElement('th');
      th.textContent = col.text;
      if (col.sort) {
        const span = document.createElement('span');
        span.className = 'sort-btn';
        span.dataset.sort = col.sort;
        span.textContent = '↕';
        th.appendChild(document.createTextNode(' '));
        th.appendChild(span);
      }
      trHead.appendChild(th);
    });
    thead.appendChild(trHead);

    // body
    rows.forEach((r) => {
      const tr = document.createElement('tr');
      const key = LR.makeKey(r);

      // dataset 綁定（你之前要求）
      tr.dataset.measure_time = r.scantime;
      tr.dataset.glass_id = r.glass_id;
      tr.dataset.recipe_id = r.recipe_id;
      tr.dataset.key = key;

      const selected = State.selectedKeys.includes(key);
      if (selected) tr.classList.add('selected');

      // checkbox
      const tdSel = document.createElement('td');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.className = 'sel';
      cb.checked = selected;
      tdSel.appendChild(cb);
      tr.appendChild(tdSel);

      // cols
      const defectCount = r.defect_summary ? (r.defect_summary.defect_count ?? '') : '';
      const cols = [r.scantime, r.recipe_id, r.glass_id, r.model]; //, r.chips || '', defectCount
      cols.forEach(val => {
        const td = document.createElement('td');
        td.textContent = val == null ? '' : String(val);
        tr.appendChild(td);
      });

      function toggle(wantChecked) {
        const exists = State.selectedKeys.includes(key);
        if (wantChecked) {
          if (exists) return true;
          if (State.selectedKeys.length >= 2) { toast('最多選兩筆做比對'); return false; }
          State.selectedKeys.push(key);
        } else {
          if (!exists) return true;
          State.selectedKeys = State.selectedKeys.filter(k => k !== key);
          // 若剩一筆且原本是第二筆，讓它移到第一筆位置（陣列只剩一元素自然是第一）
        }
        Bus.emit('compare-selection-changed', [...State.selectedKeys]);
        return true;
      }

      tr.addEventListener('click', (ev) => {
        if (ev.target && ev.target.classList.contains('sel')) return;
        cb.checked = !cb.checked;
        if (!toggle(cb.checked)) cb.checked = !cb.checked;
        tr.classList.toggle('selected', cb.checked);
      });

      cb.addEventListener('change', () => {
        if (!toggle(cb.checked)) { cb.checked = !cb.checked; return; }
        tr.classList.toggle('selected', cb.checked);
      });

      tbody.appendChild(tr);
    });

    // sorting
    thead.querySelectorAll('.sort-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const t = btn.dataset.sort;
        sortKey = t;
        if (t === 'time') rows.sort((a, b) => asDate(b.scantime) - asDate(a.scantime));
        if (t === 'recipe') rows.sort((a, b) => String(a.recipe_id).localeCompare(String(b.recipe_id)));
        if (t === 'glass') rows.sort((a, b) => String(a.glass_id).localeCompare(String(b.glass_id)));
        window.renderRunSheetTable(rows);
      });
    });

    updateStats(rows);
    renderSelectionSummary();
  };

  // selection 改變時更新 summary（渲染在 api.js 也會觸發 defect 拉取）
  Bus.on('compare-selection-changed', renderSelectionSummary);
})();