// api.js — 取後端資料 + 建立 Tabs + 日期套用
(function(){
  async function fetchJSON(url){
    const res = await fetch(url, { method:'GET' }); // 不帶 credentials，避免 CORS include 問題
    if(!res.ok) throw new Error(res.status + ' ' + res.statusText);
    return res.json();
  }

  async function fetchAllRunInfo(){
    const url = new URL('/api/run-info', window.API_BASE);
    return fetchJSON(url.toString());
  }
  async function fetchRunInfoByLine(lineId, start, end){
    const url = new URL('/api/run-info', window.API_BASE);
    url.searchParams.set('line_id', lineId);
    if(start) url.searchParams.set('start', start);
    if(end) url.searchParams.set('end', end);
    return fetchJSON(url.toString());
  }
  async function fetchDefectsByKey(key, lineId){
    const url = new URL('/api/defect-data', window.API_BASE);
    url.searchParams.set('key', key);
    if(lineId) url.searchParams.set('line_id', lineId);
    return fetchJSON(url.toString());
  }

  function buildTabs(lineTabs){
    const cont = document.getElementById('all-tab-container');
    cont.innerHTML = '';
    const row = document.createElement('div'); row.className='line-tabs';
    lineTabs.forEach((line, i)=>{
      const b = document.createElement('button');
      b.className = 'tab-btn' + (i===0?' active':'');
      b.textContent = line;
      b.addEventListener('click', async ()=>{
        row.querySelectorAll('.tab-btn').forEach(btn=>btn.classList.remove('active'));
        b.classList.add('active');
        await chooseLine(line);
      });
      row.appendChild(b);
    });
    cont.appendChild(row);
  }

  function setDateInputsAuto(range){
    const f = document.getElementById('fDateFrom');
    const t = document.getElementById('fDateTo');
    if(!range||!range.min||!range.max) return;
    f.value = range.min.slice(0,10);
    t.value = range.max.slice(0,10);
  }

  function computeRange(rows){
    if(!rows||!rows.length) return null;
    const times = rows.map(r=>String(r.scantime||'').replace(' ','T'));
    times.sort();
    return { min: times[0], max: times[times.length-1] };
  }

  async function chooseLine(line){
    State.currentLine = line;
    // 先查本地有沒有
    const local = State.AllRunInfo[line];
    if(local && local.length){
      Bus.emit('render-run-info', local);
      setDateInputsAuto(computeRange(local));
      return;
    }
    // 否則打 API 拉一波（預設最近幾天）
    const data = await fetchRunInfoByLine(line);
    const dict = data.UniRunInfoTableData || {};
    const rows = Object.values(dict);
    State.AllRunInfo[line] = rows;
    setDateInputsAuto(computeRange(rows));
    Bus.emit('render-run-info', rows);
  }

  async function init(){
    try{
      const payload = await fetchAllRunInfo();
      State.LineTabs = payload.AllLineTabs || [];
      const allDict = payload.AllRunInfoTableData || {};
      // 轉成陣列，存進 State.AllRunInfo
      Object.keys(allDict).forEach(line=>{
        State.AllRunInfo[line] = Object.values(allDict[line]||{});
      });
      buildTabs(State.LineTabs);
      if(State.LineTabs.length){
        await chooseLine(State.LineTabs[0]);
      }
    }catch(e){
      console.error('[api.js] init error:', e);
      toast('載入初始資料失敗');
    }
  }

  // 日期套用/清空
  document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('applyDates').addEventListener('click', async ()=>{
      if(!State.currentLine) return;
      const f = document.getElementById('fDateFrom').value;
      const t = document.getElementById('fDateTo').value;
      const data = await fetchRunInfoByLine(State.currentLine, f, t);
      const dict = data.UniRunInfoTableData || {};
      const rows = Object.values(dict);
      State.AllRunInfo[State.currentLine] = rows;
      Bus.emit('render-run-info', rows);
    });
    document.getElementById('clearDates').addEventListener('click', async ()=>{
      if(!State.currentLine) return;
      const data = await fetchRunInfoByLine(State.currentLine);
      const dict = data.UniRunInfoTableData || {};
      const rows = Object.values(dict);
      State.AllRunInfo[State.currentLine] = rows;
      setDateInputsAuto(computeRange(rows));
      Bus.emit('render-run-info', rows);
    });
  });

  // 勾選後需去抓 defects
  Bus.on('request-defects', async (keys)=>{
    for(const key of keys){
      if(State.DefectCache[key]) continue;
      try{
        const resp = await fetchDefectsByKey(key, State.currentLine);
        const list = (resp && resp.defects) ? resp.defects : [];
        // 正規化欄位 + 圖名補副檔名
        const norm = list.map((d)=>{
          const x = Number(d.x); const y = Number(d.y);
          const size = d.size || d.defect_size || 'S';
          const type = d.type || d.predict_code || '1';
          const chip = d.chip || d.chip_name || '';
          const file = d.img || d.pic_name || '';
          return { x, y, size, type, chip, file };
        });
        State.DefectCache[key] = norm;
        Bus.emit('defect-refresh');  // 讓 defect tables 跟 map 重畫
      }catch(e){
        console.error('[api] defect fetch error', e);
      }
    }
  });

  window.API = { fetchAllRunInfo, fetchRunInfoByLine, fetchDefectsByKey };
  document.addEventListener('DOMContentLoaded', init);
})();
