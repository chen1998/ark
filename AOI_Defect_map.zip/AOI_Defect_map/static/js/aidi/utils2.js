// AIDI core utils
(function(){
    const ns = window.AIDI = window.AIDI || {};
  
    ns.qs  = (s,r)=> (r||document).querySelector(s);
    ns.qsa = (s,r)=> Array.from((r||document).querySelectorAll(s));
    ns.el  = (t,a)=>{ const e=document.createElement(t); if(a){for(const k in a) e.setAttribute(k,a[k]);} return e; };
  
    // 解析 "YYYY-MM-DD HH:00" 或 ISO "YYYY-MM-DDTHH:mm"
    ns.parseHour = function(s){
      const d = new Date(String(s).replace('T',' ').replace(/(\d{2}):\d{2}$/,'$1:00'));
      return isNaN(+d) ? null : d;
    };
    ns.dateStr = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  
    // 僅在切到 AIDI 才載 d3
    ns.ensureD3 = function(){
      return new Promise(res=>{
        if(window.d3){ res(); return; }
        const sc = document.createElement('script');
        sc.src = 'https://cdn.jsdelivr.net/npm/d3@7';
        sc.onload = ()=> res();
        document.head.appendChild(sc);
      });
    };
  
    // 全域狀態（單一命名空間）
    ns.state = {
      inited: false,
      tabsCacheHTML: null,
      currentTab: 'UPI Hourly',
      full: { allSummary:[], series:[], filters:{ line_ids:[], aoi_ids:[], models:[], glass_sides:[], defect_codes:[] }, time_bins:[] },
      mdd: { line:null, aoi:null, model:null, code:null } // MultiDD instances
    };
  })();

  /*
  
  */