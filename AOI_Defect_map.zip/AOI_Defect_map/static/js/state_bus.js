(function () {
  if (!window.Bus) {
    const events = {};
    window.Bus = {
      on(name, fn) { (events[name] = events[name] || []).push(fn); },
      emit(name, payload) { (events[name] || []).forEach(fn => { try { fn(payload); } catch (e) { console.error('[Bus]', name, e); } }); }
    };
  }
  window.State = window.State || {};
})();