(function () {
  const API_BASE = 'http://10.97.142.217:8100';

  // 全域資料池（run-info + defects cache 會交給 LR 管）
  window.AppData = window.AppData || {
    lineTabs: [],              // ['CAPIT203','CAAOI202','CAAOI300']
    allRunInfo: {},            // { line_id: {0:{...},1:{...}} }
  };

  async function fetchJSON(url) {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`${url} -> ${res.status}`);
    return res.json();
  }

  // 取得全部資料（初始化）
  async function fetchAllRunInfo() {
    const url = `${API_BASE}/api/run-info`;
    return fetchJSON(url);
  }

  // 依 line + 日期範圍載入單線資料
  async function fetchRunInfoByLine(lineId, start, end) {
    const url = new URL(`${API_BASE}/api/run-info`);
    url.searchParams.set('line_id', lineId);
    if (start) url.searchParams.set('start', start);
    if (end) url.searchParams.set('end', end);
    return fetchJSON(url.toString());
  }

  // 依 key + line 取得缺陷明細
  async function fetchDefectsByKey(key, lineId) {
    const url = new URL(`${API_BASE}/api/defect-data`);
    url.searchParams.set('key', key);
    if (lineId) url.searchParams.set('line_id', lineId);
    return fetchJSON(url.toString());
  }

  // 建 tabs（用 line_id）
  function buildTabs(lineTabs) {
    const cont = document.getElementById('all-tab-container');
    if (!cont) return;
    cont.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'tabs-row';

    lineTabs.forEach((line, idx) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn';
      btn.textContent = line;
      if (idx === 0) btn.classList.add('active');

      btn.addEventListener('click', async () => {
        row.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        State.currentLine = line;

        // 有快取就用，沒有就打單線 API（使用最近 3 天）
        let dictRows = AppData.allRunInfo[line];
        if (!dictRows) {
          try {
            const end = new Date();
            const start = new Date(end.getTime() - 3 * 86400000);
            const fmt = (d) => d.toISOString().slice(0, 10);
            const payload = await fetchRunInfoByLine(line, fmt(start), fmt(end));
            if (payload.UniRunInfoTableData) {
              AppData.allRunInfo[line] = payload.UniRunInfoTableData;
              dictRows = payload.UniRunInfoTableData;
            }
          } catch (e) {
            console.error('[api] fetchRunInfoByLine error', e);
          }
        }

        const rows = Object.values(dictRows || {});
        LR.setRunRowsForLine(line, rows);         // 交給 LR 管（key->row）
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      });

      row.appendChild(btn);
    });

    cont.appendChild(row);
  }

  // 把 selection 改變時，主動拉缺陷明細（缺的才打）
  Bus.on('compare-selection-changed', async (keys) => {
    if (!keys || keys.length === 0) {
      Bus.emit('defect-data-ready'); // 清空畫面
      return;
    }
    // 確保有 currentLine（後端可以沒帶 line_id 也會 auto-detect，但建議帶）
    const line = State.currentLine || AppData.lineTabs[0];

    await Promise.all(keys.map(async (k) => {
      if (!LR.hasDefects(k)) {
        try {
          const data = await fetchDefectsByKey(k, line);
          if (Array.isArray(data.defects)) {
            LR.storeDefects(k, data.defects);
          } else {
            LR.storeDefects(k, []);
          }
        } catch (e) {
          console.error('[api] fetchDefectsByKey error', e);
        }
      }
    }));

    // 告知缺陷資料到齊
    Bus.emit('defect-data-ready', [...keys]);
  });

  async function init() {
    try {
      const payload = await fetchAllRunInfo(); // { AllRunInfoTableData, AllLineTabs }
      AppData.lineTabs = payload.AllLineTabs || [];
      AppData.allRunInfo = payload.AllRunInfoTableData || {};

      // 初始化 LR：放入所有 line 的 rows（讓 LR 有能力 rowForKey/imageForKey）
      Object.entries(AppData.allRunInfo).forEach(([line, dictRows]) => {
        LR.setRunRowsForLine(line, Object.values(dictRows || {}));
      });

      // 建 Tabs
      buildTabs(AppData.lineTabs);

      // 預設顯示第一個 line
      if (AppData.lineTabs.length) {
        State.currentLine = AppData.lineTabs[0];
        const rows = Object.values(AppData.allRunInfo[State.currentLine] || {});
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      }
    } catch (err) {
      console.error('[api.js] init error:', err);
      toast('載入初始資料失敗');
    }
  }

  document.addEventListener('DOMContentLoaded', init);

  // 對外：若你要主動用日期範圍切換某個 line
  window.loadUniByLineAndDates = async function (lineId, start, end) {
    const data = await fetchRunInfoByLine(lineId, start, end);
    if (data.UniRunInfoTableData) {
      AppData.allRunInfo[lineId] = data.UniRunInfoTableData;
      const rows = Object.values(data.UniRunInfoTableData);
      LR.setRunRowsForLine(lineId, rows);
      State.currentLine = lineId;
      if (typeof window.renderRunSheetTable === 'function') {
        window.renderRunSheetTable(rows);
      }
    }
  };
})();