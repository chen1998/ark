// event bus + global state + helpers
window.Bus = (function(){
  const handlers = {};
  return {
    on(name, fn){ (handlers[name]||(handlers[name]=[])).push(fn); },
    emit(name, payload){ (handlers[name]||[]).forEach(fn=>{ try{ fn(payload); }catch(e){ console.error(e); } }); }
  };
})();

window.State = {
  filters: { dateFrom:"", dateTo:"", recipeOrSheet:"" },
  selectedRows: [],            // 最多兩筆
  subFilter: { types: new Set(), sizes: new Set() },
};

// toast
window.toast = (msg)=>{
  const el = document.getElementById('toast');
  if(!el) return;
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(()=> el.classList.remove('show'), 1500);
};
