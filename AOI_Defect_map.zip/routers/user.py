from fastapi import APIRouter, Request, Body
from fastapi.responses import JSONResponse, RedirectResponse
import xml.etree.ElementTree as ET
from urllib.parse import parse_qs
import os
from pathlib import Path
from routers.main_page import HomePage_name, PortNumber

import logging
logger = logging.getLogger(__name__)
# 載入環境變數


from sqlalchemy import create_engine,text
hr_db_engine = create_engine("mssql+pymssql://lcd1mfg:lcd1mfg$m@AUHQSQL03/publichr")

#from models import hr_db_engine
from sqlalchemy import text

router = APIRouter(
    prefix="/user",
    tags=["user"]
)

def get_boss_info(user_id):
    # 使用with語句管理連線
    try:
        with hr_db_engine.connect() as connection:
            # 建立基本查詢
            query = f"""
                SELECT boss_level, title 
                FROM dbo.emp_data_all_AUGIC 
                WHERE emp_no=:emp_no
            """
            parameters = {"emp_no": user_id}
            result = connection.execute(text(query), parameters).fetchone()
            logger.debug(f"[DB QUERY] Boss info for user {user_id}: {result}")
        return result
    except Exception as e:
        logger.error(f"[DB ERROR] Error querying boss info for {user_id}: {str(e)}")
        return None
            
def parse_uac_xml(xml_str: str) -> dict:
    """
    解析UAC返回的XML數據
    """
    
    if '<?xml' in xml_str:
        xml_str = xml_str[xml_str.find('?>') + 2:]
    
    try:
        root = ET.fromstring(xml_str)
        user_data = {
            'user_id': root.find('UserID').text,
            'name': root.find('Name').text,
            'alias': root.find('Alias').text,
            'dept_no': root.find('DeptNo').text,
            'department_name': root.find('DeptarementName').text,
            'location': root.find('Location').text,
            'auth_key': root.find('Authkey').text,
            'job_title': root.find('Jobtitle').text,
            'class_no': root.find('ClassNo').text,
            'boss_no': root.find('Bossno').text,
            'email': root.find('EMail').text,
            'tel': root.find('Tel').text,
            'return_code': root.find('ReturnCode').text,
            'return_msg': root.find('ReturnMsg').text
        }
        logger.debug(f"[XML PARSE] Parsed user data: {user_data}")
        return user_data
    except Exception as e:
        logger.error(f"[XML PARSE ERROR] Failed to parse XML: {str(e)}")
        raise ValueError(f"XML解析錯誤: {str(e)}")

@router.post("/login")
async def login(request: Request, body=Body(...)):
    logger.info("[LOGIN] Login API called.")

    try:
       
        logger.debug(f"[LOGIN] Raw request body received: {body}")
        body_str = body.decode('utf-8') if isinstance(body, bytes) else str(body)
        parsed_body = parse_qs(body_str, encoding='big5')
        logger.debug(f"[LOGIN] Parsed request body: {parsed_body}")

        
        uac_message = parsed_body.get('uacReturnMessage', [''])[0]
        logger.debug(f"[LOGIN] UAC message received: {uac_message[:100]}...")  # 限制顯示前 100 字元
        user_info = parse_uac_xml(uac_message)

        if user_info['return_code'] != 'Pass':
            logger.warning(f"[LOGIN] Authentication failed for user {user_info['user_id']}: {user_info['return_msg']}")
            return JSONResponse(status_code=401, content={"message": "認證失敗"})

        logger.info(f"[LOGIN] User authenticated successfully: {user_info['alias']} ({user_info['user_id']})")

        boss_info = get_boss_info(user_info['user_id'])
        user_info['boss_level'], user_info['title'] = boss_info if boss_info else (None, None)

        session_user = {
            "employee_id": user_info['user_id'],
            "username": user_info['alias'],
            "name": user_info['name'],
            #"department": user_info['department_name'],
            "dept_no": user_info['dept_no'],
            #"location": user_info['location'],
            "job_title": user_info['job_title'],
            "email": user_info['email'],
            "tel": user_info['tel'].replace(";",""),
            #"boss_level": user_info['boss_level'],
            #"title": user_info['title'],
        }
        request.session["user"] = session_user
        logger.info(f"[LOGIN] Session created for user: {session_user['username']}")

        redirect_url = request.query_params.get('UL', f'http://tw100038735.corpnet.auo.com:{PortNumber}/{HomePage_name}')
        logger.info(f"[LOGIN] Redirecting user to: {redirect_url}")

        return RedirectResponse(url=redirect_url, status_code=303)

    except Exception as e:
        logger.error(f"[LOGIN ERROR] Unexpected error during login: {str(e)}")
        return JSONResponse(
            status_code=400,
            content={
                "message": "登入失敗",
                "error": str(e)
            }
        )
    
@router.get("/user-info")
async def get_user_info(request: Request):
    logger.info("[USER-INFO] Checking user session.")

    user = request.session.get("user")
    if user:
        logger.debug(f"[USER-INFO] User found in session: {user}")
        return user
    else:
        logger.warning("[USER-INFO] No user session found.")
        return JSONResponse(status_code=401, content={"message": "未登入"})

@router.post("/logout")
async def logout(request: Request):
    if "user" in request.session:
        del request.session["user"]
    request.session.clear()

    response = JSONResponse(content={"message": "登出成功"})
    response.delete_cookie("session")  
    return response
