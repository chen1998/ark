from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse
from sqlalchemy import text
from typing import Optional, Dict, List
from datetime import datetime, timedelta
from models.sql_db_connect import MySQLConnet

router = APIRouter()
dbhandler = MySQLConnet('l6a01_project')


class Config:
    def __init__(self):
        # =================== datetime ==========================
        now = datetime.now()
        ym = now.strftime("%Y%m")
        print(f"連線時間: {now}({ym})")
        one_mon_ago = now - timedelta(days=30)
        # ================== 摘要資料表名稱 ========================
        self.aoi_names = [f'aoi{i}00' for i in range(1,4,1)]
        self.all_aoi_summary_tbns = [f'aoi_summary_{n}' for n in self.aoi_names]
        
        self.aoi_name_vs_lineid = { 'CAPIT203': 'aoi_summary_aoi100',
                                'CAAOI202': 'aoi_summary_aoi200',
                                'CAAOI300': 'aoi_summary_aoi300'}
        
        self.all_line_tabs = list(self.aoi_name_vs_lineid.keys())
        
        # ======================= 欄位設定 ========================
        #'run_day', 'scantime', 'line_id', 'model', 'glass_id', 'recipe_id', \
        # 'defect_count', 'over_defect_count', 'large_defect_count', 'middle_defect_count', 'small_defect_count', 'chips', 'sample_image_path'
        self.run_info_keys = ['run_day', 'scantime', 'line_id', 'model', 'glass_id', 'recipe_id', 'chips', 'image_path'] #'sample_image_path'
        self.defect_summary_keys = ['defect_count', 'over_defect_count', 'large_defect_count', 'middle_defect_count', 'small_defect_count'] 
        self.run_info_table_cols = self.run_info_keys + ['defect_summary']
        self.defect_position_keys = ['x', 'y', 'defect_size', 'pic_name']

        #======================= 前端要求參數設定 =====================
        self.run_info_ask_keys = ['dates', 'line_id']

    def summary_table_clean_process(self, tb):
        tb['defect_summary'] = [{key: row[key] for key in self.defect_summary_keys} for _, row in tb.iterrows()]
        if 'sample_image_path' in tb.columns:
            tb['image_path'] = tb['sample_image_path'].tolist()
        return tb[self.run_info_table_cols ]
    
    def get_all_run_info_data(self, dbhandler):
        lines = [f'aoi{i}00' for i in range(1,4,1)]
        all_line_summary = {}
       # aoi_name_vs_line_id = {}
        for tbn in self.all_aoi_summary_tbns:
            tb = dbhandler.get_runs_delta_days(tbn, days=3)
            print(tbn, len(tb))
            line_id = tb['line_id'].unique()[0]
            tb = self.summary_table_clean_process(tb)
            all_line_summary[line_id] = tb.to_dict(orient = 'index')

        return all_line_summary

@router.get("/api/run-info", tags=["run-info"])
async def api_run_info(
    line_id: Optional[str] = Query(default=None),
    start: Optional[str] = Query(default=None, description="YYYY-MM-DD"),
    end: Optional[str] = Query(default=None, description="YYYY-MM-DD"),
):
    cfg = Config()
    
    dbhandler = MySQLConnet('l6a01_project')
    # 根據 request去篩選資料
    if not line_id:
        all_run_info_dict = cfg.get_all_run_info_data(dbhandler)

    else  :
        if line_id in cfg.aoi_name_vs_lineid.keys():
            try:
            #CAPIT203
                aoi_name = cfg.aoi_name_vs_lineid[line_id]
                print(f'請求 {aoi_name} 資料')
                tb = dbhandler.get_runs_between(aoi_name, start, end)
                
                tb = cfg.summary_table_clean_process(tb)

                return {
                    'UniRunInfoTableData':tb.to_dict(orient = 'index'),
                    "AllLineTabs":cfg.all_line_tabs
                    }
                
            except:
                
                print(f'[ERROR] {line_id} 匹配 aoi_summary table失敗')
                return  {
                    'UniRunInfoTableData':{},
                    "AllLineTabs":cfg.all_line_tabs
                    }
            

    return{ 
        "AllRunInfoTableData": all_run_info_dict,
        "AllLineTabs":cfg.all_line_tabs
        }
    

#  === 新增：依 line_id + key 取 Defect 明細 ===
@router.get("/api/defect_data", tags=["run-info"])
async def api_defect_data(line_id: str, key: str):
    """
    key 形式： 'YYYY-MM-DD HH:MM:SS|{glass_id}|{recipe_id}'
    line_id：如 'CAPIT203' / 'CAAOI202' / 'CAAOI300'
    回傳：對應一次量測的所有 defect 座標/影像欄位
    """
    cfg = Config()
    if line_id not in cfg.aoi_name_vs_lineid:
        return JSONResponse({"key": key, "defects": []})
    print(line_id, key)
    # line -> summary_table -> aoi_base（aoi100/aoi200/aoi300） -> 月表
    summary_tbl = cfg.aoi_name_vs_lineid[line_id]
    aoi_base = summary_tbl.replace("aoi_summary_", "")      # aoi200
    """
    try:
        df = dbhandler.get_defects_by_key(aoi_base, key)
        return JSONResponse({
            "key": key,
            "defects": df.to_dict(orient="records")
        })
    except Exception as e:
        print(f"[api/defect_data] error: {e}")
        return JSONResponse({"key": key, "defects": []})
    """