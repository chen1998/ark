// static/js/aoi_density/service.js
(function () {
  const AOI = (window.AOI_DENSITY = window.AOI_DENSITY || {});

  AOI.state = {
    payload: null,
    rows: [],
    uniques: {},
    timeRange: null,
    paramDict: null
  };

  // ---- 時間小工具 ----
  function fmtPiHourToShort(s) {
    if (!s) return "";
    const d = new Date(String(s).replace(" ", "T"));
    if (isNaN(d.getTime())) return String(s);
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const hh = String(d.getHours()).padStart(2, "0");
    return `${yy}-${mm}-${dd} ${hh}`;
  }
  function parsePiHourToDate(s) {
    if (!s) return null;
    if (/^\d{2}-\d{2}-\d{2}\s+\d{2}$/.test(s)) {
      const [datePart, hh] = s.split(/\s+/);
      const [yy, mm, dd] = datePart.split("-").map(Number);
      return new Date(2000 + yy, mm - 1, dd, Number(hh), 0, 0);
    }
    const d = new Date(String(s).replace(" ", "T"));
    return isNaN(d.getTime()) ? null : d;
  }
  function calcTimeRange(rows) {
    if (!rows || !rows.length) return null;
    let min = Infinity, max = -Infinity;
    rows.forEach((r) => {
      const d = parsePiHourToDate(r.pi_hour);
      if (!d) return;
      const t = d.getTime();
      if (t < min) min = t;
      if (t > max) max = t;
    });
    if (min === Infinity) return null;
    return { min: new Date(min), max: new Date(max) };
  }

  // ---- API 參數 ----
  function buildFilterJSON(filters) {
    if (!filters || typeof filters !== "object") return "{}";
    return JSON.stringify(filters);
  }
  function toDatesParam(dates) {
    // FastAPI List[str]：?dates=...&dates=...
    if (!dates || dates.length !== 2) return undefined;
    return dates;
  }

  // ====== 抓資料（只吃 DictData）======
  AOI.fetchAoiDensityData = async function (opts) {
    const dates = opts?.dates && Array.isArray(opts.dates) ? opts.dates : undefined;
    const filters = opts?.filters || {};

    const params = { filter_ask_keys: buildFilterJSON(filters) };
    const datesParam = toDatesParam(dates);
    if (datesParam) params.dates = datesParam;

    const payload = await window.API.get(
      `${window.API_BASE}/aoi_density/api/reset_summary_filter`,
      params
    );

    AOI.state.payload   = payload;
    AOI.state.paramDict = payload?.ParamDict || null;

    // 1) rows：把 DictData 標準化（pi_hour→yy-mm-dd hh、數值轉數字）
    const src = Array.isArray(payload?.DictData) ? payload.DictData : [];
    const rows = src.map(r => ({
      pi_hour: fmtPiHourToShort(r.pi_hour),
      aoi: String(r.aoi || ""),
      pi: String(r.pi || ""),
      line_id: String(r.line_id || ""),
      model: String(r.model || ""),
      glass_type: String(r.glass_type || ""),
      recipe_id: String(r.recipe_id || ""),
      defect_type: String(r.defect_type || ""),
      ai_code_1: String(r.ai_code_1 || ""),
      n_rows: Number(r.n_rows || 0),
      n_glasses: Number(r.n_glasses || 0),
      small_defect_count: Number(r.small_defect_count || 0),
      middle_defect_count: Number(r.middle_defect_count || 0),
      large_defect_count: Number(r.large_defect_count || 0),
      over_defect_count: Number(r.over_defect_count || 0),
      unknown_defect_count: Number(r.unknown_defect_count || 0),
      glass: String(r.glass || "")
    }));

    // 2) uniques：直接用後端提供的 ParamDict.filterOptionDict（不隨篩選縮減）
    const fo = payload?.ParamDict?.filterOptionDict || {};
    AOI.state.uniques = {
      line_id: fo.line_id || [],
      aoi: fo.aoi || [],
      model: fo.model || [],
      glass_type: fo.glass_type || [],
      ai_code_1: fo.ai_code_1 || [],
      defect_size: fo.defect_size || ['S','M','L','O']
    };

    AOI.state.rows = rows;
    AOI.state.timeRange = calcTimeRange(rows);

    document.dispatchEvent(new CustomEvent("aoi_density:data-ready", {
      detail: {
        rows: AOI.state.rows,
        uniques: AOI.state.uniques,
        timeRange: AOI.state.timeRange,
        paramDict: AOI.state.paramDict
      }
    }));

    return payload;
  };

  // ====== 前端過濾（等值 + defect_size 任一尺寸 > 0 + 日期）======
  AOI.getFiltered = function (opts) {
    const rows = AOI.state.rows || [];
    if (!rows.length) return [];

    const filters = (opts && opts.filters) || readFiltersFromUI();
    const dates   = (opts && opts.dates)   || readDatesFromUI();

    // 等值過濾
    const keys = ["line_id", "aoi", "model", "glass_type", "ai_code_1"];
    let out = rows.filter((r) => {
      for (const k of keys) {
        const arr = filters?.[k];
        if (arr && arr.length && !arr.includes(r[k])) return false;
      }
      return true;
    });

    // Defect size（S/M/L/O 任一對應欄位 > 0）
    const sizeMap = { S: "small_defect_count", M: "middle_defect_count", L: "large_defect_count", O: "over_defect_count" };
    if (filters?.defect_size && filters.defect_size.length) {
      const cols = filters.defect_size.map((s) => sizeMap[s]).filter(Boolean);
      if (cols.length) out = out.filter((r) => cols.some((c) => Number(r[c] || 0) > 0));
    }

    // 日期（以「yy-mm-dd hh」→ Date）
    if (dates && dates.length === 2) {
      const b = new Date(dates[0] + "T00:00:00");
      const e = new Date(dates[1] + "T23:59:59");
      const tb = b.getTime(), te = e.getTime();
      out = out.filter((r) => {
        const t = parsePiHourToDate(r.pi_hour)?.getTime();
        return typeof t === "number" && t >= tb && t <= te;
      });
    }
    return out;
  };

  // ---- 從 UI 讀取條件（id 全改成 aoi_density-*）----
  function readDatesFromUI() {
    const b = document.querySelector("#aoi_densityStart");
    const e = document.querySelector("#aoi_densityEnd");
    const begin = b && b.value ? b.value : undefined;
    const end   = e && e.value ? e.value : undefined;
    return (begin && end) ? [begin, end] : undefined;
  }
  function readMultiSelectValues(id) {
    const el = document.getElementById(id);
    if (!el) return [];
    if (el.tagName === "SELECT" && el.multiple) {
      return Array.from(el.selectedOptions).map((o) => o.value).filter(Boolean);
    }
    return [];
  }
  function readFiltersFromUI() {
    return {
      line_id: readMultiSelectValues("line-id"),
      aoi: readMultiSelectValues("aoi-id"),
      model: readMultiSelectValues("model-id"),
      glass_type: readMultiSelectValues("glass-type"),
      ai_code_1: readMultiSelectValues("defect-code"),
      defect_size: readMultiSelectValues("defect-size")
    };
  }
})();