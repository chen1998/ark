// static/js/run_sheet_table.js
(function(){
  let allRows = [];
  let sortKey = null;
  const asDate = (str)=> new Date(str.replace(' ','T'));

  // 保證 State 結構
  window.State = window.State || {};
  State.filters      = State.filters      || {dateFrom:'', dateTo:'', recipeOrSheet:''};
  State.subFilter    = State.subFilter    || {types:new Set(), sizes:new Set()};
  State.selectedKeys = State.selectedKeys || []; // 最多兩筆

  function passFilters(rows){
    const f = State.filters;
    let r = rows.slice();
    if(f.dateFrom){ r = r.filter(x => asDate(x.measure_time) >= new Date(f.dateFrom)); }
    if(f.dateTo){   r = r.filter(x => asDate(x.measure_time) <= new Date(f.dateTo+'T23:59:59')); }
    if(f.recipeOrSheet){
      const q = f.recipeOrSheet.toLowerCase();
      r = r.filter(x => x.recipe_id.toLowerCase().includes(q) || x.sheet_id.toLowerCase().includes(q));
    }
    // 若已選第一筆 → 只顯示同 sheet
    if(State.selectedKeys.length>=1){
      const r1 = LR.rowForKey(State.selectedKeys[0]);
      if(r1) r = r.filter(x => x.sheet_id === r1.sheet_id);
    }
    return r;
  }

  function updateStats(rows){
    const el = document.getElementById('run-stats');
    if(!el) return;
    const badges = el.querySelectorAll(".badge b");
    if(badges.length >= 2){
      badges[0].textContent = rows.length;
      badges[1].textContent = new Set(rows.map(r=>r.sheet_id)).size;
    }
  }

  function renderSelectionSummary(){
    const el = document.getElementById('selection-summary');
    if(!el) return;
    const [kA, kB] = State.selectedKeys;
    const fmt = (k, label)=>{
      if(!k) return `<div class="sel-card empty">${label}：未選</div>`;
      const r = LR.rowForKey(k);
      if(!r) return `<div class="sel-card empty">${label}：無資料</div>`;
      return `<div class="sel-card"><b>${label}</b>｜${r.measure_time}｜Sheet:${r.sheet_id}｜Recipe:${r.recipe_id}</div>`;
    };
    el.innerHTML = fmt(kA,'第一筆') + fmt(kB,'第二筆');
  }

  // 勾選後：顯示 Run 選取影像（雙槽）
  function renderRunSelectedImages(){
    const cont = document.getElementById('run-selected-images');
    if(!cont) return;
    const imgTop = cont.querySelector('#run-img-top img');
    const imgBot = cont.querySelector('#run-img-bottom img');

    const [kA, kB] = State.selectedKeys;
    if(!kA && !kB){
      cont.classList.add('hidden');
      imgTop && (imgTop.src = '');
      imgBot && (imgBot.src = '');
      return;
    }

    // 有選取 → 顯示容器
    cont.classList.remove('hidden');
    const urlA = kA ? (LR.imageForKey(kA) || `https://placehold.co/640x360?text=Run+Sel+1`) : '';
    const urlB = kB ? (LR.imageForKey(kB) || `https://placehold.co/640x360?text=Run+Sel+2`) : '';

    if(imgTop) imgTop.src = urlA || '';
    if(imgBot) imgBot.src = urlB || '';
  }

  function renderTable(rows){
    const cont  = document.querySelector('#run-sheet-table-container');
    if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-tbody');
    thead.innerHTML = ""; tbody.innerHTML = "";

    // thead
    const trHead = document.createElement("tr");
    [
      {text:"選"},{text:"時間",sort:"time"},{text:"Recipe",sort:"recipe"},
      {text:"Sheet",sort:"sheet"},{text:"Chip"},{text:"Lot"}
    ].forEach(col=>{
      const th = document.createElement("th");
      th.textContent = col.text;
      if(col.sort){
        const span = document.createElement("span");
        span.className = "sort-btn";
        span.dataset.sort = col.sort;
        span.textContent = "↕";
        th.appendChild(document.createTextNode(" "));
        th.appendChild(span);
      }
      trHead.appendChild(th);
    });
    thead.appendChild(trHead);

    // tbody
    rows.forEach(r=>{
      const tr  = document.createElement("tr");
      const key = LR.makeKey(r);

      tr.dataset.measure_time = r.measure_time;
      tr.dataset.sheet_id     = r.sheet_id;
      tr.dataset.recipe_id    = r.recipe_id;
      tr.dataset.key          = key;

      const selected = State.selectedKeys.includes(key);
      if(selected) tr.classList.add('selected');

      const tdSel = document.createElement("td");
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.className = "sel";
      cb.checked = selected;
      tdSel.appendChild(cb); tr.appendChild(tdSel);

      [r.measure_time, r.recipe_id, r.sheet_id, r.chip, r.lot_id].forEach(val=>{
        const td = document.createElement("td"); td.textContent = val; tr.appendChild(td);
      });

      function toggle(wantChecked){
        const exists = State.selectedKeys.includes(key);
        if(wantChecked){
          if(exists) return true;
          if(State.selectedKeys.length>=2){ alert('最多選兩筆做比對'); return false; }
          State.selectedKeys.push(key);
        }else{
          if(!exists) return true;
          State.selectedKeys = State.selectedKeys.filter(k=>k!==key);
        }
        // 只剩一筆就自然成為第一筆（陣列只有一個元素）
        Bus.emit('compare-selection-changed', [...State.selectedKeys]);
        return true;
      }

      tr.addEventListener('click',(ev)=>{
        if(ev.target && ev.target.classList.contains('sel')) return;
        cb.checked = !cb.checked;
        if(!toggle(cb.checked)) cb.checked = !cb.checked;
      });
      cb.addEventListener('change', ()=>{
        if(!toggle(cb.checked)){ cb.checked = !cb.checked; return; }
        tr.classList.toggle('selected', cb.checked);
      });

      tbody.appendChild(tr);
    });

    // 排序
    thead.querySelectorAll(".sort-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const t = btn.dataset.sort;
        sortKey = t;
        if(t==="time")   rows.sort((a,b)=> asDate(b.measure_time)-asDate(a.measure_time));
        if(t==="recipe") rows.sort((a,b)=> a.recipe_id.localeCompare(b.recipe_id));
        if(t==="sheet")  rows.sort((a,b)=> a.sheet_id.localeCompare(b.sheet_id));
        renderTable(rows);
      });
    });

    updateStats(rows);
    renderSelectionSummary();
    renderRunSelectedImages(); // 勾選後更新雙槽影像
  }

  // 初始化
  Bus.on('init-data', ({mock})=>{
    allRows = mock.run_sheet_list || [];
    renderTable(passFilters(allRows));
  });

  // 外層 filter 改變
  Bus.on('filters-changed', ()=>{
    const rows = passFilters(allRows);
    if(sortKey==="time")   rows.sort((a,b)=> asDate(b.measure_time)-asDate(a.measure_time));
    if(sortKey==="recipe") rows.sort((a,b)=> a.recipe_id.localeCompare(b.recipe_id));
    if(sortKey==="sheet")  rows.sort((a,b)=> a.sheet_id.localeCompare(b.sheet_id));
    renderTable(rows);
  });

  // 勾選變更 → 重新渲染（為了同 sheet 濾表 & 下方雙槽影像）
  Bus.on('compare-selection-changed', ()=>{
    const rows = passFilters(allRows);
    if(sortKey==="time")   rows.sort((a,b)=> asDate(b.measure_time)-asDate(a.measure_time));
    if(sortKey==="recipe") rows.sort((a,b)=> a.recipe_id.localeCompare(b.recipe_id));
    if(sortKey==="sheet")  rows.sort((a,b)=> a.sheet_id.localeCompare(b.sheet_id));
    renderTable(rows);
  });
})();