// static/js/defect_image_viewer.js
(function(){
  const paneA = document.getElementById('imgA');
  const paneB = document.getElementById('imgB');

  function render(){
    const keys = State.selectedRows || [];
    const kA = keys[0], kB = keys[1];

    if(paneA){
      const urlA = kA ? LR.imageForKey(kA) : null;
      paneA.src = urlA || 'https://placehold.co/600x360?text=No+Image+A';
    }
    if(paneB){
      const urlB = kB ? LR.imageForKey(kB) : null;
      paneB.src = urlB || 'https://placehold.co/600x360?text=No+Image+B';
    }
  }

  document.querySelectorAll('.img-reset').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      render(); // 簡化：直接重設為原圖
    });
  });

  Bus.on('init-data', render);
  Bus.on('compare-selection-changed', render);
})();
