(function (global) {
  const ns = global.AIDI = global.AIDI || {};

  ns.state = ns.state || {};
  ns.state.full = ns.state.full || {};
  ns.state.mdd = ns.state.mdd || {}; // will be filled by filter.js

  // ---------- helpers ----------
  const API_BASE = ""; // same origin
  function hourStr(ts) {
    // input like "2025-09-17 12:00:00" or "2025-09-17 12"
    if (!ts) return "";
    const s = ("" + ts).trim().replace("T", " ");
    // return "yy-mm-dd hh"
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2})/);
    if (!m) return s;
    const yy = m[1].slice(2);
    return `${yy}-${m[2]}-${m[3]} ${m[4]}`;
  }
  function uniq(arr) {
    return Array.from(new Set(arr.filter(Boolean))).sort();
  }

  // Transform backend payload -> AIDI.state.full expected by UI modules
  function normalizePayload(payload) {
    const chart = payload?.ChartDataDict || {};
    const series = [];
    const lineSet = new Set();
    const aoiSet = new Set();
    const modelSet = new Set();
    const codeSet = new Set();
    const timeSet = new Set();

    for (const line_id of Object.keys(chart)) {
      const L1 = chart[line_id] || {};
      lineSet.add(line_id);
      for (const aoi_id of Object.keys(L1)) {
        const L2 = L1[aoi_id] || {};
        aoiSet.add(aoi_id);
        for (const model_id of Object.keys(L2)) {
          const L3 = L2[model_id] || {};
          modelSet.add(model_id);
          for (const glass_type of Object.keys(L3)) {
            const L4 = L3[glass_type] || {};
            for (const defect_code of Object.keys(L4)) {
              const L5 = L4[defect_code] || {};
              for (const tkey of Object.keys(L5)) {
                const v = L5[tkey] || {};
                // make one row
                const row = {
                  line_id,
                  aoi_id,
                  model_id,
                  glass_type,
                  defect_code,
                  defect_type: v.defect_type || "",
                  time: hourStr(tkey),
                  n_rows: v.n_rows|0,
                  n_glasses: v.n_glasses|0,
                  small_defect_count: v.small_defect_count|0,
                  middle_defect_count: v.middle_defect_count|0,
                  large_defect_count: v.large_defect_count|0,
                  over_defect_count: v.over_defect_count|0,
                  unknown_defect_count: v.unknown_defect_count|0,
                  glass: v.glass || ""
                };
                series.push(row);
                codeSet.add(defect_code);
                timeSet.add(row.time);
              }
            }
          }
        }
      }
    }

    series.sort((a,b) => a.time.localeCompare(b.time));

    const full = {
      filters: {
        line_ids: uniq(Array.from(lineSet)),
        aoi_ids: uniq(Array.from(aoiSet)),
        models: uniq(Array.from(modelSet)),
        defect_codes: uniq(Array.from(codeSet))
      },
      time_bins: uniq(Array.from(timeSet)),
      series: series
    };

    return full;
  }

  // fetch summary data
  ns.fetchAIDIData = async function(opts) {
    const params = new URLSearchParams();
    if (opts?.dates && Array.isArray(opts.dates) && opts.dates.length === 2) {
      params.append("dates", opts.dates[0]);
      params.append("dates", opts.dates[1]);
    }
    if (opts?.filters && Object.keys(opts.filters).length > 0) {
      params.append("filter_ask_keys", JSON.stringify(opts.filters));
    }
    const url = `/api/reset_summary_filter?${params.toString()}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`${url} 失敗`);
    }
    const payload = await res.json();
    const full = normalizePayload(payload);
    ns.state.full = full;
    ns.state.payloadRaw = payload; // keep original
    // expose series for charts3.js compatibility
    ns.series = full.series;
    return full;
  };

  // apply filters (MultiDD + date range) -> filtered array for charts/table
  ns.getFiltered = function() {
    const s = ns.state;
    let arr = (s.full?.series || []).slice();

    const mdd = s.mdd || {};
    const sel = (key) => (mdd[key] && mdd[key].getSelected ? mdd[key].getSelected() : []);

    const fLine = sel("line_ids");
    const fAoi  = sel("aoi_ids");
    const fModel= sel("models");
    const fCode = sel("defect_codes");

    if (fLine.length) arr = arr.filter(r => fLine.includes(r.line_id));
    if (fAoi.length)  arr = arr.filter(r => fAoi.includes(r.aoi_id));
    if (fModel.length)arr = arr.filter(r => fModel.includes(r.model_id));
    if (fCode.length) arr = arr.filter(r => fCode.includes(r.defect_code));

    // date range from inputs
    const ib = document.getElementById("date-begin");
    const ie = document.getElementById("date-end");
    const begin = ib && ib.value ? ns.parseHour(ib.value) : -Infinity;
    const end   = ie && ie.value ? ns.parseHour(ie.value) : Infinity;

    arr = arr.filter(r => {
      const t = ns.parseHour(r.time);
      return t >= begin && t <= end;
    });

    return arr;
  };

})(window);