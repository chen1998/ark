// charts.js — Tableau 風格分面圖 (ECharts)
// Facet：Row = line_id × model_id，Col = aoi_id × defect_code
// Plot：bar(orange)=glass_count (yLeft，ticks 每 5)，scatter(blue)=density (yRight)，x=bytimehour
// 特色：單一底部時間軸；面板寬度自適應填滿 #aidi-charts

(function () {
  const ns = (window.AIDI = window.AIDI || {});

  // 便利方法
  ns.qs = ns.qs || ((sel, el = document) => el.querySelector(sel));
  ns.qsa = ns.qsa || ((sel, el = document) => Array.from(el.querySelectorAll(sel)));

  // 時間處理
  function parseHour(s) {
    if (!s) return null;
    const t = (s + "").slice(0, 13); // 'YYYY-MM-DD HH'
    const d = new Date(t.replace(" ", "T") + ":00:00");
    return isNaN(+d) ? null : d;
  }
  const pad2 = (n) => (n < 10 ? "0" + n : "" + n);
  const fmtHour = (d) =>
    d instanceof Date
      ? `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}`
      : "";

  // 顏色（只定義兩個重點色；其餘走主題）
  const ORANGE = "#FFA03A";
  const BLUE = "#4EA1FF";

  // 主入口
  ns.renderCharts = function () {
    // 容器（先嘗試 #aidi-facet，否則掛在 #aidi-charts）
    const host =
      ns.qs("#aidi-facet") || ns.qs("#aidi-charts") || ns.qs("#aidi-facet");
    if (!host) return;

    const data = ns.getFiltered ? ns.getFiltered() : [];
    host.innerHTML = "";
    if (!data || !data.length) {
      host.textContent = "（無資料）";
      return;
    }

    // === Facet 維度 ===
    const uniq = (arr) => Array.from(new Set(arr)).filter((v) => v != null);
    const lines = uniq(data.map((d) => d.line_id)).sort();
    const rowFacets = [];
    lines.forEach((line) => {
      const models = uniq(
        data.filter((d) => d.line_id === line).map((d) => d.model_id)
      ).sort();
      models.forEach((m) => rowFacets.push({ line_id: line, model_id: m }));
    });

    const aois = uniq(data.map((d) => d.aoi_id)).sort();
    const colFacets = [];
    aois.forEach((a) => {
      const codes = uniq(
        data.filter((d) => d.aoi_id === a).map((d) => d.defect_code)
      ).sort();
      codes.forEach((c) => colFacets.push({ aoi_id: a, defect_code: c }));
    });

    // 單一全域時間軸（bytimehour）
    const timeKeys = uniq(data.map((d) => (d.bytimehour || "").slice(0, 13))).sort();
    const timeDates = timeKeys.map(parseHour).filter(Boolean).sort((a, b) => a - b);
    const timeLabels = timeDates.map(fmtHour); // 'YYYY-MM-DD HH'

    // === 對齊資料到每個格子（row×col） ===
    const pKey = (r) =>
      `${r.line_id}__${r.model_id}__${r.aoi_id}__${r.defect_code}`;
    const panelMap = new Map(); // key -> {bars:Array(len T), dots:Array(len T)}

    // 預建所有格子
    rowFacets.forEach((rf) => {
      colFacets.forEach((cf) => {
        panelMap.set(pKey({ ...rf, ...cf }), {
          bars: new Array(timeLabels.length).fill(0),
          dots: new Array(timeLabels.length).fill(0),
        });
      });
    });

    // 填資料
    data.forEach((r) => {
      const k = pKey(r);
      const pm = panelMap.get(k);
      if (!pm) return;
      const idx = timeLabels.indexOf((r.bytimehour || "").slice(0, 13));
      if (idx < 0) return;
      pm.bars[idx] = Number(r.glass_count) || 0;
      pm.dots[idx] = Number(r.density) || 0;
    });

    // yLeft（glass_count）範圍：取全域最大，進位至 5 的倍數
    const maxGC =
      Math.max(1, ...Array.from(panelMap.values()).map((v) => Math.max(...v.bars, 0))) || 1;
    const maxGC5 = Math.ceil(maxGC / 5) * 5; // 例如 23 -> 25
    // yRight（density）：取全域最大
    const maxDN =
      Math.max(1, ...Array.from(panelMap.values()).map((v) => Math.max(...v.dots, 0))) || 1;

    // === 佈局尺寸：動態計算讓寬度填滿 ===
    const chartsHost = ns.qs("#aidi-charts") || host;
    const hostW = Math.max(600, chartsHost.clientWidth || host.clientWidth || 900);
    const gap = 12;
    const leftLabelW = 150;
    const topLabelH = 26;
    const cols = Math.max(1, colFacets.length);
    const panelW = Math.max(
      180,
      Math.floor((hostW - leftLabelW - (cols - 1) * gap) / cols)
    );
    const panelH = 160;

    // 整個 Facet 容器
    const facetDiv = document.createElement("div");
    facetDiv.className = "facet-root";
    facetDiv.style.width = "100%";
    facetDiv.style.height = "100%";
    host.appendChild(facetDiv);

    const chart = echarts.init(facetDiv, null, { renderer: "canvas" });

    const grids = [];
    const xAxes = [];
    const yAxes = [];
    const series = [];
    const graphics = [];

    // 上側欄頭
    colFacets.forEach((cf, ci) => {
      const x = leftLabelW + ci * (panelW + gap) + panelW / 2;
      graphics.push({
        type: "text",
        top: 2,
        left: x,
        style: {
          text: `${cf.aoi_id} / ${cf.defect_code}`,
          fill: "#cfd7df",
          textAlign: "center",
          fontSize: 12,
          fontWeight: 600,
        },
      });
    });

    // 左側列頭
    rowFacets.forEach((rf, ri) => {
      const y = topLabelH + ri * (panelH + gap) + panelH / 2;
      graphics.push({
        type: "text",
        top: y,
        left: 0,
        style: {
          text: `${rf.line_id}  ${rf.model_id}`,
          fill: "#cfd7df",
          textAlign: "left",
          fontSize: 12,
          fontWeight: 600,
        },
      });
    });

    // === 生成每個小面板的 grid + 雙 y 軸 + series（x 軸藏起來以顯示單一全域 x 軸） ===
    rowFacets.forEach((rf, ri) => {
      colFacets.forEach((cf, ci) => {
        const gridIndex = grids.length;
        grids.push({
          left: leftLabelW + ci * (panelW + gap),
          top: topLabelH + ri * (panelH + gap),
          width: panelW,
          height: panelH,
          containLabel: false,
        });

        // 隱藏的分類 x 軸（用來定位資料；不顯示刻度與標籤）
        xAxes.push({
          type: "category",
          gridIndex,
          data: timeLabels,
          axisLabel: { show: false },
          axisTick: { show: false },
          axisLine: { show: false },
          splitLine: { show: false },
        });

        // yLeft: glass_count（tick 間距 5，從 0 到 maxGC5）
        yAxes.push({
          type: "value",
          gridIndex,
          min: 0,
          max: maxGC5,
          interval: 5,
          axisLabel: { fontSize: 10 }, // 0,5,10,...
          axisTick: { show: false },
          axisLine: { show: false },
          splitLine: { show: true, lineStyle: { opacity: 0.12 } },
        });

        // yRight：density（共用同一範圍；我們重用 gridIndex，ECharts 自會匹配）
        yAxes.push({
          type: "value",
          gridIndex,
          min: 0,
          max: maxDN * 1.1,
          position: "right",
          axisLabel: { fontSize: 10 },
          axisTick: { show: false },
          axisLine: { show: false },
          splitLine: { show: false },
        });

        const pm = panelMap.get(pKey({ ...rf, ...cf })) || {
          bars: new Array(timeLabels.length).fill(0),
          dots: new Array(timeLabels.length).fill(0),
        };

        // bar：glass_count（橘）
        series.push({
          name: "glass_count",
          type: "bar",
          xAxisIndex: gridIndex,
          yAxisIndex: gridIndex * 2, // 左軸在 yAxes 中的位置：每格 2 個（左+右）
          data: pm.bars,
          barWidth: Math.max(
            4,
            Math.min(18, Math.floor(panelW / Math.max(8, timeLabels.length)))
          ),
          itemStyle: { color: ORANGE },
          emphasis: { itemStyle: { opacity: 0.9 } },
          _facet: { ...rf, ...cf },
        });

        // scatter：density（藍）
        series.push({
          name: "density",
          type: "scatter",
          xAxisIndex: gridIndex,
          yAxisIndex: gridIndex * 2 + 1, // 右軸
          data: pm.dots,
          symbol: "circle",
          symbolSize: 6,
          itemStyle: { color: BLUE },
          emphasis: { itemStyle: { opacity: 0.9 } },
          _facet: { ...rf, ...cf },
        });
      });
    });

    // === 追加一個「底部整寬」grid 只畫全域時間軸（單一 x 軸） ===
    const bottomGridIndex = grids.length;
    grids.push({
      left: leftLabelW,
      top:
        topLabelH +
        rowFacets.length * (panelH + gap) -
        2 +
        8, // 小位移讓軸不貼太緊
      width: colFacets.length * panelW + Math.max(0, colFacets.length - 1) * gap,
      height: 28,
      containLabel: false,
    });
    xAxes.push({
      type: "category",
      gridIndex: bottomGridIndex,
      data: timeLabels,
      axisLabel: {
        interval: Math.max(0, Math.floor(timeLabels.length / 6) - 1),
        formatter: (v) => v.slice(5), // MM-DD HH
        rotate: 80,
        fontSize: 10,
      },
      axisTick: { show: false },
      axisLine: { lineStyle: { opacity: 0.35 } },
      splitLine: { show: false },
    });
    // 這個底部 grid 不需要 y 軸，推一個隱藏的 placeholder
    yAxes.push({
      type: "value",
      gridIndex: bottomGridIndex,
      show: false,
      min: 0,
      max: 1,
    });

    // === Option ===
    chart.setOption(
      {
        animation: false,
        backgroundColor: "transparent",
        grid: grids,
        xAxis: xAxes,
        yAxis: yAxes,
        graphic: graphics,
        legend: [
          {
            orient: "horizontal",
            left: leftLabelW,
            top: 0,
            icon: "rect",
            itemWidth: 14,
            itemHeight: 10,
            textStyle: { fontSize: 12 },
            data: ["glass_count", "density"],
          },
        ],
        tooltip: {
          trigger: "item",
          confine: true,
          formatter: (p) => {
            const meta = p.series?._facet || {};
            const idx = p.dataIndex;
            const hr = timeLabels[idx] || "";
            if (p.seriesName === "glass_count") {
              return [
                `${meta.line_id} / ${meta.model_id}`,
                `${meta.aoi_id} / ${meta.defect_code}`,
                `時間：${hr}:00`,
                `glass_count：<b>${p.data}</b>`,
              ].join("<br>");
            }
            return [
              `${meta.line_id} / ${meta.model_id}`,
              `${meta.aoi_id} / ${meta.defect_code}`,
              `時間：${hr}:00`,
              `density：<b>${(p.data || 0).toFixed ? p.data.toFixed(3) : p.data}</b>`,
            ].join("<br>");
          },
        },
        series,
      },
      true
    );

    // 點擊互動
    chart.off("click");
    chart.on("click", function (p) {
      if (!p || !p.seriesName) return;
      if (p.seriesName !== "glass_count" && p.seriesName !== "density") return;

      const meta = p.series?._facet || {};
      const hourStr = (timeLabels[p.dataIndex] || "") + ":00";
      const line = meta.line_id,
        model = meta.model_id,
        aoi = meta.aoi_id,
        code = meta.defect_code;

      if (ns.quickFilter) ns.quickFilter({ line, model, aoi, code, time: parseHour(hourStr) });

      const codeSel = ns.getSel ? ns.getSel("aidiCode") : [];
      const payload = { time: hourStr, line_id: line, aoi_id: aoi, model_id: model, defect_codes: codeSel };
      if (ns.fetchHourlyPoints) {
        ns.fetchHourlyPoints(payload)
          .then(({ points }) => {
            if (!ns._miniMap && ns.MiniMap) ns._miniMap = new ns.MiniMap("#aidi-mini-map");
            if (ns._miniMap) {
              const xs = (points || []).map((q) => q.x);
              const ys = (points || []).map((q) => q.y);
              const bbox =
                points && points.length
                  ? { xmin: Math.min(...xs), xmax: Math.max(...xs), ymin: Math.min(...ys), ymax: Math.max(...ys) }
                  : null;
              ns._miniMap.setData(points || [], bbox);
            }
          })
          .catch(console.error);
      }
    });

    // 自適應（重新計算 panel 寬度）
    const onResize = () => {
      // 直接重新 render 讓 panelW 依容器重算
      ns.renderCharts();
    };
    // 先解除可能重複的 listener
    if (ns._chartsResizeHandler) window.removeEventListener("resize", ns._chartsResizeHandler);
    ns._chartsResizeHandler = onResize;
    window.addEventListener("resize", onResize);
  };
})();


