// static/js/defect_list.js — 多筆 Defect Tables（兩欄並排）+ 縮圖 + 畫廊
(function(){
  const contId   = 'defect-lists-container';
  const countId  = 'dl-count';
  const galleryId= 'gallery-grid';

  // 建立單一 table（含縮圖）
  function buildTableForKey(key, defects, imgBase){
    const { scantime, glass_id, recipe_id } = Utils.parseKey(key);

    const wrap = document.createElement('div');
    wrap.className = 'defect-table-wrap';

    const title = document.createElement('div');
    title.className = 'defect-table-title';
    title.textContent = `${scantime} ｜ ${glass_id} ｜ ${recipe_id}`;
    wrap.appendChild(title);

    const tbl = document.createElement('table');
    tbl.className = 'table defect-table';
    const thead = document.createElement('thead');
    const trh = document.createElement('tr');
    // ⚠ 你原本用 col.text，col 是字串會變 undefined，這裡改為直接塞字串
    ['x', 'y', 'size', 'type', 'chip', 'image'].forEach(label=>{
      const th = document.createElement('th');
      th.textContent = label;
      trh.appendChild(th);
    });
    thead.appendChild(trh);
    tbl.appendChild(thead);

    const tbody = document.createElement('tbody');

    (defects || []).forEach(d=>{
      const tr = document.createElement('tr');

      const x    = d.x ?? '';
      const y    = d.y ?? '';
      const size = d.size ?? d.defect_size ?? '';
      const type = d.type ?? d.predict_code ?? '';
      const chip = d.chip ?? d.chip_name ?? '';

      const file = d.img || d.pic_name || '';
      //console.log('file',file);
      const src  = (imgBase || '') + (file || '') + ((file.includes('.jpg') || file.includes('.JPG')) ? '':'.jpg');
      //console.log('src',src);

      tr.innerHTML = `
        <td>${x}</td>
        <td>${y}</td>
        <td>${size}</td>
        <td>${type}</td>
        <td>${chip}</td>
        <td class="img-cell">${file ? `<img loading="lazy" src="${src}" alt="">` : ''}</td>
      `;

      // 點列 → 丟到下方畫廊
      tr.addEventListener('click', ()=>{
        //console.log( src);
        //console.log(src, `${glass_id} ${recipe_id} @ ${scantime}`)
        if(!file) return;
        addToGallery(src, `${glass_id} ${recipe_id} @ ${scantime}`);
      });

      tbody.appendChild(tr);
    });

    tbl.appendChild(tbody);
    wrap.appendChild(tbl);
    return wrap;
  }

  function addToGallery(src, title){
    const grid = document.getElementById(galleryId);
    if(!grid || !src) return;
    const fig = document.createElement('figure');
    fig.className = 'gallery-item';
    fig.innerHTML = `
      <img loading="lazy" src="${src}" alt="">
      <figcaption>${title || ''}</figcaption>
    `;
    grid.appendChild(fig);
  }

  // 重新渲染所有選取的 keys
  function renderAll(){
    const cont = document.getElementById(contId);
    if(!cont) return;
    cont.innerHTML = '';

    const keys = State.selectedKeys.slice();
    keys.forEach(k=>{
      const nkey    = Utils.normalizeKey(k);
      const defects = State.DefectCache[nkey] || State.DefectCache[k] || [];
      const imgBase = State.imgBaseByKey[nkey] || State.imgBaseByKey[k] || '';
      cont.appendChild(buildTableForKey(nkey, defects, imgBase));
    });

    const c = document.getElementById(countId);
    if(c) c.textContent = String(keys.length);
  }

  // 收到 API 回來的缺陷資料
  Bus.on('defect-refresh', () => renderAll());
  // 勾選改變也重畫
  Bus.on('selection-changed', () => renderAll());

  // 清空畫廊
  function clearGallery(){
    const grid = document.getElementById(galleryId);
    if(grid) grid.innerHTML = '';
  }
  const btn1 = document.getElementById('btnClearGallery');
  const btn2 = document.getElementById('btnClearGallery2');
  if(btn1) btn1.addEventListener('click', clearGallery);
  if(btn2) btn2.addEventListener('click', clearGallery);
})();