// static/js/run_sheet_table.js
(function(){
  let allRows = [];
  let sortKey = null;

  function asDate(str){ return new Date(str.replace(' ','T')); }

  function passFilters(rows){
    const f = State.filters;
    let r = rows.slice();
    if(f.dateFrom){ r = r.filter(x => asDate(x.measure_time) >= new Date(f.dateFrom)); }
    if(f.dateTo){   r = r.filter(x => asDate(x.measure_time) <= new Date(f.dateTo + 'T23:59:59')); }
    if(f.recipeOrSheet){
      const q = f.recipeOrSheet.toLowerCase();
      r = r.filter(x => x.recipe_id.toLowerCase().includes(q) || x.sheet_id.toLowerCase().includes(q));
    }
    return r;
  }

  function updateStats(rows){
    const el = document.getElementById('run-stats');
    if(!el) return;
    const badges = el.querySelectorAll(".badge b");
    if(badges.length >= 2){
      badges[0].textContent = rows.length;
      badges[1].textContent = new Set(rows.map(r=>r.sheet_id)).size;
    }
  }

  // 以 key 決定是否已選
  function isKeySelected(key){
    const sel = State.selectedRows || [];
    return sel.includes(key);
  }

  function tryToggleSelection(key, checked, tr){
    const sel = State.selectedRows;

    if(checked){
      if(sel.length >= 2){
        toast('最多選兩筆做比對');
        return false;
      }
      if(!sel.includes(key)) sel.push(key);
      tr.classList.add('selected');
    }else{
      const idx = sel.indexOf(key);
      if(idx >= 0) sel.splice(idx,1);
      tr.classList.remove('selected');
    }

    Bus.emit('compare-selection-changed', [...sel]);
    return true;
  }

  function renderTable(rows){
    const cont  = document.querySelector('#run-sheet-table-container');
    if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-tbody');
    thead.innerHTML = ""; tbody.innerHTML = "";

    // thead
    const trHead = document.createElement("tr");
    const headCols = [
      {text:"選"},
      {text:"時間",  sort:"time"},
      {text:"Recipe",sort:"recipe"},
      {text:"Sheet", sort:"sheet"},
      {text:"Chip"},
      {text:"Lot"}
    ];
    headCols.forEach(col=>{
      const th = document.createElement("th");
      th.textContent = col.text;
      if(col.sort){
        const span = document.createElement("span");
        span.className = "sort-btn";
        span.dataset.sort = col.sort;
        span.textContent = "↕";
        th.appendChild(document.createTextNode(" "));
        th.appendChild(span);
      }
      trHead.appendChild(th);
    });
    thead.appendChild(trHead);

    // tbody
    rows.forEach((r, idx)=>{
      const tr = document.createElement("tr");
      tr.dataset.idx = String(idx);
      const key = LR.makeKey(r);

      const selected = isKeySelected(key);
      if(selected) tr.classList.add('selected');

      // checkbox
      const tdSel = document.createElement("td");
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.className = "sel";
      cb.checked = selected;
      cb.dataset.key = key;
      tdSel.appendChild(cb);
      tr.appendChild(tdSel);

      // 欄位
      [ r.measure_time, r.recipe_id, r.sheet_id, r.chip, r.lot_id ].forEach(val=>{
        const td = document.createElement("td");
        td.textContent = val;
        tr.appendChild(td);
      });

      // 點整列也能切換
      tr.addEventListener('click', (ev)=>{
        if(ev.target && ev.target.classList.contains('sel')) return;
        cb.checked = !cb.checked;
        tr.dispatchEvent(new Event('change'));
      });

      tr.addEventListener('change', ()=>{
        const ok = tryToggleSelection(key, cb.checked, tr);
        if(!ok) cb.checked = false;
      });

      tbody.appendChild(tr);
    });

    // 排序
    thead.querySelectorAll(".sort-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const t = btn.dataset.sort;
        sortKey = t;
        if(t==="time")   rows.sort((a,b)=> asDate(b.measure_time) - asDate(a.measure_time));
        if(t==="recipe") rows.sort((a,b)=> a.recipe_id.localeCompare(b.recipe_id));
        if(t==="sheet")  rows.sort((a,b)=> a.sheet_id.localeCompare(b.sheet_id));
        renderTable(rows);
      });
    });

    updateStats(rows);
  }

  // 初始化與篩選刷新
  Bus.on('init-data', ({mock})=>{
    allRows = mock.run_sheet_list || [];
    renderTable(passFilters(allRows));
  });

  Bus.on('filters-changed', ()=>{
    const rows = passFilters(allRows);
    if(sortKey==="time")   rows.sort((a,b)=> asDate(b.measure_time)-asDate(a.measure_time));
    if(sortKey==="recipe") rows.sort((a,b)=> a.recipe_id.localeCompare(b.recipe_id));
    if(sortKey==="sheet")  rows.sort((a,b)=> a.sheet_id.localeCompare(b.sheet_id));
    renderTable(rows);
  });
})();

