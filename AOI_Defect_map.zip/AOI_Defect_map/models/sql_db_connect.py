# %%
import pandas as pd
import logging
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError
import pymysql
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# %%
# 設定 logging
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler("db_handler.log"),  # 記錄到檔案
        logging.StreamHandler()                 # 同時輸出到終端
    ]
)


# %%
class MySQLConnet:
    def __init__(self, dbname):
        self.db = dbname
        host = "10.97.142.217"
        username = "l6a01_user"
        password = "l6a01$user"
        self.engine = create_engine(f"mysql+pymysql://{username}:{password}@{host}/{dbname}")

    def list_tables(self):
        try:
            inspector = inspect(self.engine)
            tables = inspector.get_table_names()
            logging.info(f"[list_tables] 成功取得資料表名稱，共 {len(tables)} 張表。")
            return tables
        except SQLAlchemyError as e:
            logging.error(f"[list_tables] 取得資料表名稱時發生錯誤: {e}")
            return []
    
    def get_table(self, table_name):
        try:
            df = pd.read_sql_table(table_name, self.engine)
            #logging.info(f"get_table- 讀取資料表 '{table_name}' 成功 ({len(df)} rows).")
            return df
        except SQLAlchemyError as e:
            logging.error(f"[get_table] 讀取 '{table_name}' 發生錯誤: {e}")
            return pd.DataFrame()
        
   
    def drop_table(self, table_name):
        try:
            with self.engine.begin() as conn:
                conn.execute(text(f"DROP TABLE IF EXISTS {table_name}"))
            logging.info(f"[drop_table] 資料表 '{table_name}' 已刪除.")
        except SQLAlchemyError as e:
            logging.error(f"[drop_table] 刪除 '{table_name}' 發生錯誤: {e}")

    #=======================前端 ask ==============================
    # 抓近 N 天
    def get_runs_delta_days(self, tbn, days=30):
        sql = f"""
        SELECT * FROM {self.db}.{tbn}
        WHERE scantime >= NOW() - INTERVAL :days DAY
        ORDER BY scantime DESC
        """
        return pd.read_sql(text(sql), self.engine, params={"days": days})

    # 抓日期區間
    def get_runs_between(self, tbn, start_date, end_date):
         
        sql = f"""
        SELECT * FROM {self.db}.{tbn}
        WHERE run_day BETWEEN :start AND :end
        ORDER BY scantime DESC
        """
        return pd.read_sql(text(sql), self.engine, params={"start": start_date, "end": end_date})
    
    def get_defects_by_key(self, aoi_base: str, key: str) -> pd.DataFrame:
        """
        aoi_base: 'aoi100' / 'aoi200' / 'aoi300'
        key: 'YYYY-MM-DD HH:MM:SS|{glass_id}|{recipe_id}'
        從對應月份表 aoi{xxx}_rawdata_{yyyymm} 抓該次量測的全部 defect 明細。
        """
        try:
            t_str, glass_id, recipe_id = key.split("|", 2)
        except ValueError:
            # key 格式不對
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])

        # 轉 yyyymm
        try:
            dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            # 若前端 key 的時間字串格式不同，這裡可再加其他 parse 規則
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])

        yyyymm = dt.strftime("%Y%m")
        table = f"{aoi_base}_rawdata_{yyyymm}"

        # 有些欄位是字串，這裡用 CAST，前端也可再轉 number
        sql = f"""
        SELECT
          CAST(x AS UNSIGNED)          AS x,
          CAST(y AS UNSIGNED)          AS y,
          defect_size,
          pic_name,
          chip_name,
          predict_code
        FROM {table}
        WHERE glass_id   = :glass_id
          AND recipe_id  = :recipe_id
          AND (scantime = :ts OR day = :ts)
        """
        params = {"glass_id": glass_id, "recipe_id": recipe_id, "ts": t_str}
        try:
            return pd.read_sql(text(sql), self.engine, params=params)
        except Exception as e:
            print(f"[get_defects_by_key] {table} query error: {e}")
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])

    # ---------- 給 /api/defect_data 用：明細 ----------
    def get_defects_by_key(self, aoi_base: str, key: str) -> pd.DataFrame:
        """
        aoi_base: 'aoi100' / 'aoi200' / 'aoi300'
        key: 'YYYY-MM-DD HH:MM:SS|{glass_id}|{recipe_id}'
        由時間推 yyyymm -> 查 aoi{base}_rawdata_{yyyymm}
        """
        try:
            t_str, glass_id, recipe_id = key.split("|", 2)
        except ValueError:
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])

        try:
            dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])

        yyyymm = dt.strftime("%Y%m")
        table = f"{aoi_base}_rawdata_{yyyymm}"

        sql = f"""
        SELECT
          CAST(x AS UNSIGNED)  AS x,
          CAST(y AS UNSIGNED)  AS y,
          defect_size,
          pic_name,
          chip_name,
          predict_code
        FROM {self.dbname}.{table}
        WHERE glass_id  = :glass_id
          AND recipe_id = :recipe_id
          AND (scantime = :ts OR day = :ts)
        """
        params = {"glass_id": glass_id, "recipe_id": recipe_id, "ts": t_str}
        try:
            with self.engine.begin() as conn:
                return pd.read_sql(text(sql), conn, params=params)
        except SQLAlchemyError as e:
            logging.error(f"[get_defects_by_key] {e}")
            return pd.DataFrame(columns=["x","y","defect_size","pic_name","chip_name","predict_code"])


#%%
if __name__ == "__main__":
    #main()
    dbhandler = MySQLConnet('l6a01_project')
    tables = dbhandler.list_tables()