// Simple event bus + global State
(function () {
  const listeners = {};
  window.Bus = {
    on(evt, fn) {
      (listeners[evt] ||= []).push(fn);
    },
    emit(evt, payload) {
      (listeners[evt] || []).forEach((fn) => {
        try { fn(payload); } catch (e) { console.error('[Bus]', evt, e); }
      });
    }
  };

  // 全域 State
  window.State = window.State || {};
  State.filters = State.filters || { dateFrom: '', dateTo: '', glassORrecipe: '' };
  State.subFilter = State.subFilter || { types: new Set(), sizes: new Set() }; // 子篩選（若有）
  State.selectedKeys = State.selectedKeys || []; // 第 n 筆：["scantime|glass|recipe", ...]
  State.currentLine = State.currentLine || null; // 目前選的 line_id（如 CAPIT203）

})();
