ROOT: AOI_Defect_map/
    #BACKEND
    main.py
    routers/
            aoi_defect_map.py
    #FRONTEND
    indx.html
    static/
        js/
        css/

#前端模擬資料:static/js/mock_data.js


網頁初始化:取得/api/run-info 資料
前端參數
{'dates': val || '', 'line_id': val || ''}

1.初始資料 
AllRunInfoTableData 格式: 
{line_id:{0:{key:value in for key in cfg.run_info_table_cols },1:{}...} , line_id2:{....},...}

2.前端請求特定line or 特定日期區間summary
UniRunInfoTableData 格式:
{0:{key:value in for key in cfg.run_info_keys + cfg.defect_summary_keys },1:{}...}


