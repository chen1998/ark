// LR：把 run-info rows 與 defects 快取起來，提供你原先呼叫的 rowForKey/imageForKey 等
(function () {
  const _runRowsByLine = new Map();   // line_id -> Array<row>
  const _rowIndex = new Map();        // key -> row
  const _defectsCache = new Map();    // key -> Array<{x,y,size,type,pic_name,chip_name,image_path}>

  function makeKey(row) {
    // 你要求的 key：scantime|glass_id|recipe_id
    return `${row.scantime}|${row.glass_id}|${row.recipe_id}`;
  }

  function indexRows(lineId, rows) {
    _runRowsByLine.set(lineId, rows || []);
    // 同時建立 key -> row 映射（不覆蓋其他 line 的 key）
    rows.forEach(r => {
      const k = makeKey(r);
      _rowIndex.set(k, r);
    });
  }

  window.LR = {
    makeKey,

    setRunRowsForLine(lineId, rows) {
      indexRows(lineId, rows || []);
    },

    rowForKey(key) {
      return _rowIndex.get(key) || null;
    },

    imageForKey(key) {
      const r = _rowIndex.get(key);
      return r ? (r.image_path || '') : '';
    },

    hasDefects(key) {
      return _defectsCache.has(key);
    },

    storeDefects(key, defects) {
      // defects: [{x,y,size,type,pic_name,chip_name,image_path}, ...]
      _defectsCache.set(key, Array.isArray(defects) ? defects : []);
    },

    defectsForKey(key) {
      return _defectsCache.get(key) || [];
    },

    // 合併兩筆（回傳 {A:[], B:[], keys:[kA,kB]}）
    getCompareData(keys) {
      const [kA, kB] = keys || [];
      return {
        keys: [...(keys || [])],
        A: kA ? (_defectsCache.get(kA) || []) : [],
        B: kB ? (_defectsCache.get(kB) || []) : [],
      };
    }
  };
})();
