// 多選下拉元件（checkbox + 搜尋 + 全選/全不選）
(function(){
    const ns = window.AIDI;
  
    class MultiDD {
      constructor(hostId, selectId, options = []) {
        this.hostId = hostId;
        this.selectId = selectId;
        this.options = options.slice().sort();
        this.selected = new Set();
        this.nodes = {};
        this.render();
      }
      render() {
        const { qs, el } = ns;
        const host = qs('#' + this.hostId);
        if (!host) return;
  
        // 建立/取得隱藏 select
        let select = qs('#'+this.selectId);
        if (!select) {
          select = el('select', { id: this.selectId, multiple: 'multiple', style: 'display:none' });
          host.parentElement.insertBefore(select, host.nextSibling);
        }
        select.innerHTML = '';
        this.options.forEach(v => {
          const o = el('option'); o.value = v; o.textContent = v; select.appendChild(o);
        });
  
        // UI
        host.innerHTML = '';
        const wrap = el('div', { class: 'multi-dd' });
        const btn  = el('button', { class: 'multi-dd-btn', type: 'button' });
        btn.textContent = '全部（0）';
        const list = el('div', { class: 'multi-dd-list', style: 'display:none' });
  
        const search = el('input', { type:'text', placeholder:'搜尋...', style:'width:100%;margin-bottom:6px' });
        list.appendChild(search);
  
        const cont = el('div'); list.appendChild(cont);
  
        const footer = el('div', { class: 'multi-dd-footer' });
        const bAll   = el('button', { class:'btn btn-xs', type:'button' }); bAll.textContent='全選';
        const bNone  = el('button', { class:'btn btn-xs btn-secondary', type:'button' }); bNone.textContent='清空';
        //const bApply = el('button', { class:'btn btn-xs', type:'button' }); bApply.textContent='套用';
        footer.append(bAll, bNone); //, bApply
        list.appendChild(footer);
  
        wrap.append(btn, list);
        host.appendChild(wrap);
  
        btn.addEventListener('click', () => {
          const open = list.style.display !== 'none';
          ns.qsa('.multi-dd .multi-dd-list').forEach(x => x.style.display = 'none');
          ns.qsa('.multi-dd').forEach(x => x.classList.remove('open'));
          if (!open) {
            list.style.display = '';
            wrap.classList.add('open');
            search.focus();
          }
        });
        document.addEventListener('click', (ev) => {
          if (!wrap.contains(ev.target)) {
            list.style.display = 'none';
            wrap.classList.remove('open');
          }
        });
  
        const rebuildList = () => {
          const kw = search.value.trim().toLowerCase();
          cont.innerHTML = '';
          this.options
            .filter(v => !kw || String(v).toLowerCase().includes(kw))
            .forEach(v => {
              const row = el('label', { class:'multi-dd-item' });
              const ck  = el('input', { type:'checkbox', value:v });
              ck.checked = this.selected.has(v);
              ck.addEventListener('change', () => {
                if (ck.checked) this.selected.add(v); else this.selected.delete(v);
                this.syncSelect(select);
                this.updateBtnText(btn);
              });
              const txt = el('span'); txt.textContent = v;
              row.append(ck, txt);
              cont.appendChild(row);
            });
        };
  
        bAll.addEventListener('click', () => {
          this.options.forEach(v => this.selected.add(v));
          this.syncSelect(select); this.updateBtnText(btn); rebuildList();
        });
        bNone.addEventListener('click', () => {
          this.selected.clear();
          this.syncSelect(select); this.updateBtnText(btn); rebuildList();
        });
        /*
        bApply.addEventListener('click', () => {
          list.style.display = 'none';
          wrap.classList.remove('open');
          // 交由右側「套用」按鈕觸發重繪
        });*/
        search.addEventListener('input', rebuildList);
  
        this.updateBtnText(btn);
        rebuildList();
        this.nodes = { host, wrap, btn, list, search, cont, select };
      }
      updateBtnText(btn) {
        const n = this.selected.size;
        btn.textContent = n === 0 ? '全部（0）' : `已選 ${n} 項`;
      }
      syncSelect(select) {
        Array.from(select.options).forEach(o => {
          o.selected = this.selected.has(o.value);
        });
      }
      clear() {
        this.selected.clear();
        if (this.nodes.select) {
          Array.from(this.nodes.select.options).forEach(o => o.selected = false);
        }
        if (this.nodes.btn) this.updateBtnText(this.nodes.btn);
        if (this.nodes.search) this.nodes.search.value = '';
        // 清單會在下次開啟時依據 options 重新產生
      }
      setSelected(vals = []) {
        this.selected = new Set(vals);
        if (this.nodes.select) this.syncSelect(this.nodes.select);
        if (this.nodes.btn) this.updateBtnText(this.nodes.btn);
      }
      getSelected() { return Array.from(this.selected); }
    }
  
    ns.MultiDD = MultiDD;
  })();