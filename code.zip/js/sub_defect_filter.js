(function(){
  // 依選取或全域資料產生 type 選項
  function uniqueTypes(){
    const dict = MockData.sheet_defect_dict;
    const sel = State.selectedRows || [];
    const set = new Set();
    function addFrom(list){ list.forEach(d=> set.add(d.type)); }
    if(sel.length){
      sel.forEach(r=>{
        const groups = dict[r.sheet_id] || {};
        ["A","B"].forEach(g=> addFrom((groups[g]||[])));
      });
    }else{
      Object.values(dict).forEach(g=>{
        ["A","B"].forEach(k=> addFrom(g[k]||[]));
      });
    }
    return Array.from(set).sort();
  }

  function render(){
    const host = document.getElementById('sub-defect-filter-section');
    if(!host) return;
    host.innerHTML = "";
    const wrap = document.createElement('div');
    wrap.className = "sub-filter-row";

    // type 多選
    const typeBox = document.createElement('div');
    typeBox.className = "filter-group";
    const labT = document.createElement('label'); labT.textContent = "Defect 類型";
    typeBox.appendChild(labT);
    uniqueTypes().forEach(t=>{
      const chip = document.createElement('label');
      chip.className = "chip";
      const cb = document.createElement('input'); cb.type="checkbox";
      cb.checked = State.subFilter.types.size===0 || State.subFilter.types.has(t);
      cb.addEventListener('change',()=>{
        if(cb.checked) State.subFilter.types.add(t);
        else State.subFilter.types.delete(t);
        Bus.emit('sub-filter-changed', {...State.subFilter});
      });
      chip.appendChild(cb);
      chip.appendChild(document.createTextNode(t));
      typeBox.appendChild(chip);
    });
    wrap.appendChild(typeBox);

    // size 多選
    const sizeBox = document.createElement('div');
    sizeBox.className = "filter-group";
    const labS = document.createElement('label'); labS.textContent = "Size";
    sizeBox.appendChild(labS);
    ["S","M","L","O"].forEach(s=>{
      const chip = document.createElement('label');
      chip.className = "chip";
      const cb = document.createElement('input'); cb.type="checkbox";
      cb.checked = State.subFilter.sizes.size===0 || State.subFilter.sizes.has(s);
      cb.addEventListener('change',()=>{
        if(cb.checked) State.subFilter.sizes.add(s);
        else State.subFilter.sizes.delete(s);
        Bus.emit('sub-filter-changed', {...State.subFilter});
      });
      chip.appendChild(cb);
      chip.appendChild(document.createTextNode(s));
      sizeBox.appendChild(chip);
    });
    wrap.appendChild(sizeBox);

    host.appendChild(wrap);
  }

  Bus.on('init-data', render);
  Bus.on('compare-selection-changed', render);
})();