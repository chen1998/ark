// run_info_table.js — 多選、排序、同 glass 自動濾（可關閉）
(function(){
  const theadCols = [
    {text:'選'},
    {text:'時間', key:'time', sortable:true},
    {text:'Recipe', key:'recipe_id'},
    {text:'Glass', key:'glass_id'},
    {text:'S', key:'s', sortable:true},
    {text:'M', key:'m', sortable:true},
    {text:'L', key:'l', sortable:true},
    {text:'O', key:'o', sortable:true},
    {text:'總', key:'total', sortable:true}
  ];

  let currentRows = [];
  let sortKey = 'time';
  let sortDir = 'desc';

  function toDate(s){ if(!s) return new Date(0); return new Date(String(s).replace(' ','T')); }
  function enrich(r){
    const ds = r.defect_summary || {};
    const s = +(r.small_defect_count ?? ds.small_defect_count ?? 0);
    const m = +(r.middle_defect_count ?? ds.middle_defect_count ?? 0);
    const l = +(r.large_defect_count  ?? ds.large_defect_count  ?? 0);
    const o = +(r.over_defect_count   ?? ds.over_defect_count   ?? 0);
    const total = +(r.defect_count     ?? ds.defect_count        ?? (s+m+l+o));
    return { ...r, s, m, l, o, total };
  }

  function sameGlassChk(){ const el = document.getElementById('match-same-glass'); return !!(el && el.checked); }

  function passFilters(rows){
    let r = rows;
    const q = (State.filters.glassORrecipe || '').toLowerCase();
    if(q){
      r = r.filter(x =>
        String(x.glass_id||'').toLowerCase().includes(q) ||
        String(x.recipe_id||'').toLowerCase().includes(q)
      );
    }
    // 若啟用同 glass 自動濾
    if(sameGlassChk() && State.selectedKeys.length>=1){
      const g = Utils.parseKey(State.selectedKeys[0]).glass_id;
      if(g) r = r.filter(x => x.glass_id === g);
    }
    return r;
  }

  function sortRows(rows){
    const arr = rows.slice();
    if(sortKey==='time'){
      arr.sort((a,b)=> toDate(a.scantime)-toDate(b.scantime));
    }else if(['s','m','l','o','total'].includes(sortKey)){
      arr.sort((a,b)=> (a[sortKey]||0)-(b[sortKey]||0));
    }
    if(sortDir==='desc') arr.reverse();
    return arr;
  }

  function renderHead(thead){
    thead.innerHTML = '';
    const tr = document.createElement('tr');
    theadCols.forEach(c=>{
      const th = document.createElement('th');
      th.textContent = c.text;
      if(c.sortable){
        th.classList.add('sortable');
        th.dataset.key = c.key;
        const arrow = document.createElement('span');
        arrow.className = 'sort-arrow';
        if(sortKey===c.key){
          arrow.textContent = (sortDir==='asc') ? ' ▲' : ' ▼';
        }else{
          arrow.textContent = ' ↕';
        }
        th.appendChild(arrow);
        th.addEventListener('click', ()=>{
          if(sortKey===c.key){ sortDir = (sortDir==='asc'?'desc':'asc'); }
          else { sortKey = c.key; sortDir = 'desc'; }
          render(currentRows);
        });
      }
      tr.appendChild(th);
    });
    thead.appendChild(tr);
  }

  function renderBody(tbody, rows){
    tbody.innerHTML = '';
    rows.forEach((r)=>{
      const key = Utils.keyFromRow(r);
      const tr = document.createElement('tr');
      tr.dataset.key = key;
      tr.dataset.imgfld = (r.image_path)? (window.IMG_HOST + r.image_path) : '';

      if(State.selectedKeys.includes(key)) tr.classList.add('selected');

      // 僅 checkbox 觸發
      const tdSel = document.createElement('td');
      const cb = document.createElement('input');
      cb.type='checkbox'; cb.className='sel';
      cb.checked = State.selectedKeys.includes(key);
      tdSel.appendChild(cb); tr.appendChild(tdSel);

      const cols = [ r.scantime, r.recipe_id, r.glass_id, r.s, r.m, r.l, r.o, r.total ];
      cols.forEach(val=>{
        const td = document.createElement('td'); td.textContent = (val==null?'':val); tr.appendChild(td);
      });

      function toggle(checked){
        const exists = State.selectedKeys.includes(key);
        if(checked && !exists){
          State.selectedKeys.push(key);
          if(tr.dataset.imgfld) State.imgBaseByKey[key] = tr.dataset.imgfld.endsWith('/') ? tr.dataset.imgfld : (tr.dataset.imgfld + '/');
        }else if(!checked && exists){
          State.selectedKeys = State.selectedKeys.filter(k=>k!==key);
        }
        document.getElementById('sel-count').textContent = String(State.selectedKeys.length||0);
        tr.classList.toggle('selected', checked);
        Bus.emit('request-defects', State.selectedKeys.slice());
        Bus.emit('selection-changed', State.selectedKeys.slice());
        render(currentRows); // 若開啟同 glass，自動重畫
      }

      cb.addEventListener('change', ()=> toggle(cb.checked));
      tbody.appendChild(tr);
    });

    // 更新筆數
    const el = document.querySelector('#run-stats .badge b');
    if(el) el.textContent = String(rows.length);
  }

  function render(rows){
    currentRows = (rows||[]).map(enrich);
    const cont = document.getElementById('run-info-table-container'); if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-info-tbody');
    renderHead(thead);
    const filtered = passFilters(currentRows);
    const sorted = sortRows(filtered);
    renderBody(tbody, sorted);
  }

  // 搜尋
  document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('applyQuery').addEventListener('click', ()=>{
      const q = document.getElementById('fQuery').value || '';
      State.filters.glassORrecipe = q;
      render(currentRows);
    });
    document.getElementById('clearQuery').addEventListener('click', ()=>{
      State.filters.glassORrecipe = '';
      document.getElementById('fQuery').value = '';
      render(currentRows);
    });
    const same = document.getElementById('match-same-glass');
    if(same){ same.addEventListener('change', ()=> render(currentRows)); }
  });

  Bus.on('render-run-info', (rows)=> render(rows||[]));
  Bus.on('filters-changed', ()=> render(currentRows));
  Bus.on('selection-changed', ()=> render(currentRows));
  window.renderRunInfo = (rows)=> Bus.emit('render-run-info', rows);
})();
