(function(){
  function tick(){
    const el = document.getElementById('live-clock');
    if(!el) return;
    el.textContent = new Date().toLocaleString('zh-TW',{hour12:false});
  }
  tick(); setInterval(tick, 1000);
})();