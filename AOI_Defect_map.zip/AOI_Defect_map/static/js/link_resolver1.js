(function(){
  if (window.LR) {
    // 若你已經有更完整的 LR，就不要覆蓋
    if (!LR.putDefects) LR.putDefects = function(k, arr){};
    if (!LR.defectsForKey) LR.defectsForKey = function(k){ return []; };
    return;
  }
  const _defMap = new Map(); // key -> defects array
  window.LR = {
    putDefects: (key, arr)=> _defMap.set(key, Array.isArray(arr)?arr:[]),
    defectsForKey: (key)=> _defMap.get(key) || []
  };
})();