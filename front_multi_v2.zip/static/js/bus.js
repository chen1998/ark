// bus.js — 簡易事件匯流排 + 全域 State
(function () {
  const listeners = {};
  window.Bus = {
    on(evt, fn) { (listeners[evt] ||= []).push(fn); },
    emit(evt, payload) { (listeners[evt] || []).forEach(fn => { try{ fn(payload); } catch(e){ console.error('[Bus]', evt, e);} }); }
  };

  window.State = window.State || {};
  State.filters = State.filters || { dateFrom:'', dateTo:'', glassORrecipe:'' };
  State.selectedKeys = State.selectedKeys || [];          // 多筆 key: "scantime|glass|recipe"
  State.currentLine  = State.currentLine  || null;        // 例如 "CAPIT203"
  State.LineTabs     = State.LineTabs     || [];          // 例如 ["CAPIT203","CAAOI202",...]
  State.AllRunInfo   = State.AllRunInfo   || {};          // { line: [rows] }
  State.DefectCache  = State.DefectCache  || new Map();   // key -> [{x,y,size,type,img,chip}]
  State.ColorForKey  = State.ColorForKey  || new Map();   // key -> string

  window.toast = function (msg) {
    let t = document.querySelector('.toast');
    if(!t){ t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show');
    setTimeout(()=> t.classList.remove('show'), 1600);
  };
})();
