from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, Dict
from models.sql_db_connect import MySQLConnet

import pandas as pd
from datetime import datetime, timedelta

router = APIRouter()
dbhandler = MySQLConnet('l6a01_project')
# 假資料
"""
lot_info_dict = {...}
lot_defect_dict = {...}
lot_chip_dict = {...}
lot_chip_defct = {...}
"""

# 請求 run info 資料 模型
class RunInfoRequest(BaseModel):
    lot_id: Optional[str] = ""
    date: Optional[str] = ""
    ask: Optional[str] = ""
    ask_info: Optional[Dict[str, str]] = {}

class Config:
    def __init__(self):
        # =================== datetime ==========================
        now = datetime.now()
        ym = now.strftime("%Y%m")
        print(f"連線時間: {now}({ym})")
        one_mon_ago = now - timedelta(days=30)
        # ================== 摘要資料表名稱 ========================
        self.aoi_names = [f'aoi{i}00' for i in range(1,4,1)]
        self.all_aoi_summary_tbns = [f'aoi_summary_{n}' for n in self.aoi_names]
        self.aoi_name_vs_lineid = {'aoi_summary_aoi100': 'CAPIT203',
                                'aoi_summary_aoi200': 'CAAOI202',
                                'aoi_summary_aoi300': 'CAAOI300'}
        
        # ======================= 欄位設定 ========================
        self.run_info_keys = ['day', 'model',  'glass_id', 'recipe_id', 'chips']
        self.defect_summary_keys = ['defect_count', 'over_defect_count','large_defect_count','middle_defect_count', 'small_defect_count', 'defect_count','image_path'] 
        self.defect_position_keys = ['x', 'y', 'defect_size', 'pic_name']
    def clean_glass_recipe_day_df(self, df):
    
        info_df = df[self.run_info_cols].drop_duplicates()
        print(f'info: {len(info_df)}')

        info_defect_df = df[self.run_info_cols + self.defect_summary_keys].drop_duplicates()
        print(f'info_defect_df: {len(info_defect_df)}')

        return info_df, info_defect_df

    def get_all_run_info_data(self, dbhandler):
        lines = [f'aoi{i}00' for i in range(1,4,1)]
        all_line_summary = {}
       # aoi_name_vs_line_id = {}
        for tbn in self.all_aoi_summary_tbns:
            line = tbn.split("_")[-1]
            tb = dbhandler.get_runs_delta_days(line, days=3)
            print(tbn, len(tb))
            ##f not tb.empty:continue
            line_id = tb['line_id'].unique()[0]
            #aoi_name_vs_line_id[tbn] = line_id
            #dbhandler.drop_table(tbn)
            all_line_summary[tbn] = tb.to_dict(orient = 'index')
            print(all_line_summary[tbn],'\n')
        return all_line_summary


@router.post("/run_info_api")
async def get_run_info(request: RunInfoRequest):
    # 根據 request.lot_id 等去篩選資料
    #print(f" Received: lot_id={request.lot_id}, date={request.date}, ask_info={request.ask_info}")
    cfg = Config()
    dbhandler = MySQLConnet('l6a01_project')
    all_run_info_dict = cfg.get_all_run_info_data(dbhandler)
    #print(all_run_info_dict)


    return JSONResponse(
        content={
            "AllRunInfoTableData": all_run_info_dict,
            "LineTabs":cfg.aoi_name_vs_lineid,
        }
    )

"""
# 請求 defect相關資料 模型

class DefectRequest(BaseModel):
    lot_id: Optional[str] = ""
    date: Optional[str] = ""
    ask: Optional[str] = ""
    ask_info: Optional[Dict[str, str]] = {}

@router.post("/defect_data_api")
async def get_defect_data(request: DefectRequest):
    return JSONResponse(
        content={
            "lot_chip_dict": lot_chip_dict,
            "lot_chip_defct": lot_chip_defct
        }
    )
"""