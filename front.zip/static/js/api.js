(function () {
  window.AppData = window.AppData || {
    lineTabs: [],
    allRunInfo: {},   // { line_id: { 0:{...}, 1:{...}, ... } }
    currentLine: null
  };

  async function fetchAll() {
    const res = await fetch('http://10.97.142.217:8100/api/run-info');
    if (!res.ok) throw new Error('API /api/run-info failed');
    return res.json();
  }

  function buildTabs(lineTabs) {
    const cont = document.getElementById('all-tab-container');
    if (!cont) return;
    cont.innerHTML = ''; // 清空後重建
    const ul = document.createElement('div');
    ul.className = 'tabs-row';
    lineTabs.forEach((line, idx) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn';
      btn.textContent = line;
      if (idx === 0) btn.classList.add('active');
      btn.addEventListener('click', () => {
        // 切換 active
        ul.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        // 變更目前 line，並渲染表格
        AppData.currentLine = line;
        const dictRows = AppData.allRunInfo[line] || {};
        const rows = Object.values(dictRows);
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      });
      ul.appendChild(btn);
    });
    cont.appendChild(ul);
  }

  async function init() {
    try {
      const payload = await fetchAll();
      AppData.lineTabs = payload.AllLineTabs || [];
      AppData.allRunInfo = payload.AllRunInfoTableData || {};
      buildTabs(AppData.lineTabs);
      // 預設顯示第一個 line
      if (AppData.lineTabs.length) {
        AppData.currentLine = AppData.lineTabs[0];
        const dictRows= AppData.allRunInfo[AppData.currentLine] || {};
        console.log(dictRows);
        const rows = Object.values(dictRows);
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      }
    } catch (err) {
      console.error('[api.js] init error:', err);
    }
  }

  // 對外：供日期區間 + line_id 重新查詢（可給後續用）
  window.loadUniByLineAndDates = async function (lineId, start, end) {
    const url = new URL('/api/run-info', window.location.origin);
    if (lineId) url.searchParams.set('line_id', lineId);
    if (start)  url.searchParams.set('start', start);
    if (end)    url.searchParams.set('end', end);
    const res = await fetch(url.toString());
    const data = await res.json();
    if (data.UniRunInfoTableData) {
      AppData.allRunInfo[lineId] = data.UniRunInfoTableData;
      AppData.currentLine = lineId;
      const cont = document.getElementById('all-tab-container');
      // 若需要，也可同步切換 active（略）
      if (typeof window.renderRunSheetTable === 'function') {
        window.renderRunSheetTable(Object.values(data.UniRunInfoTableData));
      }
    }
  };

  // 啟動
  document.addEventListener('DOMContentLoaded', init);
})();
