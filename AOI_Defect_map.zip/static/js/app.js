// static/js/app.js
// 簡單事件匯流排
window.Bus = (function(){
  const ev = {};
  return {
    on(name, fn){ (ev[name] || (ev[name]=[])).push(fn); },
    emit(name, data){ (ev[name]||[]).forEach(fn=>fn(data)); }
  };
})();

// 全域狀態
window.State = window.State || {};
State.filters = State.filters || { dateFrom:'', dateTo:'', recipeOrSheet:'' };
State.subFilter = State.subFilter || { types:new Set(), sizes:new Set() };
// 只存最多兩筆 key（第一/第二）
State.selectedKeys = State.selectedKeys || [];