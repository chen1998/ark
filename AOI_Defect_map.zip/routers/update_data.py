from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from routers.main_page import *
import pandas as pd
import os
from datetime import datetime

router = APIRouter()


class DictModel(BaseModel):
    AskType: str
    dict_data: dict
    weekly:list
    Editor: str

def get_week_code_range(mon_start: str, mon_end: str):
    import datetime as dt

    def make_code(date_obj: dt.date):
        iso_year, iso_week, _ = date_obj.isocalendar()
        return f"W{str(iso_year)[-1]}{iso_week:02d}"

    # 將 'YYYY-MM' 轉為月初與月末
    start_date = dt.datetime.strptime(mon_start, "%Y-%m").date().replace(day=1)
    if mon_start == mon_end:
        next_month = dt.datetime.strptime(mon_end, "%Y-%m").date().replace(day=28) + dt.timedelta(days=4)
    else:
        next_month = dt.datetime.strptime(mon_end, "%Y-%m").date().replace(day=1) + dt.timedelta(days=4)
    print(next_month )
    end_date = next_month.replace(day=1) - dt.timedelta(days=1)

    # 從起始週的週一開始跑到結束週的週日
    curr = start_date - dt.timedelta(days=start_date.weekday())  # 該週一
    end = end_date + dt.timedelta(days=(6 - end_date.weekday()))  # 該週日

    week_codes = set()
    while curr <= end:
        week_codes.add(make_code(curr))
        curr += dt.timedelta(days=7)

    return sorted(week_codes)

def get_previous_5_weeks(date_str: str):
    import datetime as dt

    """
    傳入日期字串 'YYYY-MM-DD'，回傳當週起往前共 5 週的週別代碼字串清單（格式: 'W[年尾數][週數]'）
    例如：['W520', 'W519', 'W518', 'W517', 'W516']
    """
    date_obj = dt.datetime.strptime(date_str, "%Y-%m-%d").date()

    def make_code(date_obj: dt.date):
        iso_year, iso_week, _ = date_obj.isocalendar()
        return f"W{str(iso_year)[-1]}{iso_week:02d}"

    # 回推前五週（含當週）
    codes = [make_code(date_obj - dt.timedelta(weeks=i)) for i in range(5)]
    return codes



def generate_common_dict(config, index_key, Editor, timestamp):
    match_keys = {'index_key':index_key}
    common_dict = {key:value for key, value in zip(config.common_columns, dict_data['index_key'].split("_"))}
    editor_dict = {'drop':False, 'editor':Editor, 'modify_time': timestamp}
    common_dict.update(editor_dict)

    return match_keys, editor_dict, common_dict

def del_row(timestamp, config, dict_data, Editor):
    dict_data.update({'index_key':dict_data['index_key'].strip()})
    common_dict = {key:value for key, value in zip(config.common_columns, dict_data['index_key'].split("_"))}
    common_dict.update({'drop':True, 'editor':Editor, 'modify_time': timestamp})

    if '~' in dict_data['時程'] :
        dict_data.update({key: value for key, value in zip(['Start', 'Due date'], dict_data['時程'].split("~"))})
    else:
        dict_data.update({key: '' for key, value in zip(['Start', 'Due date'], dict_data['時程'].split("~"))})

    dict_data.update(common_dict)

    weekly_dict = {key:dict_data[key] for key in dict_data.keys() if (key[0]=='W' and len(key) ==4) or key in config.weekly_columns}
    summary_dict = {key:dict_data[key] for key in dict_data.keys() if key in config.summary_columns}
    
    for table_name, df in zip(config.sql_table_names, [summary_dict, weekly_dict]):
        config.DBHandler.upsert_row_direct(table_name,df )
def check_pjids(summary_dict):
    if '專案管理平台立案' in summary_dict.keys():
        ids = [path.split('PJTID=')[-1] for path in summary_dict['專案管理平台立案'].split("\n") if 'PJTID=' in path]
        if len(ids)>0:
            id_char =  "\n".join(ids)
            summary_dict['專案代碼'] = id_char 
    return summary_dict

def AppendBtn(timestamp, config, dict_data):
    append_weekly_dict = { 'modify_time':timestamp }
    #(
    print( dict_data)
    for group, owner_data in dict_data.items():

        for owner, pj_data in owner_data.items():

            for pj, row_dict in pj_data.items():
                append_weekly_dict.update({'Group':group , 'Owner': owner, 'Project Name':pj, 'drop' : False })
                append_summary_dict = append_weekly_dict.copy()
                append_weekly_dict.update({key:row_dict[key] for key in row_dict.keys() if (key[0]=='W' and len(key) ==4) or key in config.weekly_columns })
                append_summary_dict.update({key:row_dict[key] for key in row_dict.keys() if key in config.summary_columns })
                append_summary_dict.update({key: append_summary_dict[key].replace("-",'') + '000000' \
                                            for key in ['Start', 'Due date'] if key in append_summary_dict.keys() and append_summary_dict[key] not in ['', 'NA']})
                append_summary_dict.update({'TaskType':'持續性', 'ReturnParam':'不回傳'})
    append_summary_dict = check_pjids(append_summary_dict)
    #miss_cols = config.DBHandler.ensure_columns("Project_Weekly", append_weekly_dict.keys())
    #print('weekly',append_weekly_dict)
    print('summary',append_summary_dict)
    config.DBHandler.upsert_row_direct("Project_Weekly",append_weekly_dict)
    config.DBHandler.upsert_row_direct("Project_Summary",append_summary_dict)


def modify_editbtn(timestamp, config, dict_data, weekly, Editor):
    index_key = dict_data['index_key']
    match_keys, editor_dict, common_dict = generate_common_dict(config, index_key, Editor, timestamp)
    print('modify', editor_dict)
    
    if '進度' in dict_data.keys():
        if dict_data['進度'][-1] == '%':
            dict_data['進度'] = dict_data['進度'][:-1]
    try:
       if  int(dict_data['進度']) == 100:
           dict_data['狀態'] = '已完成'
           dict_data['進度'] = '100'
    except:
        pass
    
    if '狀態' in dict_data.keys():
        if dict_data['狀態'] == '已完成':
            dict_data['進度'] = '100'

    dict_data = check_pjids(dict_data)
    print(dict_data)



    modify_common_cols = {key: value for key, value in dict_data.items() if key in config.common_columns  }
    modify_summary_dict = {key: value for key, value in dict_data.items() if key in config.summary_columns and key != 'index_key'}
    modify_weekly_dict = {key: value for key, value in dict_data.items() if (key in config.weekly_columns and key != 'index_key') or( key in weekly)}

    if len(modify_common_cols) !=0:
        print(f'modeift common key: {modify_common_cols}')
        drop_dict = editor_dict.copy()
        drop_dict.update({'drop':True})
    
        for table_name, modify_dict in zip(config.sql_table_names, [modify_summary_dict, modify_weekly_dict]) :
            old_row_dict = config.DBHandler.get_row(table_name, match_keys)
            print(f'{table_name}...')
            #drop old row
            drop_row_dict = old_row_dict.copy()
            drop_row_dict.update(drop_dict)
            
            print(f'drop {table_name} {index_key}',drop_row_dict)
            config.DBHandler.update_row(table_name, match_keys, drop_row_dict)
            # append new index_key
            new_index_dict = old_row_dict.copy()
            new_index_dict.update(editor_dict)
            if len(modify_dict) !=0:
                new_index_dict.update(modify_dict)
                
            new_index_key = "_".join([new_index_dict[col] for col in config.common_columns])
            new_index_dict.update({'index_key':new_index_key})
            print(f'append new {new_index_key} row', new_index_dict)
            new_row = pd.DataFrame([new_index_dict])
            config.DBHandler.append_new_rows(new_row, table_name, ['index_key'])

    else:
        for table_name, modify_dict in zip(config.sql_table_names, [modify_summary_dict, modify_weekly_dict]) :
            new_values = {col:dict_data[col] for col in modify_dict}
            new_values.update(editor_dict)
            print(f'{table_name}...modify : {new_values}')
            config.DBHandler.update_row(table_name, match_keys, new_values)
        config.DBHandler.update_row("Project_Weekly", {'index_key':index_key}, {'modify_time':str(timestamp)})

def download_data_process(config, dict_data):
    now_time = datetime.now()
    weekly_cols = get_previous_5_weeks(now_time.strftime('%Y-%m-%d'))

    if dict_data['mon_start'] == '':
        ym = now_time.strftime('%Y')
    else:
        ym = dict_data['mon_start'].split("-")[0]
    st_ym = f'{ym}-01'

    summary_df = config.DBHandler.get_table("Project_Summary")

    filtered_df = summary_df[(summary_df['Start'].str.slice(0, 7) >= st_ym) & (summary_df['drop'] != True)]
    print(len(filtered_df['index_key'].unique()))
    Weekly_df = config.DBHandler.sync_table_columns_and_get_df(
            "Project_Weekly", 
            config.common_columns + weekly_cols + config.sql_key_columns
        )
    Weekly_df = Weekly_df[Weekly_df['drop'] != True]
    Weekly_df = Weekly_df[Weekly_df['index_key'].isin(filtered_df['index_key'].unique())]
    merge_df = pd.merge(summary_df, Weekly_df, on = config.common_columns + config.sql_key_columns, how = 'inner' )
    merge_df = merge_df[[cl for cl in merge_df.columns if cl not in ['index_key', 'drop']]]

    return merge_df

# 主 API：處理來自前端的 dict 更新請求
@router.post("/")
async def backend_process(data: DictModel):
    global dict_data
    config = Config()
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

    asktype = data.AskType
    weekly_cols = data.weekly
    Editor = data.Editor
    dict_data = data.dict_data
    if asktype == 'add_new_project':
        AppendBtn(timestamp, config, dict_data)
    elif asktype == 'del_row':
        del_row(timestamp, config, dict_data, Editor)
        #AppendBtn(timestamp, config, data.dict_data)
    elif asktype == 'modify_row':
        modify_editbtn(timestamp, config, dict_data, weekly_cols , Editor)
    """
    elif asktype == 'download':
        print(data)
        csv_data = download_data_process(config, dict_data)
    """
    df = read_and_merge_tables(config, weekly_cols)
    result = groupby_to_nested_dict(df, config.common_columns, value_func=value_func)



    return {
        "message": "資料已成功存入 Excel！",
        "status": "success",
        "dict_data": result
    }