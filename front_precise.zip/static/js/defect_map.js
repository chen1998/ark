// defect_map.js — 多筆疊圖 + 放大縮小 + 框選 + 尺寸/類型篩選 + 點擊 offset 比對
(function(){
  const canvas = document.getElementById('defect-map-canvas');
  const ctx = canvas.getContext('2d');

  // 畫布尺寸自適應容器
  function resizeCanvas(){
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.max(300, Math.floor(rect.width));
    canvas.height = Math.max(300, Math.floor(rect.height));
  }
  window.addEventListener('resize', ()=>{ resizeCanvas(); drawAll(); });
  resizeCanvas();

  function getDefects(key){ return State.DefectCache[key] || []; }
  function allPoints(){
    const pts = [];
    State.selectedKeys.forEach(k=>{
      const color = Utils.colorFor(k);
      const bs = getDefects(k);
      bs.forEach(d=> pts.push({ key:k, x:Number(d.x)||0, y:Number(d.y)||0, size:(d.size||'S'), type:(d.type||'1'), color }));
    });
    return pts;
  }

  // 地圖座標系統
  function computeBounds(){
    const pts = allPoints();
    if(!pts.length) return {minx:0,miny:0,maxx:100,maxy:100};
    let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
    pts.forEach(p=>{ if(p.x<minx)minx=p.x; if(p.y<miny)miny=p.y; if(p.x>maxx)maxx=p.x; if(p.y>maxy)maxy=p.y; });
    if(!Number.isFinite(minx)) { minx=0; miny=0; maxx=100; maxy=100; }
    // padding
    const dx=(maxx-minx)||100, dy=(maxy-miny)||100;
    return { minx:minx-0.05*dx, miny:miny-0.05*dy, maxx:maxx+0.05*dx, maxy:maxy+0.05*dy };
  }

  function worldToScreen(wx, wy){
    const {ox,oy,scale} = State.Map;
    const x = (wx - ox)*scale + 50;
    const y = (wy - oy)*scale + (canvas.height-50);
    return {x, y};
  }
  function screenToWorld(sx, sy){
    const {ox,oy,scale} = State.Map;
    const wx = (sx - 50)/scale + ox;
    const wy = (sy - (canvas.height-50))/scale + oy;
    return {x:wx, y:wy};
  }

  function fitToData(){
    const b = computeBounds();
    const dx = b.maxx - b.minx;
    const dy = b.maxy - b.miny;
    const sx = (canvas.width-100)/dx;
    const sy = (canvas.height-100)/dy;
    const scale = Math.max(0.0001, Math.min(sx, sy));
    State.Map.scale = scale;
    State.Map.ox = b.minx;
    State.Map.oy = b.maxy; // 注意 y 軸反向
  }

  function drawAxes(){
    ctx.save();
    ctx.strokeStyle = '#2a3140';
    ctx.lineWidth = 1;
    // x 軸
    ctx.beginPath(); ctx.moveTo(50, canvas.height-50); ctx.lineTo(canvas.width-10, canvas.height-50); ctx.stroke();
    // y 軸
    ctx.beginPath(); ctx.moveTo(50, canvas.height-10); ctx.lineTo(50, 10); ctx.stroke();

    // 刻度
    ctx.fillStyle = '#8fa3b8';
    ctx.font = '11px system-ui, sans-serif';
    for(let i=0;i<6;i++){
      const tx = 50 + i*(canvas.width-100)/5;
      const wx = screenToWorld(tx, canvas.height-50).x;
      ctx.fillText(wx.toFixed(0), tx-12, canvas.height-34);

      const ty = canvas.height-50 - i*(canvas.height-100)/5;
      const wy = screenToWorld(50, ty).y;
      ctx.fillText(wy.toFixed(0), 8, ty+4);
    }
    ctx.restore();
  }

  function drawPoints(){
    const sizeSet = State.SizeFilter, typeSet = State.TypeFilter;
    const pts = allPoints();
    pts.forEach(p=>{
      if(!sizeSet.has(String(p.size).toUpperCase())) return;
      if(!typeSet.has(String(p.type))) return;
      const {x,y} = worldToScreen(p.x, p.y);
      let r = 2.5;
      if(p.size==='M') r=4; else if(p.size==='L') r=5.5; else if(p.size==='O') r=7;
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI*2); ctx.fill();
    });
  }

  function drawAll(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    drawAxes();
    drawPoints();
    drawLegend();
  }

  function drawLegend(){
    const box = document.getElementById('map-legend');
    box.innerHTML='';
    State.selectedKeys.forEach(k=>{
      const c = Utils.colorFor(k);
      const div = document.createElement('div');
      div.className='legend-chip';
      div.innerHTML = `<span class="legend-dot" style="background:${c}"></span> ${k}`;
      box.appendChild(div);
    });
  }

  // Map controls
  document.getElementById('btnReset').addEventListener('click', ()=>{ fitToData(); drawAll(); });
  document.getElementById('btnZoomIn').addEventListener('click', ()=>{ State.Map.scale*=1.25; drawAll(); });
  document.getElementById('btnZoomOut').addEventListener('click', ()=>{ State.Map.scale/=1.25; drawAll(); });

  // Box zoom
  let isBox=false, start=null;
  document.getElementById('btnBoxZoom').addEventListener('click', ()=>{ isBox = !isBox; toast(isBox?'框選中（拖曳）':'取消框選'); });
  canvas.addEventListener('mousedown', (ev)=>{
    if(!isBox) return;
    start = {x:ev.offsetX, y:ev.offsetY};
  });
  canvas.addEventListener('mousemove', (ev)=>{
    if(!isBox || !start) return;
    drawAll();
    const x= Math.min(start.x, ev.offsetX), y=Math.min(start.y, ev.offsetY);
    const w= Math.abs(start.x-ev.offsetX), h=Math.abs(start.y-ev.offsetY);
    ctx.save(); ctx.strokeStyle='#92b5ff'; ctx.setLineDash([4,3]); ctx.strokeRect(x,y,w,h); ctx.restore();
  });
  canvas.addEventListener('mouseup', (ev)=>{
    if(!isBox || !start) return;
    const x1 = Math.min(start.x, ev.offsetX), y1=Math.min(start.y, ev.offsetY);
    const x2 = Math.max(start.x, ev.offsetX), y2=Math.max(start.y, ev.offsetY);
    const w1 = screenToWorld(x1, y2); const w2 = screenToWorld(x2, y1);
    // fit to selection
    const dx = w2.x - w1.x, dy = w2.y - w1.y;
    const sx = (canvas.width-100)/dx; const sy = (canvas.height-100)/dy;
    State.Map.scale = Math.max(0.0001, Math.min(sx, sy));
    State.Map.ox = w1.x; State.Map.oy = w2.y;
    isBox=false; start=null; drawAll();
  });

  // Size / Type filters
  document.querySelectorAll('.mf-size').forEach(cb=>{
    cb.addEventListener('change', ()=>{
      if(cb.checked) State.SizeFilter.add(cb.value); else State.SizeFilter.delete(cb.value);
      drawAll();
    });
  });
  document.querySelectorAll('.mf-type').forEach(cb=>{
    cb.addEventListener('change', ()=>{
      if(cb.checked) State.TypeFilter.add(cb.value); else State.TypeFilter.delete(cb.value);
      drawAll();
    });
  });

  // 當選取或缺陷資料更新 → 重新計算範圍並繪製
  Bus.on('selection-changed', ()=>{ fitToData(); drawAll(); });
  Bus.on('defect-refresh', ()=>{ fitToData(); drawAll(); });

  // 點擊地圖：Offset 比對
  canvas.addEventListener('click', (ev)=>{
    const w = screenToWorld(ev.offsetX, ev.offsetY);
    const offset = Math.abs(Number(document.getElementById('offsetInput').value)||5);
    const th = offset*offset;
    const cont = document.getElementById('map-info-container');
    cont.innerHTML = '';
    State.selectedKeys.forEach(k=>{
      const color = Utils.colorFor(k);
      const defects = (State.DefectCache[k]||[]).slice().sort(Utils.byOriginAsc);
      const near = defects.filter(d=>{
        const dx = (Number(d.x)||0) - w.x;
        const dy = (Number(d.y)||0) - w.y;
        return (dx*dx + dy*dy) <= th;
      });

      const wrap = document.createElement('div');
      wrap.className = 'offset-group';
      const title = document.createElement('div');
      title.className = 'offset-title';
      title.innerHTML = `<span style="color:${color};">●</span> ${k} — within ${offset}`;
      wrap.appendChild(title);

      const tbl = document.createElement('table');
      tbl.className = 'offset-table';
      const thd = document.createElement('thead');
      thd.innerHTML = `<tr><th>#</th><th>x</th><th>y</th><th>size</th><th>type</th><th>chip</th><th>img</th></tr>`;
      tbl.appendChild(thd);
      const tb = document.createElement('tbody');
      (near.length?near:[]).forEach((d, idx)=>{
        const file = Utils.addJpgIfMissing(d.file || d.pic_name || '');
        const base = State.imgBaseByKey[k] || '';
        const src = (file ? (base + file) : '');
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${idx+1}</td><td>${d.x||''}</td><td>${d.y||''}</td><td>${d.size||''}</td><td>${d.type||''}</td><td>${d.chip||''}</td><td class="img-cell">${src?`<img src="${src}" alt="">`:''}</td>`;
        tb.appendChild(tr);
      });
      if(!near.length){
        const tr = document.createElement('tr');
        tr.innerHTML = `<td colspan="7" style="color:#8fa3b8;">（無符合資料）</td>`;
        tb.appendChild(tr);
      }
      tbl.appendChild(tb);
      wrap.appendChild(tbl);
      cont.appendChild(wrap);
    });
  });

})();