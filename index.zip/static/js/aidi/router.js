// static/js/aidi/router2.js
(function () {
    const ns = {};
    window.AIDIRouter = ns;
  
    // 初始化
    ns.ensureInit = async function () {
      try {
        const dates = readDates();
        const filters = {}; // 初次不帶過濾（讓後端用預設當月）
        await window.AIDI.fetchAIDIData({ dates, filters });
        // 初始化篩選下拉清單
        populateFilterOptions(window.AIDI.state.uniques);
        // 首次繪圖
        redraw();
        bindUI();
      } catch (err) {
        console.error(err);
        alert("初始化失敗：" + err.message);
      }
    };
  
    function readDates() {
      const b = document.querySelector("#date-begin")?.value;
      const e = document.querySelector("#date-end")?.value;
      return (b && e) ? [b, e] : undefined; // "YYYY-MM-DD"
    }
  
    function populateSelect(id, values) {
      const el = document.getElementById(id);
      if (!el) return;
      // 清空
      el.innerHTML = "";
      // 填入
      (values || []).sort().forEach(v => {
        const opt = document.createElement("option");
        opt.value = v;
        opt.textContent = v;
        el.appendChild(opt);
      });
    }
  
    function populateFilterOptions(uniques) {
      populateSelect("line-id", uniques.line_id);
      populateSelect("aoi-id", uniques.aoi);
      populateSelect("model-id", uniques.model);
      populateSelect("glass-type", uniques.glass_type);
      populateSelect("defect-code", uniques.ai_code_1);
      populateSelect("defect-size", ["S","M","L","O"]);
    }
  
    function needRefetch(dates) {
      // 若選擇日期超出目前快取範圍，回後端重抓
      const tr = window.AIDI.state.timeRange;
      if (!tr || !dates || dates.length !== 2) return false;
      const begin = new Date(dates[0] + "T00:00:00");
      const end   = new Date(dates[1] + "T23:59:59");
      return (begin < tr.min || end > tr.max);
    }
  
    async function redraw() {
      const dates = readDates();
      if (needRefetch(dates)) {
        // 把目前 UI 的 filter 一起傳回去：後端會回覆新月份資料
        const filters = (function readFilters() {
          const getVals = (id) => {
            const el = document.getElementById(id);
            if (!el) return [];
            if (el.tagName === "SELECT" && el.multiple) {
              return Array.from(el.selectedOptions).map(o => o.value);
            }
            return el.value ? [el.value] : [];
          };
          return {
            line_id: getVals("line-id"),
            aoi: getVals("aoi-id"),
            model: getVals("model-id"),
            glass_type: getVals("glass-type"),
            ai_code_1: getVals("defect-code"),
            defect_size: getVals("defect-size")
          };
        })();
  
        await window.AIDI.fetchAIDIData({ dates, filters });
        populateFilterOptions(window.AIDI.state.uniques);
      }
  
      const rows = window.AIDI.getFiltered({ dates });
      // 你自己的 charts renderer，如果有的話直接替換這行
      renderCharts(rows);
    }
  
    function bindUI() {
      const ids = ["line-id","aoi-id","model-id","glass-type","defect-code","defect-size","date-begin","date-end"];
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener("change", () => redraw());
        el.addEventListener("input",  () => redraw());
      });
    }
  
    // ====== 簡易範例：把數據畫成一個總量折線（你可換成 Tableau/ECharts/Highcharts 等） ======
    function renderCharts(rows) {
      // 這裡示範把 n_glasses 依 pi_hour 累加成簡單表格（safe fallback）
      const holder = document.getElementById("chart-holder");
      if (!holder) return;
      if (!rows.length) {
        holder.innerHTML = "<div class='muted'>沒有資料</div>";
        return;
      }
      const byHour = {};
      rows.forEach((r) => {
        byHour[r.pi_hour] = (byHour[r.pi_hour] || 0) + Number(r.n_glasses || 0);
      });
      const hours = Object.keys(byHour).sort();
      const html = [
        "<table class='simple'>",
        "<thead><tr><th>pi_hour (yy-mm-dd hh)</th><th>n_glasses</th></tr></thead>",
        "<tbody>",
        ...hours.map(h => `<tr><td>${h}</td><td>${byHour[h]}</td></tr>`),
        "</tbody></table>"
      ].join("");
      holder.innerHTML = html;
  
      // 如果你有自己的繪圖函式：
      // if (window.renderAIDICharts) window.renderAIDICharts(rows, window.AIDI.state.uniques, window.AIDI.state.paramDict);
    }
  
    // 自動啟動
    document.addEventListener("DOMContentLoaded", ns.ensureInit);
  })();