// static/js/aoi_density/router.js
(function () {
  const ns = {};
  window.AOI_DENSITY_Router = ns;

  let isFetching = false;
  ns.cachedSpan = null;
  ns.userAppliedDate = false;
  ns.justFetchedUsingDefault = false;

  ns.ensureInit = async function () {
    try {
      let dates = readDates();
      if (!dates) {
        const def = computeDefaultLast3Days();
        setUIDates(def);
        ns.userAppliedDate = false;
        await fetchData(undefined, {}, 'init-default');
        ns.justFetchedUsingDefault = true;
      } else {
        await fetchData(expandDatesToFullDays(dates), {}, 'init-with-ui-dates');
        ns.userAppliedDate = true;
      }
      await redraw();
      bindUI();
    } catch (err) {
      alert("初始化失敗：" + err.message);
    }
  };

  function toYMD(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  function computeDefaultLast3Days() {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const start = new Date(end); start.setDate(start.getDate() - 3);
    return [toYMD(start), toYMD(end)];
  }
  function setUIDates([b, e]) {
    const beginEl = document.querySelector("#aoi_densityStart");
    const endEl   = document.querySelector("#aoi_densityEnd");
    if (beginEl) beginEl.value = b;
    if (endEl)   endEl.value   = e;
  }
  function expandDatesToFullDays(dates) {
    if (!dates || dates.length !== 2) return dates;
    return [`${dates[0]} 00:00:00`, `${dates[1]} 23:59:59`];
  }
  function normalizeDaySpan(minDate, maxDate) {
    if (!minDate || !maxDate) return null;
    const b = new Date(minDate); b.setHours(0,0,0,0);
    const e = new Date(maxDate); e.setHours(23,59,59,999);
    return { begin: b, end: e };
  }
  function readDates() {
    const b = document.querySelector("#aoi_densityStart")?.value;
    const e = document.querySelector("#aoi_densityEnd")?.value;
    return (b && e) ? [b, e] : undefined;
  }

  function readFilters() {
    const getVals = (id) => Array.from(document.getElementById(id)?.selectedOptions || []).map(o=>o.value);
    return {
      line_id: getVals("line-id"),
      aoi: getVals("aoi-id"),
      model: getVals("model-id"),
      glass_type: getVals("glass-type"),
      ai_code_1: getVals("defect-code"),
      defect_size: getVals("defect-size")
    };
  }

  async function fetchData(datesWithTimes, filters, reason) {
    if (isFetching) return;
    isFetching = true;
    try {
      await window.AOI_DENSITY.fetchAoiDensityData({ dates: datesWithTimes, filters: filters || {} });
      const tr = window.AOI_DENSITY.state.timeRange;
      if (tr) ns.cachedSpan = normalizeDaySpan(tr.min, tr.max);
    } finally { isFetching = false; }
  }

  function isWithinCachedSpan(datesYMD) {
    if (!ns.cachedSpan || !datesYMD || datesYMD.length !== 2) return false;
    const wantBegin = new Date(datesYMD[0] + "T00:00:00");
    const wantEnd   = new Date(datesYMD[1] + "T23:59:59");
    return (wantBegin >= ns.cachedSpan.begin) && (wantEnd <= ns.cachedSpan.end);
  }

  async function redraw() {
    const dates = readDates();

    if (!ns.justFetchedUsingDefault) {
      if (dates && !isWithinCachedSpan(dates) && ns.userAppliedDate) {
        await fetchData(expandDatesToFullDays(dates), readFilters(), 'redraw-out-of-cache');
      }
    } else {
      ns.justFetchedUsingDefault = false;
    }

    const rows = window.AOI_DENSITY.getFiltered({ dates });
    render(rows); // 用過濾後 rows 畫
  }

  function bindUI() {
    ["line-id","aoi-id","model-id","glass-type","defect-size","defect-code"].forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener("change", () => redraw());
      el.addEventListener("input",  () => redraw());
    });

    document.getElementById("aoi_densityApply")?.addEventListener("click", async ()=>{
      const dates = readDates();
      if (!dates) return;
      ns.userAppliedDate = true;
      if (!isWithinCachedSpan(dates)) {
        await fetchData(expandDatesToFullDays(dates), readFilters(), 'apply-out-of-cache');
      }
      await redraw();
    });

    document.getElementById("aoi_densityClear")?.addEventListener("click", async ()=>{
      const b = document.getElementById("aoi_densityStart");
      const e = document.getElementById("aoi_densityEnd");
      if (b) b.value = ""; if (e) e.value = "";
      ns.userAppliedDate = false;
      await fetchData(undefined, readFilters(), 'clear-to-default');
      const def = computeDefaultLast3Days();
      setUIDates(def);
      ns.justFetchedUsingDefault = true;
      await redraw();
    });
  }

  function render(rows){
    // 圖
    if (window.AOI_DENSITY?.Charts?.render) {
      window.AOI_DENSITY.Charts.render(rows, window.AOI_DENSITY?.state?.paramDict);
    }
    // 表
    if (window.AOI_DENSITY?.Table?.render) {
      window.AOI_DENSITY.Table.render(rows, window.AOI_DENSITY?.state?.paramDict);
    }
  }
})();

/*

*/