// static/js/link_resolver.js
// 將 (measure_time|sheet_id|recipe_id) 作為唯一 key，
// 在 init 時建立 key -> row 與 key -> 虛擬組別(A/B) 的映射，
// 讓 map/table/images 都可不依賴 group 欄位。

(function(){
    const LR = {
      // key: `${measure_time}|${sheet_id}|${recipe_id}`
      makeKey(row){
        return `${row.measure_time}|${row.sheet_id}|${row.recipe_id}`;
      },
      // 內部映射
      _keyToRow: new Map(),          // key -> row
      _keyToVirtGroup: new Map(),    // key -> 'A' | 'B'
      _sheetToKeys: new Map(),       // sheet -> keys(依時間排序)
      _inited: false,
  
      // 初始化：根據 run_sheet_list 建索引與虛擬 A/B
      init(mock){
        if(!mock || !Array.isArray(mock.run_sheet_list)) return;
        this._keyToRow.clear(); this._keyToVirtGroup.clear(); this._sheetToKeys.clear();
        const rows = mock.run_sheet_list.slice();
  
        // 依 sheet 分組
        const bySheet = new Map();
        for(const r of rows){
          const arr = bySheet.get(r.sheet_id) || [];
          arr.push(r);
          bySheet.set(r.sheet_id, arr);
        }
  
        // 各 sheet 內依時間排序並交替指定 A / B
        const asDate = (s)=> new Date(String(s).replace(' ','T'));
        for(const [sheet, arr] of bySheet.entries()){
          arr.sort((a,b)=> asDate(a.measure_time) - asDate(b.measure_time)); // 由早到晚
          const keys = [];
          arr.forEach((row, idx)=>{
            const key = this.makeKey(row);
            this._keyToRow.set(key, row);
            // 交替：偶數 A、奇數 B
            const virt = (idx % 2 === 0) ? 'A' : 'B';
            this._keyToVirtGroup.set(key, virt);
            keys.push(key);
          });
          this._sheetToKeys.set(sheet, keys);
        }
  
        this._inited = true;
      },
  
      // 取得 row / group / defects / image
      rowForKey(key){ return this._keyToRow.get(key) || null; },
      virtGroupForKey(key){ return this._keyToVirtGroup.get(key) || null; },
  
      defectsForKey(key){
        const row = this.rowForKey(key);
        const g = this.virtGroupForKey(key);
        if(!row || !g) return [];
        const dict = (window.MockData && MockData.sheet_defect_dict) || {};
        const groups = dict[row.sheet_id] || {};
        const arr = groups[g] || [];
        return arr;
      },
  
      imageForKey(key){
        const row = this.rowForKey(key);
        const g = this.virtGroupForKey(key);
        if(!row || !g) return null;
        const imgDict = (window.MockData && MockData.images) || {};
        return imgDict[`${row.sheet_id}|${g}`] || null;
      }
    };
  
    // 匯出到全域
    window.LR = LR;
  
    // 等待資料就緒後初始化
    Bus.on('init-data', ({mock})=>{
      LR.init(mock);
    });
  })();