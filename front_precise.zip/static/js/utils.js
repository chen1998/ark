// utils.js — 共用工具
(function(){
  const COLORS = ['#7fe7c8','#8aa0ff','#ffb86b','#ff6b6b','#a5d8ff','#b197fc','#ffc078','#faa2c1','#69db7c','#ffd43b'];
  function colorFor(key){
    if(State.ColorForKey[key]) return State.ColorForKey[key];
    const c = COLORS[Object.keys(State.ColorForKey).length % COLORS.length];
    State.ColorForKey[key] = c; return c;
  }

  function keyFromRow(r){
    // key: 'YYYY-MM-DDTHH:MM:SS|GLASS|RECIPE'
    const t = String(r.scantime||'').replace(' ','T');
    return `${t}|${r.glass_id}|${r.recipe_id}`;
  }
  function parseKey(k){
    const [t,g,r] = String(k||'||').split('|');
    return { scantime:t, glass_id:g, recipe_id:r };
  }

  function addJpgIfMissing(s){
    if(!s) return s;
    const lower = s.toLowerCase();
    if(lower.endsWith('.jpg')||lower.endsWith('.jpeg')||lower.endsWith('.png')) return s;
    return s + '.jpg';
  }

  function distanceSq(a,b){ const dx=a.x-b.x, dy=a.y-b.y; return dx*dx+dy*dy; }
  function toNum(v){ const n = Number(v); return Number.isFinite(n)?n:0; }
  function byOriginAsc(a,b){
    const da = toNum(a.x)*toNum(a.x) + toNum(a.y)*toNum(a.y);
    const db = toNum(b.x)*toNum(b.x) + toNum(b.y)*toNum(b.y);
    return da - db;
  }

  window.Utils = { colorFor, keyFromRow, parseKey, addJpgIfMissing, distanceSq, byOriginAsc };
})();
