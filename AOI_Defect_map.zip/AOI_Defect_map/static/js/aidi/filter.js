// 右側篩選：建置、多選值存取、快速篩選、日期預設
(function(){
  const ns = window.AIDI;

  ns.buildFilterWidgets = function(){
    const F = ns.state.full.filters || {};
    ns.state.mdd.line  = new ns.MultiDD('aidiLine-dd',  'aidiLine',  F.line_ids || []);
    ns.state.mdd.aoi   = new ns.MultiDD('aidiAOI-dd',   'aidiAOI',   F.aoi_ids || []);
    ns.state.mdd.model = new ns.MultiDD('aidiModel-dd', 'aidiModel', F.models || []);
    ns.state.mdd.code  = new ns.MultiDD('aidiCode-dd',  'aidiCode',  F.defect_codes || []);

    // <<< 新增：監聽 AOI -> AIDI 的同步事件 >>>
    // 允許 AOI 送過來部份欄位（line/model/aoi/code/time/dateRange）
    window.Bus?.on('aoi:filter', (payload)=>{
      if(!payload) return;
      // 套入各類選擇
      ns.setFilterSelections({
        line:  payload.line  || undefined,
        aoi:   payload.aoi   || undefined,
        model: payload.model || undefined,
        code:  payload.code  || undefined
      });
      // 時間可傳單一 time（小時），或 dateRange: [start,end]（YYYY-MM-DD）
      if (payload.time) {
        const d = new Date(payload.time); d.setMinutes(0,0,0);
        const ds = ns.dateStr(d);
        ns.qs('#aidiStart').value = ds;
        ns.qs('#aidiEnd').value   = ds;
      }
      if (Array.isArray(payload.dateRange) && payload.dateRange.length === 2) {
        ns.qs('#aidiStart').value = payload.dateRange[0];
        ns.qs('#aidiEnd').value   = payload.dateRange[1];
      }
      ns.renderCharts(); ns.renderTable();
    });

    // AOI 單點/框選等 selection（語意更偏向「聚焦」）
    window.Bus?.on('aoi:selection', (sel)=>{
      if(!sel) return;
      // 常見欄位: { line, model, aoi, time } 或 { line, aoi } 等
      ns.setFilterSelections({
        line:  sel.line  ? [sel.line]  : undefined,
        aoi:   sel.aoi   ? [sel.aoi]   : undefined,
        model: sel.model ? [sel.model] : undefined
      });
      if (sel.time) {
        const d = new Date(sel.time); d.setMinutes(0,0,0);
        const ds = ns.dateStr(d);
        ns.qs('#aidiStart').value = ds;
        ns.qs('#aidiEnd').value   = ds;
      }
      ns.renderCharts(); ns.renderTable();
    });
  };

  ns.fillDateFromBins = function(){
    const { parseHour, dateStr, qs } = ns;
    const bins = (ns.state.full.time_bins||[])
      .map(parseHour).filter(Boolean).sort((a,b)=>a-b);
    if(bins.length){
      qs('#aidiStart').value = dateStr(bins[0]);
      qs('#aidiEnd').value   = dateStr(bins[bins.length-1]);
    }
  };

  ns.getSel = function(id){
    const elx = ns.qs('#'+id);
    return elx ? [...elx.options].filter(o=>o.selected).map(o=>o.value) : [];
  };

  // <<< 新增：把目前 AIDI 的篩選狀態打包（給 emit 用） >>>
  ns.collectCurrentFilter = function(){
    const pack = {
      line:  ns.getSel('aidiLine'),
      aoi:   ns.getSel('aidiAOI'),
      model: ns.getSel('aidiModel'),
      code:  ns.getSel('aidiCode'),
      dateRange: [
        ns.qs('#aidiStart')?.value || '',
        ns.qs('#aidiEnd')?.value   || ''
      ]
    };
    return pack;
  };

  ns.getFiltered = function(){
    const S = ns.state.full.series || [];
    const L = ns.getSel('aidiLine');
    const A = ns.getSel('aidiAOI');
    const M = ns.getSel('aidiModel');
    const C = ns.getSel('aidiCode');

    const d1 = new Date(ns.qs('#aidiStart').value||''); d1.setHours(0,0,0,0);
    const d2 = new Date(ns.qs('#aidiEnd').value||'');   d2.setHours(23,59,59,999);

    return S.filter(r=>{
      if(L.length && !L.includes(r.line_id)) return false;
      if(A.length && !A.includes(r.aoi_id)) return false;
      if(M.length && !M.includes(r.model_id)) return false;
      if(C.length && !C.includes(r.defect_code)) return false;
      const hh = ns.parseHour(r.time);
      if(d1.toString() !== 'Invalid Date' && hh && hh < d1) return false;
      if(d2.toString() !== 'Invalid Date' && hh && hh > d2) return false;
      return true;
    });
  };

  ns.setFilterSelections = function({ line, aoi, model, code }){
    if (line  && ns.state.mdd.line)   ns.state.mdd.line.setSelected(line);
    if (aoi   && ns.state.mdd.aoi)    ns.state.mdd.aoi.setSelected(aoi);
    if (model && ns.state.mdd.model)  ns.state.mdd.model.setSelected(model);
    if (code  && ns.state.mdd.code)   ns.state.mdd.code.setSelected(code);
  };

  ns.quickFilter = function({line, model, aoi, time}){
    const { dateStr, qs } = ns;
    ns.setFilterSelections({
      line:  line  ? [line]  : undefined,
      aoi:   aoi   ? [aoi]   : undefined,
      model: model ? [model] : undefined
    });
    if(time){
      const d = new Date(time); d.setMinutes(0,0,0);
      const ds = dateStr(d);
      qs('#aidiStart').value = ds;
      qs('#aidiEnd').value   = ds;
    }
    ns.renderCharts(); ns.renderTable();

    // <<< 新增：AIDI -> AOI 同步 >>>
    window.Bus?.emit('aidi:filter', ns.collectCurrentFilter());
  };
})();