// 繪製地圖 + 控制列 + Offset 查表（每 key 一張）
(function(){
  const canvas = document.getElementById('defect-map-canvas');
  const ctx = canvas.getContext('2d');

  function resizeCanvas(){
    const box = document.getElementById('defect-map-container');
    const w = box.clientWidth, h = Math.max(260, box.clientHeight-2);
    canvas.width = w; canvas.height = h;
  }
  window.addEventListener('resize', ()=>{ resizeCanvas(); drawAll(); });
  resizeCanvas();

  function toScreen(x, y){
    // AOI 座標 → 畫布座標（簡單線性，(0,0) 在左下）
    const s = State.Map.scale;
    const px = State.Map.panX;
    const py = State.Map.panY;
    // 這裡假定 y 軸朝上，畫布 y 朝下 → 轉一下
    const sx = (x * s) + px + 40;
    const sy = (canvas.height - (y * s)) + py - 30;
    return [sx, sy];
  }

  function drawAxes(){
    ctx.save();
    ctx.strokeStyle = '#999';
    ctx.lineWidth = 1;
    // X 軸
    ctx.beginPath();
    ctx.moveTo(30, canvas.height-30);
    ctx.lineTo(canvas.width-10, canvas.height-30);
    ctx.stroke();
    // Y 軸
    ctx.beginPath();
    ctx.moveTo(30, canvas.height-30);
    ctx.lineTo(30, 10);
    ctx.stroke();
    // 刻度
    ctx.fillStyle = '#777';
    ctx.font = '10px sans-serif';
    for(let i=0;i<=10;i++){
      const gx = 30 + i*((canvas.width-60)/10);
      ctx.fillRect(gx, canvas.height-32, 1, 4);
    }
    for(let i=0;i<=10;i++){
      const gy = canvas.height-30 - i*((canvas.height-60)/10);
      ctx.fillRect(28, gy, 4, 1);
    }
    ctx.restore();
  }

  function allPoints(){
    const points = [];
    (State.selectedKeys||[]).forEach(key=>{
      const color = Utils.colorForKey(key);
      (State.DefectCache[key]||[]).forEach(d=>{
        // 篩選：Size / Type
        const size = String(d.size ?? d.defect_size ?? '').toUpperCase();
        if(State.Map.sizeFilter.size && !State.Map.sizeFilter.has(size)) return;
        const type = String(d.type ?? d.predict_code ?? '').trim();
        if(State.Map.typeFilter.size && !State.Map.typeFilter.has(type)) return;

        points.push({
          key,
          x: +d.x, y:+d.y,
          size,
          type,
          color,
          d
        });
      });
    });
    return points;
  }

  function computeBounds(){
    const pts = allPoints();
    if(!pts.length) return {minX:0,maxX:100,minY:0,maxY:100};
    let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    pts.forEach(p=>{
      if(p.x<minX) minX=p.x;
      if(p.x>maxX) maxX=p.x;
      if(p.y<minY) minY=p.y;
      if(p.y>maxY) maxY=p.y;
    });
    return {minX,maxX,minY,maxY};
  }

  function radiusBySize(s){
    if(s==='S') return 2;
    if(s==='M') return 3.5;
    if(s==='L') return 5.5;
    if(s==='O') return 7.5;
    return 3;
  }

  function drawAll(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    drawAxes();

    const pts = allPoints();
    // 圈框（若有）
    if(State.Map.box){
      const b = State.Map.box;
      ctx.save();
      ctx.strokeStyle = 'rgba(0,0,0,.4)';
      ctx.setLineDash([5,4]);
      ctx.strokeRect(b.x, b.y, b.w, b.h);
      ctx.restore();
    }

    pts.forEach(p=>{
      const [sx, sy] = toScreen(p.x, p.y);
      ctx.beginPath();
      ctx.arc(sx, sy, radiusBySize(p.size), 0, Math.PI*2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = 0.85;
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // 圖例：每 key 一個色塊
    const leg = document.getElementById('map-legend');
    leg.innerHTML = '';
    (State.selectedKeys||[]).forEach(k=>{
      const div = document.createElement('div');
      div.className = 'legend-item';
      div.innerHTML = `<span class="c" style="background:${Utils.colorForKey(k)}"></span><span class="t">${k}</span>`;
      leg.appendChild(div);
    });
  }

  // ========= 互動 =========
  // 1) 重新建立 Type filters
  Bus.on('rebuild-type-filters', ()=>{
    const host = document.getElementById('type-filters');
    if(!host) return;
    // 清除舊的
    [...host.querySelectorAll('label[data-type]')].forEach(el => el.remove());
    // 動態加入
    const types = Array.from(State.Map.typeFilter.values()).sort();
    types.forEach(t=>{
      const id = `type-${t || 'NA'}`;
      const lbl = document.createElement('label');
      lbl.setAttribute('data-type', t);
      lbl.innerHTML = `<input type="checkbox" id="${id}" checked> ${t||'NA'}`;
      lbl.querySelector('input').addEventListener('change', (ev)=>{
        if(ev.target.checked) State.Map.typeFilter.add(t);
        else State.Map.typeFilter.delete(t);
        drawAll();
      });
      host.appendChild(lbl);
    });
  });

  // 2) Size filters
  ['S','M','L','O'].forEach(s=>{
    document.getElementById(`size-${s}`)?.addEventListener('change', (ev)=>{
      if(ev.target.checked) State.Map.sizeFilter.add(s);
      else State.Map.sizeFilter.delete(s);
      drawAll();
    });
  });

  // 3) Zoom / Reset / Box
  document.getElementById('btnMapReset')?.addEventListener('click', ()=>{
    State.Map.panX=0; State.Map.panY=0; State.Map.scale=0.5; // 給一個視野大一點的 scale
    drawAll();
  });
  document.getElementById('btnZoomIn')?.addEventListener('click', ()=>{
    State.Map.scale *= 1.2; drawAll();
  });
  document.getElementById('btnZoomOut')?.addEventListener('click', ()=>{
    State.Map.scale /= 1.2; drawAll();
  });
  document.getElementById('btnBoxZoom')?.addEventListener('click', ()=>{
    State.Map.boxMode = !State.Map.boxMode;
    toast(State.Map.boxMode ? '框選開啟' : '框選關閉');
  });
  document.getElementById('btnClearBox')?.addEventListener('click', ()=>{
    State.Map.box = null; drawAll();
  });
  document.getElementById('offsetInput')?.addEventListener('change', (e)=>{
    let v = parseFloat(e.target.value||'5'); if(!isFinite(v)||v<=0) v=5;
    State.Map.offset = v;
  });

  // 拖曳/框選/點擊
  let dragging=false, lastX=0,lastY=0, boxStart=null;
  canvas.addEventListener('mousedown', (e)=>{
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX-rect.left, y = e.clientY-rect.top;
    if(State.Map.boxMode){
      boxStart = {x,y};
      State.Map.box = {x,y,w:0,h:0};
    }else{
      dragging=true; lastX=x; lastY=y;
    }
  });
  canvas.addEventListener('mousemove', (e)=>{
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX-rect.left, y = e.clientY-rect.top;
    if(dragging){
      State.Map.panX += (x-lastX);
      State.Map.panY += (y-lastY);
      lastX=x; lastY=y;
      drawAll();
    }else if(boxStart){
      State.Map.box = { x: boxStart.x, y: boxStart.y, w: x-boxStart.x, h: y-boxStart.y };
      drawAll();
    }
  });
  canvas.addEventListener('mouseup', (e)=>{
    if(dragging){ dragging=false; return; }
    if(boxStart){
      // Box-zoom：將框選區對齊畫布
      const b = State.Map.box;
      boxStart=null;
      if(b && Math.abs(b.w)>10 && Math.abs(b.h)>10){
        // 粗略轉換：估算 scale 與平移
        const pts = computeBounds();
        // 這裡簡化處理：把框選當作新視窗（僅平移）
        State.Map.panX -= b.x; State.Map.panY -= (b.y - (canvas.height-b.y-b.h));
        drawAll();
      }
      return;
    }

    // 點擊：做 offset 查表
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX-rect.left, y = e.clientY-rect.top;

    // 反推地圖座標（近似）
    const s = State.Map.scale, px=State.Map.panX, py=State.Map.panY;
    const gx = (x - px - 40)/s;
    const gy = ((canvas.height - y) - py + 30)/s;

    renderOffsetTables(gx, gy);
  });

  function renderOffsetTables(gx, gy){
    const wrap = document.getElementById('map-info-container');
    if(!wrap) return;
    wrap.innerHTML = '';

    const off = State.Map.offset || 5;
    const keys = State.selectedKeys.slice();
    keys.forEach(k=>{
      const box = document.createElement('div');
      box.className = 'offset-block';
      const title = document.createElement('div');
      title.className = 'offset-title';
      title.textContent = `Offset ${off} ｜ ${k}`;
      box.appendChild(title);

      const tbl = document.createElement('table');
      tbl.className = 'table offset-defect-table';
      const thead = document.createElement('thead');
      thead.innerHTML = `<tr><th>#</th><th>x</th><th>y</th><th>size</th><th>type</th><th>img</th></tr>`;
      tbl.appendChild(thead);

      const tbody = document.createElement('tbody');

      const list = (State.DefectCache[k]||[]).filter(d=>{
        return Utils.dist(+d.x, +d.y, gx, gy) <= off;
      }).sort((a,b)=>{
        // 同 run table 的原點→遠排序
        const da = Utils.dist(+a.x,+a.y,0,0);
        const db = Utils.dist(+b.x,+b.y,0,0);
        return Utils.cmpNum(da, db);
      });

      list.forEach((d,i)=>{
        const tr = document.createElement('tr');
        const size = (d.size ?? d.defect_size ?? '').toUpperCase();
        const type = (d.type ?? d.predict_code ?? '');
        const imgBase = State.imgBaseByKey[k] || '';
        const file = d.img || d.pic_name || '';
        const src = Utils.buildImgSrc(imgBase, file);
        tr.innerHTML = `
          <td>${i+1}</td>
          <td>${d.x}</td>
          <td>${d.y}</td>
          <td>${size}</td>
          <td>${type}</td>
          <td class="img-cell"><img loading="lazy" src="${src}" alt=""></td>
        `;
        tbody.appendChild(tr);
      });

      tbl.appendChild(tbody);
      box.appendChild(tbl);
      wrap.appendChild(box);
    });
  }

  // 任何資料變動都重畫
  Bus.on('defect-refresh', drawAll);
  Bus.on('selection-changed', drawAll);

  // 啟動時給個合理的視野
  State.Map.scale = 0.5;
  drawAll();
})();
