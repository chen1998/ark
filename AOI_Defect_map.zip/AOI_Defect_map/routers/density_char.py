# routers/density_char.py
# -*- coding: utf-8 -*-
"""
AIDI /hourly（CSV 版，精簡）
- 讀兩份 CSV：summary_df（每片一列）、rowdata_df（每缺陷一列）
- 依 hour/line/aoi/model 聚合：
    glass_count（片數）、defect_total（缺陷總數）、density=defect_total/glass_count
- 回傳前保證無 NaN/Inf，避免 JSON 序列化錯誤
"""

from __future__ import annotations
from typing import Optional, List, Dict, Tuple
from datetime import datetime, timedelta
import os, re
import numpy as np
import pandas as pd
from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
import json

SUMMARY_CSV = r"D:/Ruby/Project/common_venv/AOI_Defect_map/routers/aoi_summary_aoi200.csv"
RAWDATA_CSV = r"D:/Ruby/Project/common_venv/AOI_Defect_map/routers/aoi200_rawdata_202509.csv"

router = APIRouter(prefix="/aidi", tags=["aidi"])

_SDF: pd.DataFrame | None = None
_RDF: pd.DataFrame | None = None


# ---------------------- 讀檔/清理 ----------------------
def _strip_unnamed(df: pd.DataFrame) -> pd.DataFrame:
    return df.loc[:, ~df.columns.str.contains(r"^Unnamed")].copy()

def _read_csvs(reload: bool = False) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """讀入 CSV + 去掉 Unnamed；low_memory=False 避免 DtypeWarning。"""
    global _SDF, _RDF
    if reload or _SDF is None or _RDF is None:
        sdf = pd.read_csv(SUMMARY_CSV, low_memory=False)
        rdf = pd.read_csv(RAWDATA_CSV, low_memory=False)
        _SDF = _strip_unnamed(sdf)
        _RDF = _strip_unnamed(rdf)
    return _SDF.copy(), _RDF.copy()

def clean_time_cols(df: pd.DataFrame, time_key: str = "scantime") -> pd.DataFrame:
    """補 hour/dayhour/day/year/month/yearmonth；floor('s') 避免警告。"""
    df = df.copy()
    df[time_key] = pd.to_datetime(df[time_key], errors="coerce").dt.floor("s")
    df["hour"]      = df[time_key].dt.strftime("%H")
    df["dayhour"]   = df[time_key].dt.strftime("%m-%d %H")
    df["day"]       = df[time_key].dt.strftime("%m-%d")
    df["bytimehour"] = df[time_key].dt.strftime("%Y-%m-%d %H")  #要在前端chart顯示的時間軸
    return df

def filter_by_time(df: pd.DataFrame, days: Optional[int]=None,
                   start: Optional[str]=None, end: Optional[str]=None,
                   time_key: str="scantime") -> pd.DataFrame:
    """用 days 或 start/end 篩時間（兩者擇一；給 start/end 則忽略 days）"""
    df = df.copy()
    df[time_key] = pd.to_datetime(df[time_key], errors="coerce")
    if start or end:
        if start:
            s = pd.to_datetime(start, errors="coerce")
            df = df[df[time_key] >= s]
        if end:
            e = pd.to_datetime(end, errors="coerce")
            df = df[df[time_key] <= e]
    elif days is not None:
        now = pd.Timestamp.now()
        df = df[df[time_key].between(now - pd.Timedelta(days=days), now)]
    return df

def ensure_columns(sdf: pd.DataFrame, rdf: pd.DataFrame) -> Tuple[pd.DataFrame,pd.DataFrame]:
    """若缺少 aoi_id / glass_side / defect_code 就補基本值。"""
    sdf = sdf.copy(); rdf = rdf.copy()

    def _assign_aoi(df):
        if "aoi_id" not in df.columns:
            if "glass_id" in df.columns:
                codes, _ = pd.factorize(df["glass_id"].astype(str), sort=True)
            else:
                codes = np.zeros(len(df), dtype=int)
            aois = np.array(["AOI200"]) #["AOI100","AOI200","AOI300"]
            df["aoi_id"] = 'aoi200'#aois[codes % len(aois)]
        return df

    sdf = _assign_aoi(sdf)
    rdf = _assign_aoi(rdf)

    if "glass_side" not in sdf.columns:
        sdf["glass_side"] = "TFT"
    if "defect_code" not in sdf.columns:
        sdf["defect_code"] = "N/A"
    return sdf, rdf

def col(df: pd.DataFrame, *names: str) -> str:
    """回傳第一個存在的欄位名（model/model_id 兼容）"""
    for n in names:
        if n in df.columns: return n
    return names[-1]


# ---------------------- 聚合/輸出 ----------------------
def make_hourly_series(sdf: pd.DataFrame, rdf: pd.DataFrame) -> Tuple[List[str], pd.DataFrame]:
    """
    聚合 (line_id, aoi_id, model_id, bytimehour) ：
      glass_count：sdf（每片一列） → 同 bytimehour/line/aoi/model 的片數
      defect_total：rdf（每缺陷一列） → 同 bytimehour/line/aoi/models內所有glass的Defect總數
      density = defect_total / glass_count
    """
    sdf = sdf.copy(); rdf = rdf.copy()
    timekey = 'bytimehour'
    # 欄位相容處理 ->> match 欄位內容 'scantime','glass_id','recipe_id'
    model_s = col(sdf, "model", "model_id")
    model_r = col(rdf, "model", "model_id")

    # 
    g_glass = (sdf.groupby(["line_id","aoi_id",model_s,"glass_side","defect_code",timekey])
                 .agg(glass_count=("glass_id","nunique"))
                 .reset_index()
                 .rename(columns={model_s:"model_id"}))
    
    # 
    if {"line_id","aoi_id",model_r,timekey}.issubset(rdf.columns):
        g_def = (rdf.groupby(["line_id","aoi_id",model_r,timekey])
                   .size().reset_index(name="defect_total")
                   .rename(columns={model_r:"model_id"}))
    else:
        g_def = g_glass[["line_id","aoi_id","model_id",timekey]].copy()
        g_def["defect_total"] = 0
        
    # 合併
    key = ["line_id","aoi_id","model_id",timekey]
    merged = g_glass.merge(g_def, on=key, how="outer")

    # 清理數值欄位，避免 NaN/Inf
    merged["glass_count"]  = merged["glass_count"].fillna(0).astype("int64", errors="ignore")
    merged["defect_total"] = merged["defect_total"].fillna(0).astype("int64", errors="ignore")
    gc = merged["glass_count"].replace(0, np.nan)
    merged["density"] = (merged["defect_total"] / gc).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    print(merged)
    # 時間字串
    #merged["time"] = merged["hour"].dt.strftime("%Y-%m-%d %H:00")

    # 欄位順序
    merged = merged[[
        timekey,"line_id","aoi_id","model_id",
        "glass_side","defect_code",
        "glass_count","defect_total","density"
    ]].sort_values([timekey, "line_id","aoi_id","model_id"])

    time_bins = merged[timekey].drop_duplicates().tolist()
    return time_bins, merged

def build_filters(sdf: pd.DataFrame) -> Dict[str, List[str]]:
    model_s = col(sdf, "model", "model_id")
    return {
        "line_ids":    sorted(sdf["line_id"].dropna().astype(str).unique().tolist()),
        "aoi_ids":     sorted(sdf["aoi_id"].dropna().astype(str).unique().tolist()),
        "models":      sorted(sdf[model_s].dropna().astype(str).unique().tolist()),
        "glass_sides": sorted(sdf["glass_side"].dropna().astype(str).unique().tolist()),
        "defect_codes":sorted(sdf["defect_code"].dropna().astype(str).unique().tolist()),
    }

def df_json_safe_records(df: pd.DataFrame) -> list[dict]:
    # 1) 先把 ±Inf 變 NaN
    out = df.replace([np.inf, -np.inf], np.nan).copy()

    # 2) 數值欄位一律 fillna(0)
    num_cols = out.select_dtypes(include=[np.number]).columns
    out[num_cols] = out[num_cols].fillna(0)

    # 3) 任何 datetime64 → 轉為字串（避免 Timestamp 殘留）
    for c in out.columns:
        if np.issubdtype(out[c].dtype, np.datetime64):
            out[c] = out[c].dt.strftime("%Y-%m-%d %H:%M:%S")
    #print(out)
    # 4) 最保險作法：用 pandas 的 to_json（會把 NaN 轉 null）
    #    再轉回 Python list[dict]，這樣丟給 JSONResponse 就不會再報
    return json.loads(out.to_json(orient="records"))



# ---------------------- API ----------------------
@router.get("/hourly")
def api_aidi_hourly(
    days: Optional[int] = Query(default=7, description="最近 N 天；若提供 start/end 則忽略"),
    start: Optional[str] = Query(default=None, description="YYYY-MM-DD"),
    end:   Optional[str] = Query(default=None, description="YYYY-MM-DD"),
    reload: bool = Query(default=False, description="true=重新讀 CSV"),
):
    sdf, rdf = _read_csvs(reload=reload)

    # 時間篩選
    sdf = filter_by_time(sdf, days=days if not start and not end else None, start=start, end=end)
    rdf = filter_by_time(rdf, days=days if not start and not end else None, start=start, end=end)
    
    # 清時間 + 最小欄位補齊
    sdf = clean_time_cols(sdf, "scantime")
    rdf = clean_time_cols(rdf, "scantime")
    sdf, rdf = ensure_columns(sdf, rdf)

    sdf['line_id'] = 'CAAOI202' #config
    all_summary_dict = {}
    for line, line_rows in sdf.groupby(['line_id']):
        line = line[0]
        all_summary_dict[line] = {}
        for aoi, aoi_rows in line_rows.groupby(['aoi_id']):
            aoi = aoi[0]
            aoi_rows = aoi_rows[[ 'bytimehour', 'model','scantime','glass_id', 'recipe_id', 'over_defect_count', 'large_defect_count', 'middle_defect_count', 'small_defect_count']]
            aoi_rows.reset_index(inplace = True, drop = True)
            aoi_rows['scantime'] = aoi_rows['scantime'].apply(lambda x: str(x))
            #aoi_rows.fillna('', inplace = True)
            all_summary_dict[line][aoi] = aoi_rows.to_dict(orient = 'index')
    #print(all_summary_dict)
    # 聚合
    time_bins, series_df = make_hourly_series(sdf, rdf)
    
    filters = build_filters(sdf)
    series = df_json_safe_records(series_df)
    payload = {
        "all_summary_dict":all_summary_dict,
        "time_bins": time_bins,
        "series": series,  
        "filters": filters,
    }
    #print("time_bins", time_bins)
    #print("series", series  )
    #print("filters", filters)
    return JSONResponse(payload)  # 或 JSONResponse(jsonable_encoder(payload)) 都可以


def _parse_hour(s: str):
    """
    解析 'YYYY-MM-DD HH:00' 或 ISO 'YYYY-MM-DDTHH:MM' -> 整點 datetime
    """
    if not s:
        return None
    ss = s.replace('T', ' ')
    m = re.match(r'^(\d{4}-\d{2}-\d{2})\s+(\d{2})', ss)
    if not m:
        return None
    return datetime.strptime(f"{m.group(1)} {m.group(2)}:00:00", "%Y-%m-%d %H:%M:%S")

def _to_yyyymm(dt: datetime) -> str:
    return dt.strftime("%Y%m")

# === 依你的實際資料位置調整：月檔命名規則 ===
# 需求：檔名 = aoi_id + 'rowdata' + yyyymm，可能有底線或大小寫差異
# 我們提供多個候選樣式，找到就讀。
def _resolve_rowdata_csv(aoi_id: str, yyyymm: str) -> str:
    """
    回傳 rowdata CSV 的實際路徑。依序嘗試以下檔名：
    - {aoi_id}_rowdata_{yyyymm}.csv
    - {aoi_id}rowdata{yyyymm}.csv
    - rowdata_{aoi_id}_{yyyymm}.csv
    目錄的部份請依你的實際部署調整：
      - ./data/rowdata/
      - ./dataset/rowdata/
      - ./csv/
    """
    aoi = str(aoi_id)
    candidates = [
        f"{aoi}_rowdata_{yyyymm}.csv",
        f"{aoi}rowdata{yyyymm}.csv",
        f"rowdata_{aoi}_{yyyymm}.csv",
    ]
    roots = [
        os.path.join(os.getcwd(), "data", "rowdata"),
        os.path.join(os.getcwd(), "dataset", "rowdata"),
        os.path.join(os.getcwd(), "csv"),
    ]
    for root in roots:
        for name in candidates:
            p = os.path.join(root, name)
            if os.path.exists(p):
                return p
    # 找不到就回空字串（上層 fallback）
    return ""

def _read_rowdata(aoi_id: str, yyyymm: str) -> pd.DataFrame:
    """
    優先讀月檔；若找不到月檔，回退到你原本聚合時使用的 rowdata 載入方式（若檔案已有）。
    """
    csv_path = _resolve_rowdata_csv(aoi_id, yyyymm)
    if csv_path and os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
    else:
        # Fallback：若你的檔案裡有 load_rowdata_df(reload=False) 之類的共用函式，請改成你的名稱：
        try:
            df = pd.read_csv(csv_path)  # 若你檔案有此函式，會讀全部月份
            df = _strip_unnamed(df)
            # 僅取該月份（用 scantime 切）
            m0 = pd.to_datetime(df["scantime"], errors="coerce")
            df = df.loc[(m0.dt.strftime("%Y%m") == yyyymm)]
        except Exception:
            raise HTTPException(404, detail=f"rowdata csv not found for {aoi_id}-{yyyymm}")
    # 基本欄位保證（沿用你檔案既有的 ensure_columns 名稱）
    req = ["scantime","line_id","aoi_id","model_id",
           "glass_id","recipe_id","x","y","defect_size","defect_code","pic_name"]
    for k in req:
        if k not in df.columns:
            df[k] = np.nan if k in ("x","y") else ""
    # 型別與清洗
    df["scantime"] = pd.to_datetime(df["scantime"], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    return df

@router.get("/defects_query")
def api_aidi_defects_query(
    # 模式一（bar 點擊）：以 hour + line/aoi/model
    time: str | None = Query(None, description="小時：YYYY-MM-DD HH:00 或 ISO 小時"),
    line_id: str | None = Query(None),
    aoi_id: str | None = Query(None),
    model_id: str | None = Query(None),
    # 模式二（table 細項勾選）：以 run 三鍵
    scantime: str | None = Query(None, description="YYYY-MM-DD HH:MM:SS"),
    glass_id: str | None = Query(None),
    recipe_id: str | None = Query(None),

    defect_codes: str | None = Query(None, description="多值以逗號分隔"),
    sizes: str | None = Query(None, description="多值以逗號分隔 S,M,L,O"),
    output: str = Query("points", description="points|runs；points=回傳座標點，runs=回傳細項列表")
):
    """
    依參數決定：
      - 模式一（bar 點擊）：需有 time + line_id + aoi_id + model_id
        * 讀 aoi_id 對應 yyyymm 月檔，篩該小時 [time, time+1h)，再依 line/aoi/model 篩
      - 模式二（table 細項勾選）：需有 scantime + glass_id + recipe_id + aoi_id (+line_id 可助篩)
        * 讀該月份月檔，直接以三鍵（+aoi_id/line_id）篩

    output:
      - points：回傳 {count, points:[{x,y,size,code,glass_id,recipe_id,scantime,pic_name}]}
      - runs：   回傳 {count, runs:[{scantime,glass_id,recipe_id,defect_count}]}
                 （僅在模式一使用，列出該 group 下的各片細項與其 defect_count）
    """
    # ---- 解析模式 ----
    mode1 = (time and line_id and aoi_id and model_id)
    mode2 = (scantime and glass_id and recipe_id and aoi_id)

    if not (mode1 or mode2):
        raise HTTPException(400, "缺少必要參數：模式一需 time/line_id/aoi_id/model_id；模式二需 scantime/glass_id/recipe_id/aoi_id")

    # ---- 解析時間與月檔 ----
    if mode1:
        t0 = _parse_hour(time)
        if t0 is None:
            raise HTTPException(400, "time 格式錯誤，需 'YYYY-MM-DD HH:00'")
        yyyymm = _to_yyyymm(t0)
    else:  # mode2
        try:
            t_sc = datetime.strptime(scantime, "%Y-%m-%d %H:%M:%S")
        except Exception:
            # 允許 HH:MM:SS 缺秒，做些寬鬆處理
            try:
                t_sc = datetime.strptime(scantime, "%Y-%m-%d %H:%M")
            except Exception:
                raise HTTPException(400, "scantime 格式錯誤，需 'YYYY-MM-DD HH:MM:SS'")
        yyyymm = _to_yyyymm(t_sc)

    # ---- 讀月份 rowdata ----
    df = _read_rowdata(aoi_id, yyyymm)

    # ---- 套條件 ----
    if mode1:
        t0 = _parse_hour(time)
        t1 = t0 + timedelta(hours=1)
        m = (
            (df["aoi_id"].astype(str) == str(aoi_id)) &
            (df["line_id"].astype(str) == str(line_id)) &
            (df["model_id"].astype(str) == str(model_id)) &
            (df["scantime"] >= t0) & (df["scantime"] < t1)
        )
        df = df.loc[m]
    else:
        m = (
            (df["aoi_id"].astype(str) == str(aoi_id)) &
            (df["glass_id"].astype(str) == str(glass_id)) &
            (df["recipe_id"].astype(str) == str(recipe_id))
        )
        if line_id:
            m = m & (df["line_id"].astype(str) == str(line_id))
        # scantime 等於該片（允許 ±5 分鐘浮動可選；這裡先精準等於）
        m = m & (df["scantime"] == pd.to_datetime(scantime, errors="coerce"))
        df = df.loc[m]

    # 缺陷 code/size 過濾
    if defect_codes:
        allow = set([c.strip() for c in defect_codes.split(",") if c.strip()])
        if len(allow):
            df = df[df["defect_code"].astype(str).isin(allow)]
    if sizes:
        allow = set([s.strip().upper() for s in sizes.split(",") if s.strip()])
        if len(allow):
            df = df[df["defect_size"].astype(str).str.upper().isin(allow)]

    # ---- output 分支 ----
    if output == "runs":
        if not mode1:
            raise HTTPException(400, "runs 輸出僅支援模式一（需提供 time/line_id/aoi_id/model_id）")
        # 以（scantime, glass_id, recipe_id）彙總 defect_count
        if df.empty:
            return {"count": 0, "runs": []}
        grp = (df
               .groupby(["scantime","glass_id","recipe_id"], dropna=False)
               .size()
               .reset_index(name="defect_count"))
        grp["scantime"] = grp["scantime"].dt.strftime("%Y-%m-%d %H:%M:%S")
        grp = grp.sort_values(["scantime","glass_id","recipe_id"]).to_dict(orient="records")
        return {"count": len(grp), "runs": grp}

    # points
    if df.empty:
        return {"count": 0, "points": []}
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=["x","y"])
    pts = [
        {
            "x": float(r["x"]),
            "y": float(r["y"]),
            "size": str(r.get("defect_size","")),
            "code": str(r.get("defect_code","")),
            "pic_name": str(r.get("pic_name","")),
            "glass_id": str(r.get("glass_id","")),
            "recipe_id": str(r.get("recipe_id","")),
            "scantime": pd.to_datetime(r["scantime"]).strftime("%Y-%m-%d %H:%M:%S") if pd.notna(r["scantime"]) else ""
        }
        for _, r in df.iterrows()
    ]
    return {"count": len(pts), "points": pts}

