// api.js — 串接 /api/run-info 與 /api/defect-data，建立 line tabs 與過濾行為
(function(){
  const BASE = (window.API_BASE || '').replace(/\/$/, '');

  async function fetchJSON(path, params){
    const url = new URL((BASE || '') + path, window.location.origin);
    if(params){ Object.entries(params).forEach(([k,v]) => (v!==undefined && v!==null && v!=='') && url.searchParams.set(k, v)); }
    const res = await fetch(url.toString(), { credentials: 'omit' });
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function fetchAllRunInfo(){
    return fetchJSON('/api/run-info');
  }

  async function fetchRunInfoByLineAndDates(line, start, end){
    return fetchJSON('/api/run-info', { line_id: line, start, end });
  }

  async function fetchDefects(key, line){
    return fetchJSON('/api/defect-data', { key, line_id: line });
  }

  function buildLineTabs(list){
    const cont = document.getElementById('all-tab-container');
    if(!cont) return;
    cont.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'line-tabs';
    list.forEach((line, idx)=>{
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (idx===0 ? ' active' : '');
      btn.textContent = line;
      btn.addEventListener('click', ()=>{
        row.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        State.currentLine = line;
        const rows = (State.AllRunInfo[line] || []);
        Bus.emit('render-run-info', rows);
        // 清空選取與地圖/畫廊
        State.selectedKeys = [];
        Bus.emit('selection-changed', State.selectedKeys);
        document.getElementById('sel-count').textContent = '0';
        document.getElementById('gallery-grid').innerHTML = '';
      });
      row.appendChild(btn);
    });
    cont.appendChild(row);
  }

  async function init(){
    // 系統 tab（預先保留切頁）
    document.querySelectorAll('.sys-tab').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        document.querySelectorAll('.sys-tab').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const v = btn.dataset.view;
        // 目前只有 defect-map 視圖，其餘先預留占位
        if(v!=='defect-map'){
          toast('此頁將於後續版本提供');
        }
      });
    });

    // 日期套用/清空
    const btnApply = document.getElementById('applyDates');
    const btnClear = document.getElementById('clearDates');
    btnApply.addEventListener('click', async ()=>{
      const s = document.getElementById('fDateFrom').value || '';
      const e = document.getElementById('fDateTo').value || '';
      const line = State.currentLine;
      if(!line){ toast('尚未選擇產線'); return; }
      try{
        const data = await fetchRunInfoByLineAndDates(line, s, e);
        if(data && data.UniRunInfoTableData){
          const rows = Object.values(data.UniRunInfoTableData);
          State.AllRunInfo[line] = rows;
          Bus.emit('render-run-info', rows);
        }
      }catch(err){ console.error('[api] dates fetch error:', err); toast('日期查詢失敗'); }
    });
    btnClear.addEventListener('click', ()=>{
      document.getElementById('fDateFrom').value = '';
      document.getElementById('fDateTo').value = '';
    });

    // Query 搜尋
    document.getElementById('applyQuery').addEventListener('click', ()=>{
      State.filters.glassORrecipe = document.getElementById('fQuery').value.trim();
      Bus.emit('filters-changed');
    });
    document.getElementById('clearQuery').addEventListener('click', ()=>{
      document.getElementById('fQuery').value = '';
      State.filters.glassORrecipe = '';
      Bus.emit('filters-changed');
    });

    // 初始載入
    try{
      const payload = await fetchAllRunInfo();
      State.LineTabs = payload.AllLineTabs || [];
      // 將每個 line 的 dict 轉成陣列
      const all = payload.AllRunInfoTableData || {};
      State.AllRunInfo = {};
      Object.keys(all).forEach(line=>{
        const dict = all[line] || {};
        State.AllRunInfo[line] = Object.values(dict);
      });
      buildLineTabs(State.LineTabs);
      // 預設顯示第一個 line
      if(State.LineTabs.length){
        State.currentLine = State.LineTabs[0];
        Bus.emit('render-run-info', State.AllRunInfo[State.currentLine] || []);
      }
    }catch(err){
      console.error('[api.js] init error:', err);
      toast('載入初始資料失敗');
    }

    // 監聽：需要缺陷資料
    Bus.on('request-defects', async (keys)=>{
      const line = State.currentLine;
      const need = (keys||[]).filter(k => !State.DefectCache.has(k));
      for(const k of need){
        try{
          const res = await fetchDefects(k, line);
          const arr = (res && res.defects) ? res.defects : [];
          State.DefectCache.set(k, arr);
          Bus.emit('defect-data-loaded', { key:k, defects: arr });
        }catch(err){
          console.error('[api] fetchDefects error:', err);
        }
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
