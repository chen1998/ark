AIDI Sub Table Points Patch (v2)
--------------------------------
放置位置：
- static/js/aidi/table.js  (主檔案，必需)
- static/js/aidi/service2_patch.js  (可選，如果你現有的 service2.js 沒有兩個 helper 才需要載入)
- routers/density_char_patch.py  (可選，僅示意，如果你的後端已支援就不用)

重點行為：
1) 展開 btn：
   - Sub table 顯示來源 = allSummary（以 line_id/aoi_id/model_id/bytimehour 篩選）。
   - 另外（可選）以 hour key 打 defects_query(output=points) 做快取；回傳只作為之後合併繪圖的資料來源，不顯示。

2) 勾選 Sub table：
   - 送 per-glass 的 defects_query(output=points)，以 scantime/glass_id/recipe_id/aoi_id/line_id 當 keys。
   - 回傳 defect_rows 只拿來畫地圖座標（不顯示在表格）。

地圖對接：
- 若你的前端提供 ns.setDefectOverlay(points) 就直接呼這個方法。
- 否則會向 #map-viewport 派發 aidi:defect-overlay 事件，detail.points 是座標陣列。

注意：
- bytimehour 正規化成 'YYYY-MM-DD HH:00' 傳給後端的 'time'。
- 回傳 JSON key 可用 defect_rows 或 points 或 rows，前端都有做 normalize。
