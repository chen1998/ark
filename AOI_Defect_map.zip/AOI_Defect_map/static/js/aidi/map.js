// 迷你 Map：軸刻度、滑鼠拖曳平移、滾輪縮放、框選、渲染點
(function(){
    const ns = window.AIDI;
  
    class MiniMap {
      constructor(canvasSel){
        this.canvas = ns.qs(canvasSel);
        this.ctx = this.canvas.getContext('2d');
        // 視窗大小 & 世界轉換
        this.viewport = {x:0, y:0, w:1000, h:1000}; // 世界座標的視窗
        this.scale = 1; // 畫素/世界單位
        this.pan = {x:0, y:0}; // 以世界原點為基準的平移
        this.dragging = false;
        this.lastPos = null;
        this.boxZoom = null; // {x0,y0,x1,y1} in screen space
        this.points = [];
        this.theme = {
          bg: '#0f1115',
          axis: '#2b3240',
          grid: '#1b2330',
          tick: '#6c7b8c',
          point: '#4ea1ff',
          pointS: '#9fbad1',
          pointM: '#5ec18f',
          pointL: '#ffb85c',
          pointO: '#ff6b6b'
        };
        this.attachEvents();
        this.resizeObserver = new ResizeObserver(()=>this.resize());
        this.resizeObserver.observe(this.canvas.parentElement);
        this.resize();
      }
  
      resize(){
        // 讓 canvas 自適應容器
        const box = this.canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width  = Math.max(200, Math.floor(box.width  * dpr));
        this.canvas.height = Math.max(200, Math.floor(box.height * dpr));
        this.ctx.setTransform(dpr,0,0,dpr,0,0);
        this.draw();
      }
  
      // 世界<->螢幕 轉換
      worldToScreen(wx, wy){
        const sx = (wx - this.pan.x) * this.scale;
        const sy = (wy - this.pan.y) * this.scale;
        return [sx, this.canvas.height / (window.devicePixelRatio||1) - sy];
      }
      screenToWorld(sx, sy){
        const h = this.canvas.height / (window.devicePixelRatio||1);
        const wx = sx / this.scale + this.pan.x;
        const wy = (h - sy) / this.scale + this.pan.y;
        return [wx, wy];
      }
  
      setData(points, bbox){
        this.points = points || [];
        // 自動視窗：以資料外框為主（留邊 5%）
        if(bbox && isFinite(bbox.xmin) && isFinite(bbox.ymin) && isFinite(bbox.xmax) && isFinite(bbox.ymax)){
          const pad = 0.05;
          const w = bbox.xmax - bbox.xmin || 1, h = bbox.ymax - bbox.ymin || 1;
          const cx = bbox.xmin - w*pad, cy = bbox.ymin - h*pad;
          this.pan = {x: cx, y: cy};
          const cw = (bbox.xmax - bbox.xmin) * (1+2*pad);
          const ch = (bbox.ymax - bbox.ymin) * (1+2*pad);
          const viewW = this.canvas.clientWidth || 600;
          const viewH = this.canvas.clientHeight || 300;
          this.scale = Math.min(viewW / cw, viewH / ch);
        }
        this.draw();
      }
  
      attachEvents(){
        const canvas = this.canvas;
        // 拖曳平移
        canvas.addEventListener('mousedown', (e)=>{
          this.dragging = true;
          this.lastPos = {x:e.offsetX, y:e.offsetY};
        });
        window.addEventListener('mouseup', ()=>{ this.dragging=false; this.lastPos=null; });
        canvas.addEventListener('mousemove', (e)=>{
          if(this.dragging && this.lastPos){
            const dx = e.offsetX - this.lastPos.x;
            const dy = e.offsetY - this.lastPos.y;
            // 轉回世界位移
            this.pan.x -= dx / this.scale;
            this.pan.y += dy / this.scale;
            this.lastPos = {x:e.offsetX, y:e.offsetY};
            this.draw();
          }
        });
  
        // 滾輪縮放（以滑鼠位置為中心）
        canvas.addEventListener('wheel', (e)=>{
          e.preventDefault();
          const factor = (e.deltaY < 0) ? 1.1 : 0.9;
          const mx = e.offsetX, my = e.offsetY;
          const [wx, wy] = this.screenToWorld(mx, my);
          this.scale *= factor;
          // 調整 pan 以固定滑鼠下的世界點
          const [sx2, sy2] = this.worldToScreen(wx, wy);
          const dx = mx - sx2, dy = my - sy2;
          this.pan.x -= dx / this.scale;
          this.pan.y += dy / this.scale;
          this.draw();
        }, { passive:false });
      }
  
      drawAxes(){
        const ctx = this.ctx, W = this.canvas.width/(window.devicePixelRatio||1), H = this.canvas.height/(window.devicePixelRatio||1);
        ctx.save();
        // 背景
        ctx.fillStyle = this.theme.bg;
        ctx.fillRect(0,0,W,H);
  
        // 刻度估算（讓網格間距大致 80px）
        const pxTarget = 80;
        const stepWorld = this.niceStep(pxTarget / this.scale);
        const [w0x, w0y] = this.screenToWorld(0, H);
        const [w1x, w1y] = this.screenToWorld(W, 0);
  
        const startX = Math.floor(w0x / stepWorld) * stepWorld;
        const endX   = Math.ceil (w1x / stepWorld) * stepWorld;
        const startY = Math.floor(w0y / stepWorld) * stepWorld;
        const endY   = Math.ceil (w1y / stepWorld) * stepWorld;
  
        // 網格 + 刻度
        ctx.strokeStyle = this.theme.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for(let x=startX; x<=endX; x+=stepWorld){
          const [sx] = this.worldToScreen(x, 0);
          ctx.moveTo(sx, 0); ctx.lineTo(sx, H);
        }
        for(let y=startY; y<=endY; y+=stepWorld){
          const [,sy] = this.worldToScreen(0, y);
          ctx.moveTo(0, sy); ctx.lineTo(W, sy);
        }
        ctx.stroke();
  
        // 座標軸（x=0, y=0）
        ctx.strokeStyle = this.theme.axis;
        ctx.beginPath();
        const [sx0] = this.worldToScreen(0,0);
        const [,sy0] = this.worldToScreen(0,0);
        ctx.moveTo(sx0, 0); ctx.lineTo(sx0, H);
        ctx.moveTo(0, sy0); ctx.lineTo(W, sy0);
        ctx.stroke();
  
        // 文字標籤
        ctx.fillStyle = this.theme.tick;
        ctx.font = '11px system-ui, -apple-system, Segoe UI, Roboto';
        for(let x=startX; x<=endX; x+=stepWorld){
          const [sx] = this.worldToScreen(x, 0);
          ctx.fillText(String(Math.round(x)), sx+2, 12);
        }
        for(let y=startY; y<=endY; y+=stepWorld){
          const [,sy] = this.worldToScreen(0, y);
          ctx.fillText(String(Math.round(y)), 2, sy-2);
        }
        ctx.restore();
      }
  
      niceStep(raw){
        // 產生 1-2-5 尺度
        const pow = Math.pow(10, Math.floor(Math.log10(raw||1)));
        const unit = raw / pow;
        let m = 1;
        if (unit > 5) m = 10; else if (unit > 2) m = 5; else if (unit > 1) m = 2;
        return m * pow;
      }
  
      drawPoints(){
        const ctx = this.ctx;
        ctx.save();
        this.points.forEach(p=>{
          const [sx, sy] = this.worldToScreen(p.x, p.y);
          const r = this.radiusBySize(p.size);
          ctx.beginPath();
          ctx.arc(sx, sy, r, 0, Math.PI*2);
          ctx.fillStyle = this.colorBySize(p.size);
          ctx.fill();
        });
        ctx.restore();
      }
  
      colorBySize(size){
        const s = String(size||'').toUpperCase();
        if (s === 'L') return this.theme.pointL;
        if (s === 'M') return this.theme.pointM;
        if (s === 'S') return this.theme.pointS;
        return this.theme.pointO; // 其他/超大
      }
      radiusBySize(size){
        const s = String(size||'').toUpperCase();
        if (s === 'L') return 3.5;
        if (s === 'M') return 3.0;
        if (s === 'S') return 2.5;
        return 4.0;
      }
  
      draw(){
        this.drawAxes();
        this.drawPoints();
      }
    }
  
    ns.MiniMap = MiniMap;
  
    // 提供一個統一入口：由 charts 或 table 呼叫，載點並畫圖
    ns.requestMiniMap = async function({ line_id, aoi_id, model_id, time }){
      try{
        const codeSel = ns.getSel ? ns.getSel('aidiCode') : [];
        const sizes = []; // 若你右側有 size 選單，讀進來；目前先空
        const { points } = await ns.fetchHourlyPoints({ time, line_id, aoi_id, model_id, defect_codes: codeSel, sizes });
        if (!ns._miniMap) ns._miniMap = new ns.MiniMap('#aidi-mini-map');
        // 自動計算邊界
        const xs = points.map(p=>p.x), ys = points.map(p=>p.y);
        const bbox = points.length ? { xmin: Math.min(...xs), xmax: Math.max(...xs), ymin: Math.min(...ys), ymax: Math.max(...ys) } : null;
        ns._miniMap.setData(points, bbox);
      }catch(e){
        console.error(e);
        if (!ns._miniMap) ns._miniMap = new ns.MiniMap('#aidi-mini-map');
        ns._miniMap.setData([], null);
      }
    };
  
  })();
  