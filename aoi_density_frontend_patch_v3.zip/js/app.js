// app.js (ES Module)
import { resetSummaryFilter } from './api.js';

const el = (s) => document.querySelector(s);
const statusEl = el('#status');
const chartsRoot = el('#charts');

function setStatus(msg) { statusEl.textContent = msg; }

function fmtToDisplay(ts) {
  // input: 'YYYY-MM-DD HH:MM:SS' → 'yy-mm-dd hh'
  if (!ts) return '';
  const y = ts.slice(2,4);
  const m = ts.slice(5,7);
  const d = ts.slice(8,10);
  const hh = ts.slice(11,13);
  return `${y}-${m}-${d} ${hh}`;
}
function backToFullHour(s) {
  // 'yy-mm-dd hh' → 'YYYY-MM-DD HH:00:00'（假設 20xx）
  // 以 20 開頭合理（此系統看起來是 2025yyy）
  const yy = s.slice(0,2);
  const y4 = `20${yy}`;
  const M = s.slice(3,5);
  const D = s.slice(6,8);
  const hh = s.slice(9,11);
  return `${y4}-${M}-${D} ${hh}:00:00`;
}

function uniq(arr) {
  return Array.from(new Set(arr.filter(x => x !== undefined && x !== null && `${x}`.trim() !== '')));
}
function setOptions(select, values) {
  const cur = new Set(Array.from(select.selectedOptions).map(o => o.value));
  select.innerHTML = '';
  values.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    if (cur.has(v)) opt.selected = true;
    select.appendChild(opt);
  });
}

function extractFilterValues(FilterData) {
  // 從列資料取唯一值填選單
  const pick = (k) => uniq(FilterData.map(r => r[k]).map(x => (x==null?'':`${x}`)));
  const line_id = pick('line_id');
  const aoi = pick('aoi');
  const model = pick('model');
  const gtype = pick('glass_type');
  const code = pick('ai_code_1');
  // pi_hour: 轉成 yy-mm-dd hh
  const pi = uniq(FilterData.map(r => fmtToDisplay(r.pi_hour)));
  return { line_id, aoi, model, gtype, code, pi };
}

function ensureChartsRoot() {
  chartsRoot.innerHTML = '';
}

function groupKeys(chartData) {
  // 取所有 line_id, aoi 的組合
  const combos = [];
  for (const line_id of Object.keys(chartData || {})) {
    const objAoi = chartData[line_id] || {};
    for (const aoi of Object.keys(objAoi)) {
      combos.push([line_id, aoi]);
    }
  }
  return combos;
}

function aggregateGroup(groupObj) {
  // groupObj = chart[line_id][aoi]
  // 往下把 model, glass_type, ai_code_1 合併在同一時間點
  // 回傳 { x: [ts...], stacks: {S,M,L,O,UNK}, n_glasses: [..] }
  const acc = new Map(); // ts -> {S,M,L,O,UNK,n_glasses}
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    // 找到最內層：node[pi_hour] = {...}
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (v && typeof v === 'object' && 'n_rows' in v && 'small_defect_count' in v) {
        const ts = k;
        const rec = acc.get(ts) || {S:0,M:0,L:0,O:0,UNK:0,n:0};
        rec.S += Number(v.small_defect_count||0);
        rec.M += Number(v.middle_defect_count||0);
        rec.L += Number(v.large_defect_count||0);
        rec.O += Number(v.over_defect_count||0);
        rec.UNK += Number(v.unknown_defect_count||0);
        rec.n  += Number(v.n_glasses||0);
        acc.set(ts, rec);
      } else {
        walk(v);
      }
    }
  };
  walk(groupObj);

  const allTs = Array.from(acc.keys()).sort();
  const series = {
    x: allTs.map(fmtToDisplay),
    S: allTs.map(t => acc.get(t).S),
    M: allTs.map(t => acc.get(t).M),
    L: allTs.map(t => acc.get(t).L),
    O: allTs.map(t => acc.get(t).O),
    UNK: allTs.map(t => acc.get(t).UNK),
    n: allTs.map(t => acc.get(t).n),
  };
  return series;
}

function renderOneChart(dom, title, series) {
  const chart = echarts.init(dom);
  const option = {
    title: { text: title, left: 'center', top: 0, textStyle: { fontSize: 12 } },
    tooltip: { trigger: 'axis' },
    legend: { top: 22 },
    grid: { left: 50, right: 50, top: 60, bottom: 40 },
    xAxis: { type: 'category', data: series.x, axisLabel: { rotate: 45 } },
    yAxis: [
      { type: 'value', name: 'defects (count, S/M/L/O/UNK)', position: 'left' },
      { type: 'value', name: 'n_glasses', position: 'right' },
    ],
    series: [
      { name:'S', type:'bar', stack:'def', data: series.S },
      { name:'M', type:'bar', stack:'def', data: series.M },
      { name:'L', type:'bar', stack:'def', data: series.L },
      { name:'O', type:'bar', stack:'def', data: series.O },
      { name:'UNK', type:'bar', stack:'def', data: series.UNK },
      { name:'n_glasses', type:'line', yAxisIndex:1, data: series.n },
    ]
  };
  chart.setOption(option);
  return chart;
}

function renderCharts(chartData) {
  ensureChartsRoot();
  const combos = groupKeys(chartData);
  if (!combos.length) {
    chartsRoot.innerHTML = '<div class="panel">沒有符合條件的資料</div>';
    return;
  }
  const charts = [];
  combos.forEach(([line_id, aoi]) => {
    const section = document.createElement('div');
    section.className = 'chart-wrap';
    section.innerHTML = `<div class="chart-title"><div><b>${line_id}</b> × <b>${aoi}</b></div></div><div class="chart"></div>`;
    chartsRoot.appendChild(section);
    const dom = section.querySelector('.chart');
    const series = aggregateGroup(chartData[line_id][aoi]);
    charts.push(renderOneChart(dom, `${line_id} × ${aoi}`, series));
  });
  // 回傳 charts 以利後續 resize 等
  return charts;
}

function getMulti(select) {
  return Array.from(select.selectedOptions).map(o=>o.value).filter(Boolean);
}

function parseDateInputs() {
  const s = el('#start').value;
  const e = el('#end').value;
  if (!s || !e) return null;
  // datetime-local → 'YYYY-MM-DDTHH:MM' → 轉空白與補秒
  const fmt = (x) => x.replace('T',' ') + ':00';
  return [fmt(s), fmt(e)];
}

async function boot() {
  setStatus('載入中…');
  try {
    const data = await resetSummaryFilter();
    setStatus('載入完成');

    // 填篩選器
    const { FilterData, ChartDataDict } = data;
    const vals = extractFilterValues(FilterData);
    setOptions(el('#line_id'), vals.line_id);
    setOptions(el('#aoi'), vals.aoi);
    setOptions(el('#model'), vals.model);
    setOptions(el('#glass_type'), vals.gtype);
    setOptions(el('#ai_code_1'), vals.code);
    setOptions(el('#pi_hour'), vals.pi);

    // 畫圖
    renderCharts(ChartDataDict);

    // 綁定按鈕
    el('#apply').addEventListener('click', async () => {
      const dates = parseDateInputs();
      const filters = {};
      const addIf = (k, v) => { if (v && v.length) filters[k]=v; };
      addIf('line_id', getMulti(el('#line_id')));
      addIf('aoi', getMulti(el('#aoi')));
      addIf('model', getMulti(el('#model')));
      addIf('glass_type', getMulti(el('#glass_type')));
      addIf('ai_code_1', getMulti(el('#ai_code_1')));
      addIf('defect_size', getMulti(el('#defect_size')));
      // glass_id: 逗號切
      const gtxt = el('#glass_id').value.trim();
      if (gtxt) { filters['glass_id'] = gtxt.split(',').map(s=>s.trim()).filter(Boolean); }
      // pi_hour: yy-mm-dd hh → 後端 'YYYY-MM-DD HH:00:00'
      const ph = getMulti(el('#pi_hour'));
      if (ph.length) { filters['pi_hour'] = ph.map(backToFullHour); }

      setStatus('查詢中…');
      const resp = await resetSummaryFilter({ dates, filters });
      setStatus('完成');
      const vals2 = extractFilterValues(resp.FilterData);
      setOptions(el('#line_id'), vals2.line_id);
      setOptions(el('#aoi'), vals2.aoi);
      setOptions(el('#model'), vals2.model);
      setOptions(el('#glass_type'), vals2.gtype);
      setOptions(el('#ai_code_1'), vals2.code);
      setOptions(el('#pi_hour'), vals2.pi);
      renderCharts(resp.ChartDataDict);
    });

    el('#reset').addEventListener('click', async () => {
      el('#start').value = '';
      el('#end').value = '';
      ['line_id','aoi','model','glass_type','ai_code_1','defect_size','pi_hour'].forEach(id => {
        const sel = el('#'+id);
        if (sel) Array.from(sel.options).forEach(o => o.selected=false);
      });
      el('#glass_id').value='';
      setStatus('重載資料…');
      const resp = await resetSummaryFilter();
      setStatus('完成');
      const vals3 = extractFilterValues(resp.FilterData);
      setOptions(el('#line_id'), vals3.line_id);
      setOptions(el('#aoi'), vals3.aoi);
      setOptions(el('#model'), vals3.model);
      setOptions(el('#glass_type'), vals3.gtype);
      setOptions(el('#ai_code_1'), vals3.code);
      setOptions(el('#pi_hour'), vals3.pi);
      renderCharts(resp.ChartDataDict);
    });

  } catch (err) {
    console.error(err);
    setStatus('發生錯誤：' + err.message);
  }
}

boot();
