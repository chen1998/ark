// table.js (Strict-ID + Built-in Filter UI + Key Normalization)
(function () {
  const ns = (window.AIDI = window.AIDI || {});
  ns.AIDI_DEBUG = ns.AIDI_DEBUG ?? true;

  // ===== 欄位設定 =====
  const AIDITableCols = {
    line_id: "PI Line",
    aoi_id: "AOI",
    model_id: "Model",
    glass_side: "GS",
    defect_code: "defect_code",
    density: "density",
    glass_count: "glass_num",
    bytimehour: "Hour",
  };

  const GlassSubInfoKeys = [
    "scantime","model","glass_id","recipe_id",
    "over_defect_count","large_defect_count","middle_defect_count","small_defect_count",
  ];

  // ===== 狀態 =====
  const state = {
    series: [],              // 原始資料（標準化後）
    allSummary: {},          // all_summary_dict
    filters: {               // 內建 filter 條件
      line_id: new Set(),
      aoi_id: new Set(),
      model_id: new Set(),
      glass_side: new Set(),
      text: "",              // 關鍵字（line/aoi/model/defect_code 上模糊查）
      density: [null, null], // [min,max]
      glass_count: [null, null],
      time_from: null,       // Date 或 null
      time_to: null,
    },
  };

  // ===== 小工具 =====
  const dlog   = (...a)=> ns.AIDI_DEBUG && console.log("[AIDI:table]", ...a);
  const dgroup = (label, fn)=> { if(!ns.AIDI_DEBUG){ fn?.(); return; } console.group(label); try{ fn?.(); } finally{ console.groupEnd(); } };
  const el     = (tag, attrs={}, children=[])=>{
    const e = document.createElement(tag);
    for (const [k,v] of Object.entries(attrs)){
      if (k==="class") e.className=v;
      else if (k==="style") e.style.cssText=v;
      else e.setAttribute(k,v);
    }
    (Array.isArray(children)?children:[children]).forEach(c=>{
      if (c==null) return;
      e.appendChild(typeof c==="string"?document.createTextNode(c):c);
    });
    return e;
  };
  const getTable = ()=> document.getElementById("aidi-table") || (dlog("找不到 #aidi-table"), null);
  const safe = (v)=> v==null ? "" : String(v);

  // ===== 資料標準化（鍵名容錯） =====
  function normalizeSeries(arr){
    if (!Array.isArray(arr)) return [];
    return arr.map(r=>{
      const o = {...r};

      // 常見別名 → 正式鍵
      o.line_id     = o.line_id     ?? o.line ?? o.lineID ?? o.LineID ?? "";
      o.aoi_id      = o.aoi_id      ?? o.aoi  ?? o.aoiID  ?? o.AOI    ?? "";
      o.model_id    = o.model_id    ?? o.model ?? o.Model ?? "";
      o.glass_side  = o.glass_side  ?? o.gs ?? o.side ?? "";
      o.defect_code = o.defect_code ?? o.defect ?? o.defectCode ?? "";
      o.density     = numOrNull(o.density);
      o.glass_count = toInt(o.glass_count ?? o.glass_num);
      o.bytimehour  = o.bytimehour ?? o.by_time_hour ?? o.byTimeHour ?? o.Hour ?? "";

      return o;
    });
  }
  function numOrNull(v){ const n = Number(v); return Number.isFinite(n) ? n : null; }
  function toInt(v){ const n = parseInt(v,10); return Number.isFinite(n)? n : null; }

  // ===== 建表頭（只做一次） =====
  function ensureHeaderOnce(){
    const table = getTable(); if (!table) return;
    let thead = table.querySelector("thead");
    if (!thead){ thead = el("thead"); table.appendChild(thead); }

    if (thead.dataset.built === "1") return;
    const tr = el("tr");
    Object.values(AIDITableCols).forEach(text => tr.appendChild(el("th", {}, text)));
    tr.appendChild(el("th", {}, "操作"));
    thead.innerHTML = ""; thead.appendChild(tr);
    thead.dataset.built = "1";
    dlog("[HEADER] 已建立表頭 (values):", Object.values(AIDITableCols));
  }

  // ===== 篩選邏輯 =====
  function getFiltered(){
    const f = state.filters;
    const text = (f.text||"").trim().toLowerCase();
    const hasText = !!text;
    const hasFrom = f.time_from instanceof Date;
    const hasTo   = f.time_to   instanceof Date;

    const [denMin, denMax]   = f.density;
    const [cntMin, cntMax]   = f.glass_count;

    return (state.series||[]).filter(r=>{
      if (f.line_id.size && !f.line_id.has(String(r.line_id))) return false;
      if (f.aoi_id.size  && !f.aoi_id.has(String(r.aoi_id)))   return false;
      if (f.model_id.size&& !f.model_id.has(String(r.model_id))) return false;
      if (f.glass_side.size && !f.glass_side.has(String(r.glass_side))) return false;

      if (hasText){
        const hay = [r.line_id,r.aoi_id,r.model_id,r.defect_code].map(x=>String(x||"").toLowerCase()).join(" ");
        if (!hay.includes(text)) return false;
      }

      if (denMin!=null || denMax!=null){
        const v = Number(r.density);
        if (denMin!=null && !(v>=denMin)) return false;
        if (denMax!=null && !(v<=denMax)) return false;
      }
      if (cntMin!=null || cntMax!=null){
        const v = Number(r.glass_count);
        if (cntMin!=null && !(v>=cntMin)) return false;
        if (cntMax!=null && !(v<=cntMax)) return false;
      }

      if (hasFrom || hasTo){
        const t = parseMaybeDate(r.bytimehour);
        if (hasFrom && t && t < f.time_from) return false;
        if (hasTo   && t && t > f.time_to)   return false;
      }
      return true;
    });
  }
  function parseMaybeDate(v){
    // 接受 'YYYY-MM-DD hh:mm' 或 ISO
    const s = String(v||"").replace(" ", "T");
    const d = new Date(s);
    return isNaN(+d) ? null : d;
  }

  // ===== Filter UI =====
  function attachFilterUI(){
    const wrap = document.querySelector("#aidi-table-wrap .table-head") || document.querySelector("#aidi-table-wrap");
    if (!wrap) return;

    let bar = wrap.querySelector(".aidi-filter-bar");
    if (!bar){
      bar = el("div", {class:"aidi-filter-bar", style:"margin-top:6px; display:flex; flex-wrap:wrap; gap:8px; align-items:center;"});
      wrap.appendChild(bar);
    } else {
      bar.innerHTML = ""; // 重建
    }

    // 取唯一值
    const uniq = (key)=> [...new Set((state.series||[]).map(r=>String(r[key]??"")).filter(Boolean))].sort();

    const lineSel  = makeMultiSel("Line", uniq("line_id"), state.filters.line_id);
    const aoiSel   = makeMultiSel("AOI",  uniq("aoi_id"),  state.filters.aoi_id);
    const modelSel = makeMultiSel("Model",uniq("model_id"),state.filters.model_id);
    const sideSel  = makeMultiSel("GS",   uniq("glass_side"), state.filters.glass_side);

    const textBox = el("input", {type:"search", placeholder:"關鍵字(line/aoi/model/defect)", style:"min-width:200px; padding:4px 6px; border:1px solid #2b3240; background:#151922; color:#e6e9ef; border-radius:6px;"});
    textBox.value = state.filters.text || "";
    textBox.addEventListener("input", debounce(()=>{ state.filters.text = textBox.value; ns.renderTable(); }, 200));

    const denMin = el("input",{type:"number", placeholder:"density ≥", style:boxStyle()});
    const denMax = el("input",{type:"number", placeholder:"density ≤", style:boxStyle()});
    if (state.filters.density[0]!=null) denMin.value = state.filters.density[0];
    if (state.filters.density[1]!=null) denMax.value = state.filters.density[1];
    const onDen = ()=>{ state.filters.density = [valOrNull(denMin.value), valOrNull(denMax.value)]; ns.renderTable(); };
    denMin.addEventListener("change", onDen); denMax.addEventListener("change", onDen);

    const cntMin = el("input",{type:"number", placeholder:"glass_num ≥", style:boxStyle()});
    const cntMax = el("input",{type:"number", placeholder:"glass_num ≤", style:boxStyle()});
    if (state.filters.glass_count[0]!=null) cntMin.value = state.filters.glass_count[0];
    if (state.filters.glass_count[1]!=null) cntMax.value = state.filters.glass_count[1];
    const onCnt = ()=>{ state.filters.glass_count = [valOrNull(cntMin.value), valOrNull(cntMax.value)]; ns.renderTable(); };
    cntMin.addEventListener("change", onCnt); cntMax.addEventListener("change", onCnt);

    const tFrom = el("input",{type:"datetime-local", style:boxStyle()});
    const tTo   = el("input",{type:"datetime-local", style:boxStyle()});
    if (state.filters.time_from) tFrom.value = toLocalInputValue(state.filters.time_from);
    if (state.filters.time_to)   tTo.value   = toLocalInputValue(state.filters.time_to);
    const onTime = ()=>{
      state.filters.time_from = tFrom.value ? new Date(tFrom.value) : null;
      state.filters.time_to   = tTo.value   ? new Date(tTo.value)   : null;
      ns.renderTable();
    };
    tFrom.addEventListener("change", onTime);
    tTo.addEventListener("change", onTime);

    const clearBtn = el("button", {class:"btn btn-xs"}, "清除篩選");
    clearBtn.addEventListener("click", ()=>{
      state.filters = {
        line_id:new Set(), aoi_id:new Set(), model_id:new Set(), glass_side:new Set(),
        text:"", density:[null,null], glass_count:[null,null], time_from:null, time_to:null
      };
      attachFilterUI(); // 重新畫 UI
      ns.renderTable();
    });

    bar.append(
      lineSel.wrap, aoiSel.wrap, modelSel.wrap, sideSel.wrap,
      textBox, denMin, denMax, cntMin, cntMax, tFrom, tTo, clearBtn
    );
  }

  function makeMultiSel(label, options, setRef){
    const wrap = el("label", {style:"display:flex; align-items:center; gap:6px;"}, [
      el("span", {style:"opacity:.9; font-size:12.5px;"}, label),
      (()=>{
        const sel = el("select", {multiple:"multiple", size:String(Math.min(6, Math.max(2, options.length))) , style:"min-width:120px; background:#151922; border:1px solid #2b3240; border-radius:6px; color:#e6e9ef; padding:4px;"});
        options.forEach(v=>{
          const opt = el("option", {}, v);
          opt.selected = setRef.has(v);
          sel.appendChild(opt);
        });
        sel.addEventListener("change", ()=>{
          const chosen = [...sel.selectedOptions].map(o=>o.value);
          setRef.clear();
          chosen.forEach(v=> setRef.add(v));
          ns.renderTable();
        });
        return sel;
      })()
    ]);
    return {wrap};
  }
  const boxStyle = ()=>"min-width:120px; padding:4px 6px; border:1px solid #2b3240; background:#151922; color:#e6e9ef; border-radius:6px;";
  const valOrNull = (v)=> (v==="" || v==null) ? null : Number(v);
  const toLocalInputValue = (d)=> new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);
  const debounce = (fn,ms)=>{ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; };

  // ===== Rowspan 計算 =====
  function computeRowspans(rows, keys){
    const out = {};
    keys.forEach(key=>{
      out[key] = rows.map(()=>({render:false,rowspan:1}));
      let i=0;
      while(i<rows.length){
        const val = rows[i]?.[key];
        let j=i+1; while(j<rows.length && rows[j]?.[key]===val) j++;
        out[key][i] = {render:true,rowspan:j-i};
        for(let k=i+1;k<j;k++) out[key][k] = {render:false,rowspan:0};
        i=j;
      }
    });
    return out;
  }

  // ===== 渲染 =====
  ns.renderTable = function(){
    const table = getTable(); if (!table) return;
    ensureHeaderOnce();

    const data = getFiltered();
    dgroup("RenderTable - rows(after filter)", ()=>{
      dlog("rows.count:", data.length);
      if (data.length) console.table(data.slice(0,20));
    });

    let tbody = table.querySelector("tbody");
    if (!tbody){ tbody = el("tbody"); table.appendChild(tbody); }
    tbody.innerHTML = "";

    if (!data.length){
      const hint = el("div", {style:"opacity:.8; font-size:12px; padding:2px 0;"},
        state.series.length ? "（無資料，請調整篩選條件）" : "（無資料）"
      );
      const td = el("td",{colspan:"99"});
      td.appendChild(hint);
      tbody.appendChild(el("tr",{}, td));
      return;
    }

    const colKeys = Object.keys(AIDITableCols);
    const rows = data.slice().sort((a,b)=>
      a.line_id!==b.line_id ? String(a.line_id).localeCompare(String(b.line_id)) :
      a.aoi_id!==b.aoi_id   ? String(a.aoi_id).localeCompare(String(b.aoi_id))   :
      a.model_id!==b.model_id ? String(a.model_id).localeCompare(String(b.model_id)) :
      String(a.bytimehour).localeCompare(String(b.bytimehour))
    );
    const spans = computeRowspans(rows, ["line_id","aoi_id"]);

    rows.forEach((r, idx)=>{
      const tr = el("tr",{class:"main-row","data-row-idx":String(idx)});
      for (const key of colKeys){
        if (key==="line_id" || key==="aoi_id"){
          const s = spans[key][idx];
          if (!s.render) continue;
          const td = el("td",{class:`col-${key} merged`,rowspan:String(s.rowspan)});
          td.textContent = safe(r[key]); tr.appendChild(td);
        }else{
          const td = el("td",{class:`col-${key}`});
          td.textContent = (key==="density" && Number.isFinite(+r.density))
            ? (+r.density).toFixed(3) : safe(r[key]);
          tr.appendChild(td);
        }
      }
      const act = el("td",{class:"col-action"});
      const btn = el("button",{class:"btn btn-xs"},"展開");
      btn.addEventListener("click", ()=> toggleDetail(tr, r));
      act.appendChild(btn); tr.appendChild(act);
      tbody.appendChild(tr);
    });
  };

  function toggleDetail(mainTr, rowData){
    dgroup("Toggle Detail - row payload", ()=>{
      console.table([rowData]);
      dlog("match keys =>", {
        line_id: rowData.line_id,
        aoi_id: rowData.aoi_id,
        model_id: rowData.model_id,
        bytimehour: rowData.bytimehour,
      });
    });

    const isOpen = mainTr.classList.toggle("is-open");
    const btn = mainTr.querySelector(".col-action > .btn");
    if (btn) btn.textContent = isOpen ? "收合" : "展開";

    const next = mainTr.nextElementSibling;
    if (isOpen){
      const detailTr = buildDetailRow(rowData);
      if (next && next.classList.contains("detail-row")) next.replaceWith(detailTr);
      else mainTr.insertAdjacentElement("afterend", detailTr);
    }else{
      if (next && next.classList.contains("detail-row")) next.remove();
    }
  }

  function buildDetailRow(row){
    const { line_id, aoi_id, model_id, bytimehour } = row;
    const aoiDict = state.allSummary?.[line_id]?.[aoi_id] || {};
    const arr = Object.values(aoiDict);
    const filtered = arr.filter(o=>{
      if (String(o.bytimehour||"") !== String(bytimehour||"")) return false;
      if (o.model_id!=null) return String(o.model_id)===String(model_id);
      return true;
    });

    dgroup("Detail match result", ()=>{
      dlog(`allSummary[${line_id}][${aoi_id}] count:`, arr.length);
      dlog("filtered count:", filtered.length);
      filtered.length ? console.table(filtered.slice(0,20)) : dlog("（無符合資料）");
    });

    const tr = el("tr", {class:"detail-row"});
    const td = el("td", {colspan: String(Object.keys(AIDITableCols).length + 1)});
    tr.appendChild(td);

    const box = el("div", {class:"detail-box"});
    box.appendChild(el("div", {class:"detail-title"},
      `明細：${line_id} / ${aoi_id} / ${model_id} / ${bytimehour}`
    ));

    if (!filtered.length){
      box.appendChild(el("div", {class:"detail-empty"}, "（無符合的明細資料）"));
      td.appendChild(box);
      return tr;
    }

    const sub = el("table", {class:"table sub-table"});
    const thead = el("thead");
    const thr = el("tr");
    GlassSubInfoKeys.forEach(k=> thr.appendChild(el("th",{},k)));
    thead.appendChild(thr); sub.appendChild(thead);

    const tbody = el("tbody");
    filtered.forEach(o=>{
      const rr = el("tr");
      GlassSubInfoKeys.forEach(k=> rr.appendChild(el("td",{},safe(o[k]))));
      tbody.appendChild(rr);
    });
    sub.appendChild(tbody);
    box.appendChild(sub);
    td.appendChild(box);
    return tr;
  }

  // ===== Public APIs =====
  ns.initAIDITable = function({ series, all_summary_dict, enable_filter_ui = true }){
    state.series = normalizeSeries(series||[]);
    state.allSummary = all_summary_dict || {};

    dgroup("Init Payload (normalized)", ()=>{
      dlog("series.length:", state.series.length);
      if (state.series.length) console.table(state.series.slice(0,10));
      const lineKeys = Object.keys(state.allSummary||{});
      dlog("all_summary_dict lines:", lineKeys);
      if (lineKeys.length){
        const aoiKeys = Object.keys(state.allSummary[lineKeys[0]]||{});
        dlog(`example aoi under ${lineKeys[0]}:`, aoiKeys);
      }
    });

    ensureHeaderOnce();
    if (enable_filter_ui) attachFilterUI();
  };

  ns.setFilters = function(partial){
    // 支援：{ line_id: ['L1','L2'], text: 'xxx', density:[0,2], time_from:'2025-09-17T08:00', ... }
    if (!partial || typeof partial!=="object") return;

    if (partial.line_id)    { state.filters.line_id = new Set(partial.line_id.map(String)); }
    if (partial.aoi_id)     { state.filters.aoi_id  = new Set(partial.aoi_id.map(String)); }
    if (partial.model_id)   { state.filters.model_id= new Set(partial.model_id.map(String)); }
    if (partial.glass_side) { state.filters.glass_side = new Set(partial.glass_side.map(String)); }
    if (partial.text!=null) { state.filters.text = String(partial.text||""); }
    if (partial.density)    { state.filters.density = [valOrNull(partial.density[0]), valOrNull(partial.density[1])]; }
    if (partial.glass_count){ state.filters.glass_count = [valOrNull(partial.glass_count[0]), valOrNull(partial.glass_count[1])]; }
    if (partial.time_from!=null){ state.filters.time_from = partial.time_from ? new Date(partial.time_from) : null; }
    if (partial.time_to!=null)  { state.filters.time_to   = partial.time_to   ? new Date(partial.time_to)   : null; }

    attachFilterUI(); // 更新下拉的選取狀態
    ns.renderTable();
  };

  ns.clearFilters = function(){ ns.setFilters({ line_id:[], aoi_id:[], model_id:[], glass_side:[], text:"", density:[null,null], glass_count:[null,null], time_from:null, time_to:null }); };

  ns.refreshFilterOptions = attachFilterUI;

  ns.renderTableWith = function(series, all_summary_dict = {}){
    // 直接用外部資料渲染一次（不改變現有 state）
    const prev = { series: state.series, allSummary: state.allSummary };
    try{
      state.series = normalizeSeries(series||[]);
      state.allSummary = all_summary_dict || {};
      ns.renderTable();
    } finally {
      state.series = prev.series;
      state.allSummary = prev.allSummary;
    }
  };

  // 頁面載入時先建表頭
  document.addEventListener("DOMContentLoaded", ensureHeaderOnce);
})();



/*

*/