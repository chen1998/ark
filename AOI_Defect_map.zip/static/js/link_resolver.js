// static/js/link_resolver.js
(function(){
  const DEBUG = true;
  const log = (...a)=>{ if(DEBUG) console.log('[LR]', ...a); };

  const LR = {
    makeKey(row){ return `${row.measure_time}|${row.sheet_id}|${row.recipe_id}`; },
    _keyToRow:new Map(), _keyToVirt:new Map(), _sheetToKeys:new Map(), _inited:false,

    init(mock){
      log('init start');
      if(!mock || !Array.isArray(mock.run_sheet_list)){ log('no rows'); return; }
      this._keyToRow.clear(); this._keyToVirt.clear(); this._sheetToKeys.clear();

      const rows = mock.run_sheet_list.slice();
      const asDate = s=> new Date(String(s).replace(' ','T'));

      const bySheet = new Map();
      for(const r of rows){
        const arr = bySheet.get(r.sheet_id) || [];
        arr.push(r); bySheet.set(r.sheet_id, arr);
      }

      for(const [sheet, arr] of bySheet.entries()){
        arr.sort((a,b)=> asDate(a.measure_time) - asDate(b.measure_time)); // 早→晚
        const keys=[];
        arr.forEach((row, idx)=>{
          const key = this.makeKey(row);
          this._keyToRow.set(key,row);
          this._keyToVirt.set(key, (idx%2===0?'A':'B'));
          keys.push(key);
        });
        this._sheetToKeys.set(sheet, keys);
      }
      this._inited = true;
      log('inited', {keys: this._keyToRow.size});
    },

    ensureReady(){ if(!this._inited && window.MockData) this.init(MockData); return this._inited; },

    rowForKey(key){ this.ensureReady(); return this._keyToRow.get(key)||null; },

    virtForKey(key){
      this.ensureReady();
      let g = this._keyToVirt.get(key);
      if(g) return g;
      const row = this.rowForKey(key);
      if(!row) return null;
      const list = this._sheetToKeys.get(row.sheet_id) || [];
      const idx = list.indexOf(key);
      g = (idx>=0 && idx%2===0) ? 'A' : 'B';
      if(!g) g = 'A';
      this._keyToVirt.set(key, g);
      return g;
    },

    // --- 核心：若 A/B 缺失，現場拆分回補，避免回傳 0 ---
    defectsForKey(key){
      this.ensureReady();
      const row = this.rowForKey(key);
      const g = this.virtForKey(key);
      if(!row || !g) return [];

      const dict = (window.MockData && MockData.sheet_defect_dict) || {};
      let groups = dict[row.sheet_id];

      if(!groups || (!Array.isArray(groups.A) && !Array.isArray(groups.B))){
        // 補：若沒有 A/B，就用一組 base 拆兩半
        const base = [];
        const N = 260 + Math.floor(Math.random()*120);
        for(let i=0;i<N;i++){
          base.push({
            x: Math.random()*MockData.MAP_W,
            y: Math.random()*MockData.MAP_H,
            type: ["Dot","Particle","Line","Butterfly"][Math.floor(Math.random()*4)],
            size: ["S","M","L","O"][Math.floor(Math.random()*4)],
            value: +(Math.random()*1.0).toFixed(2)
          });
        }
        const A = base.filter((_,i)=> i%2===0);
        const B = base.filter((_,i)=> i%2===1);
        MockData.sheet_defect_dict[row.sheet_id] = groups = { A, B };
        log('hot patched A/B for sheet', row.sheet_id, {A:A.length, B:B.length});
      }

      const arr = (groups[g] || []);
      log('defectsForKey', {key, sheet: row.sheet_id, g, count: arr.length});
      return arr;
    },

    imageForKey(key){
      this.ensureReady();
      const row = this.rowForKey(key);
      const g = this.virtForKey(key);
      if(!row || !g) return null;
      const imgs = (window.MockData && MockData.images) || {};
      return imgs[`${row.sheet_id}|${g}`] || null;
    }
  };

  window.LR = LR;
  Bus.on('init-data', ({mock})=> LR.init(mock));
})();