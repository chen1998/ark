// static/js/aidi_view.js  (Drop-in replacement)
// - 新增 MultiDD 多選下拉元件（checkbox + 搜尋 + 全選/全不選 + 套用）
// - 建立隱藏 <select multiple> 與 UI 雙向同步
// - #aidiApply / #aidiClear / 點圖 quickFilter 都會觸發重繪 charts + table

(function () {
    const qs  = (s,r)=> (r||document).querySelector(s);
    const qsa = (s,r)=> Array.from((r||document).querySelectorAll(s));
    const el  = (t,a)=>{const e=document.createElement(t); if(a){for(const k in a) e.setAttribute(k,a[k]);} return e;};
  
    // --- 動態載入 d3 ---
    function ensureD3(){
      return new Promise(res=>{
        if(window.d3){ res(); return; }
        const sc = document.createElement('script');
        sc.src = 'https://cdn.jsdelivr.net/npm/d3@7';
        sc.onload = ()=> res();
        document.head.appendChild(sc);
      });
    }
  
    // 解析 YYYY-MM-DD HH:00 (或 ISO "YYYY-MM-DDTHH:mm")
    function parseHour(s){
      const d = new Date(String(s).replace('T',' ').replace(/(\d{2}):\d{2}$/,'$1:00'));
      return isNaN(+d) ? null : d;
    }
    const dateStr = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  
    // ---------------- MultiDD：多選下拉（渲染到 #<id>-dd，並建立隱藏 <select multiple id="<id>">） ----------------
    class MultiDD {
      constructor(hostId, selectId, options = []) {
        this.hostId = hostId;       // 容器（你 HTML 的 multi-dd-host）
        this.selectId = selectId;   // 隱藏 select 的 id（AIDI.getSel 會讀它）
        this.options = options.slice().sort(); // 顯示用
        this.selected = new Set();   // 目前選取
        this.nodes = {};             // 快速存取 DOM
        this.render();
      }
      render() {
        const host = qs('#' + this.hostId);
        if (!host) return;
  
        // 建立/或取得隱藏 select
        let select = qs('#'+this.selectId);
        if (!select) {
          select = el('select', { id: this.selectId, multiple: 'multiple', style: 'display:none' });
          host.parentElement.insertBefore(select, host.nextSibling);
        }
        // 填入 <option>
        select.innerHTML = '';
        this.options.forEach(v => {
          const o = el('option'); o.value = v; o.textContent = v; select.appendChild(o);
        });
  
        // UI：多選元件
        host.innerHTML = '';
        const wrap = el('div', { class: 'multi-dd' });
        const btn  = el('button', { class: 'multi-dd-btn', type: 'button' });
        btn.textContent = '全部（0）';
        const list = el('div', { class: 'multi-dd-list', style: 'display:none' });
  
        // 搜尋
        const search = el('input', { type:'text', placeholder:'搜尋...', style:'width:100%;margin-bottom:6px' });
        list.appendChild(search);
  
        // 清單
        const cont = el('div');
        list.appendChild(cont);
  
        // Footer：全選/全不選/套用
        const footer = el('div', { class: 'multi-dd-footer' });
        const bAll   = el('button', { class:'btn btn-xs', type:'button' }); bAll.textContent='全選';
        const bNone  = el('button', { class:'btn btn-xs btn-secondary', type:'button' }); bNone.textContent='全不選';
        const bApply = el('button', { class:'btn btn-xs', type:'button' }); bApply.textContent='套用';
        footer.append(bAll, bNone, bApply);
        list.appendChild(footer);
  
        wrap.append(btn, list);
        host.appendChild(wrap);
  
        // 綁定
        btn.addEventListener('click', () => {
          const open = list.style.display !== 'none';
          qsa('.multi-dd .multi-dd-list').forEach(x => x.style.display = 'none');
          qsa('.multi-dd').forEach(x => x.classList.remove('open'));
          if (!open) {
            list.style.display = '';
            wrap.classList.add('open');
            search.focus();
          }
        });
        document.addEventListener('click', (ev) => {
          if (!wrap.contains(ev.target)) {
            list.style.display = 'none';
            wrap.classList.remove('open');
          }
        });
  
        const rebuildList = () => {
          const kw = search.value.trim().toLowerCase();
          cont.innerHTML = '';
          this.options
            .filter(v => !kw || String(v).toLowerCase().includes(kw))
            .forEach(v => {
              const row = el('label', { class:'multi-dd-item' });
              const ck  = el('input', { type:'checkbox', value:v });
              ck.checked = this.selected.has(v);
              ck.addEventListener('change', () => {
                if (ck.checked) this.selected.add(v); else this.selected.delete(v);
                this.syncSelect(select);
                this.updateBtnText(btn);
              });
              const txt = el('span'); txt.textContent = v;
              row.append(ck, txt);
              cont.appendChild(row);
            });
        };
  
        bAll.addEventListener('click', () => {
          this.options.forEach(v => this.selected.add(v));
          this.syncSelect(select);
          this.updateBtnText(btn);
          rebuildList();
        });
        bNone.addEventListener('click', () => {
          this.selected.clear();
          this.syncSelect(select);
          this.updateBtnText(btn);
          rebuildList();
        });
        bApply.addEventListener('click', () => {
          list.style.display = 'none';
          wrap.classList.remove('open');
          // 讓外層可在套用時觸發重繪（AIDI.ensureInit 已綁 aidiApply 按鈕；若想單獨這裡就觸發，可 emit 事件）
        });
  
        search.addEventListener('input', rebuildList);
  
        // 初始化清單 & 按鈕文案
        this.updateBtnText(btn);
        rebuildList();
  
        // 暴露節點
        this.nodes = { host, wrap, btn, list, search, cont, select };
      }
      updateBtnText(btn) {
        const n = this.selected.size;
        btn.textContent = n === 0 ? '全部（0）' : `已選 ${n} 項`;
      }
      syncSelect(select) {
        // 把 selected set 寫回隱藏 select 的 selected 狀態
        Array.from(select.options).forEach(o => {
          o.selected = this.selected.has(o.value);
        });
      }
      clear() {
        this.selected.clear();
        if (this.nodes.select) {
          Array.from(this.nodes.select.options).forEach(o => o.selected = false);
        }
        if (this.nodes.btn) this.updateBtnText(this.nodes.btn);
        if (this.nodes.search) this.nodes.search.value = '';
        if (this.nodes.cont) {
          // 重新產生清單
          this.options && this.options.length && this.options.forEach(()=>{});
        }
      }
      setSelected(vals = []) {
        this.selected = new Set(vals);
        if (this.nodes.select) this.syncSelect(this.nodes.select);
        if (this.nodes.btn) this.updateBtnText(this.nodes.btn);
      }
      getSelected() { return Array.from(this.selected); }
    }
  
    // ---------------- AIDI 主模組 ----------------
    const AIDI = {
      inited:false,
      tabsCacheHTML:null,
      currentTab:'UPI Hourly',
      full:{ series:[], filters:{ line_ids:[], aoi_ids:[], models:[], glass_sides:[], defect_codes:[] }, time_bins:[] },
      // MultiDD 實例
      mdd: {
        line:  null,
        aoi:   null,
        model: null,
        code:  null
      },
  
      async fetchData(params={}){
        const usp = new URLSearchParams({ days:'7', reload:'false', ...params });
        const r = await fetch(`${window.API_BASE}/api/aidi/hourly?${usp.toString()}`);
        if(!r.ok){ throw new Error('API /api/aidi/hourly 失敗'); }
        return r.json();
      },
  
      // 建置多選元件（並建立隱藏 select）
      buildFilterWidgets(){
        const F = this.full.filters || {};
        // 1) Line
        this.mdd.line  = new MultiDD('aidiLine-dd',  'aidiLine',  F.line_ids || []);
        // 2) AOI
        this.mdd.aoi   = new MultiDD('aidiAOI-dd',   'aidiAOI',   F.aoi_ids || []);
        // 3) Model
        this.mdd.model = new MultiDD('aidiModel-dd', 'aidiModel', F.models || []);
        // 4) Defect Code
        this.mdd.code  = new MultiDD('aidiCode-dd',  'aidiCode',  F.defect_codes || []);
      },
  
      // 日期預設
      fillDateFromBins(){
        const bins = (this.full.time_bins||[])
          .map(parseHour).filter(Boolean).sort((a,b)=>a-b);
        if(bins.length){
          qs('#aidiStart').value = dateStr(bins[0]);
          qs('#aidiEnd').value   = dateStr(bins[bins.length-1]);
        }
      },
  
      getSel(id){
        const elx = qs('#'+id);
        return elx ? [...elx.options].filter(o=>o.selected).map(o=>o.value) : [];
      },
  
      // 依右側 filter 篩資料
      getFiltered(){
        const S = this.full.series || [];
        const L = this.getSel('aidiLine');
        const A = this.getSel('aidiAOI');
        const M = this.getSel('aidiModel');
        const C = this.getSel('aidiCode');
        const d1 = new Date(qs('#aidiStart').value||''); d1.setHours(0,0,0,0);
        const d2 = new Date(qs('#aidiEnd').value||'');   d2.setHours(23,59,59,999);
  
        return S.filter(r=>{
          if(L.length && !L.includes(r.line_id)) return false;
          if(A.length && !A.includes(r.aoi_id)) return false;
          if(M.length && !M.includes(r.model_id)) return false;
          if(C.length && !C.includes(r.defect_code)) return false;
          const hh = parseHour(r.time);
          if(d1.toString() !== 'Invalid Date' && hh && hh < d1) return false;
          if(d2.toString() !== 'Invalid Date' && hh && hh > d2) return false;
          return true;
        });
      },
  
      // 產出矩陣資料
      buildMatrix(data){
        const aois  = Array.from(new Set(data.map(d=>d.aoi_id))).sort();
        const lines = Array.from(new Set(data.map(d=>d.line_id))).sort();
        const lineRows = lines.map(line=>{
          const models = Array.from(new Set(data.filter(d=>d.line_id===line).map(d=>d.model_id))).sort();
          return { line, models };
        });
  
        const allT = Array.from(new Set(data.map(d=>d.time))).map(parseHour).filter(Boolean).sort((a,b)=>a-b);
        const tMin = allT[0] || new Date();
        const tMax = allT[allT.length-1] || new Date();
  
        const maxGC = d3.max(data, d=>+d.glass_count||0) || 1;
        const maxDN = d3.max(data, d=>+d.density||0) || 1;
  
        const key = (r)=> `${r.line_id}__${r.model_id}__${r.aoi_id}`;
        const map = new Map();
        data.forEach(r=>{
          const k = key(r);
          if(!map.has(k)) map.set(k, { line:r.line_id, model:r.model_id, aoi:r.aoi_id, values:[] });
          map.get(k).values.push({
            t: parseHour(r.time),
            gc: +r.glass_count||0,
            dn: +r.density||0,
            dt: +r.defect_total||0
          });
        });
        // 保證每格存在
        lineRows.forEach(L=>{
          L.models.forEach(m=>{
            aois.forEach(a=>{
              const k = `${L.line}__${m}__${a}`;
              if(!map.has(k)) map.set(k, { line:L.line, model:m, aoi:a, values:[] });
            });
          });
        });
  
        return { aois, lineRows, panels:[...map.values()], tMin, tMax, maxGC, maxDN };
      },
  
      // 矩陣小圖（d3）
      renderCharts(){
        const host = qs('#aidi-charts'); if(!host) return;
        host.innerHTML = '';
  
        const data = this.getFiltered();
        if(!data.length){ host.textContent = '（無資料）'; return; }
  
        const M = this.buildMatrix(data);
  
        const leftW = 160, colW = 260, panelH = 160;
        const gridCols = [leftW, ...M.aois.map(()=>colW)];
        const matrix = el('div',{class:'aidi-matrix'});
        matrix.style.gridTemplateColumns = gridCols.map(w=>`${w}px`).join(' ');
        host.appendChild(matrix);
  
        // header
        const header = el('div',{class:'header'});
        header.style.gridColumn = `1 / span ${1 + M.aois.length}`;
        header.style.display    = 'grid';
        header.style.gridTemplateColumns = gridCols.map(w=>`${w}px`).join(' ');
        header.appendChild(el('div',{class:'cell'})); // 左上角空白
        M.aois.forEach(a=>{
          const c = el('div',{class:'cell'}); c.textContent = a; header.appendChild(c);
        });
        matrix.appendChild(header);
  
        // 比例尺
        const x  = d3.scaleTime().domain([M.tMin, M.tMax]).range([8, colW-8]);
        const yL = d3.scaleLinear().domain([0, M.maxGC*1.1]).range([panelH-22, 12]);
        const yR = d3.scaleLinear().domain([0, M.maxDN*1.1]).range([panelH-22, 12]);
        const barW = Math.max(4, Math.min(18, (colW-20) / Math.max(6, (M.tMax-M.tMin)/(3600e3)) * 0.6));
  
        const Pkey = (line,model,aoi)=> `${line}__${model}__${aoi}`;
        const Pmap = new Map(M.panels.map(p=>[Pkey(p.line,p.model,p.aoi), p]));
  
        M.lineRows.forEach(L=>{
          L.models.forEach(model=>{
            const lab = el('div',{class:'row-label'});
            lab.textContent = `${L.line}  ${model}`;
            lab.title = '點擊快速篩選此 Line + Model';
            lab.addEventListener('click', ()=>{
              this.setFilterSelections({ line:[L.line], model:[model] });
              this.renderCharts(); this.renderTable();
            });
            matrix.appendChild(lab);
  
            M.aois.forEach(aoi=>{
              const holder = el('div',{class:'panel'});
              matrix.appendChild(holder);
  
              const svg = d3.select(holder).append('svg')
                .attr('width', colW-12).attr('height', panelH)
                .style('display','block');
              const g = svg.append('g').attr('transform','translate(0,0)');
  
              const p = Pmap.get(Pkey(L.line, model, aoi)) || {values:[]};
  
              // 柱（片數）
              g.selectAll('.bar').data(p.values).enter().append('rect')
                .attr('class','bar')
                .attr('x', d=> x(d.t)-barW/2)
                .attr('y', d=> yL(d.gc))
                .attr('width', barW)
                .attr('height', d=> Math.max(0, (panelH-22) - yL(d.gc)))
                .on('click', (ev,d)=>{ this.quickFilter({ line:L.line, model, aoi, time:d.t }); });
  
              // 點（密度）
              g.selectAll('.dot').data(p.values).enter().append('circle')
                .attr('class','dot')
                .attr('r', 3)
                .attr('cx', d=> x(d.t))
                .attr('cy', d=> yR(d.dn))
                .on('click', (ev,d)=>{ this.quickFilter({ line:L.line, model, aoi, time:d.t }); });
  
              // Label（密度）
              g.selectAll('.dot-label').data(p.values).enter().append('text')
                .attr('class','dot-label')
                .attr('x', d=> x(d.t))
                .attr('y', d=> yR(d.dn)-6)
                .attr('text-anchor','middle')
                .text(d=> d.dn>0 ? d.dn.toFixed(2) : '');
  
              // x 刻度
              const ticks = x.ticks(5);
              g.selectAll('.xtick').data(ticks).enter().append('text')
                .attr('class','xtick')
                .attr('x', t=> x(t))
                .attr('y', panelH-4)
                .attr('transform', t=> `rotate(-90, ${x(t)}, ${panelH-4}) translate(-2,-4)`)
                .attr('text-anchor','end')
                .text(t=> d3.timeFormat('%m-%d %H')(t))
                .style('cursor','pointer')
                .on('click', (ev,t)=>{ this.quickFilter({ time:t }); });
            });
          });
        });
      },
  
      // 右下表格
      renderTable(){
        const host = qs('#aidi-table'); if(!host) return;
        const data = this.getFiltered();
        if(!data.length){ host.innerHTML = '<div class="table-placeholder">（無資料）</div>'; return; }
  
        const tbl = el('table',{class:'table'});
        tbl.innerHTML = `
          <thead><tr>
            <th>Time</th><th>Line</th><th>AOI</th><th>Model</th>
            <th>Glass</th><th>Defect</th><th>Density</th>
          </tr></thead><tbody></tbody>`;
        const tb = tbl.querySelector('tbody');
  
        data.sort((a,b)=> (a.time<b.time?-1:a.time>b.time?1:0));
        data.slice(0,500).forEach(r=>{
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${r.time}</td>
            <td>${r.line_id}</td>
            <td>${r.aoi_id}</td>
            <td>${r.model_id}</td>
            <td>${r.glass_count}</td>
            <td>${r.defect_total}</td>
            <td>${(+r.density||0).toFixed(2)}</td>`;
          tb.appendChild(tr);
        });
        host.innerHTML = ''; host.appendChild(tbl);
      },
  
      renderTopTabs(){
        const host = qs('#all-tab-container'); if(!host) return;
        const tabs = ['UPI Hourly','SPOT Hourly','UPI Hourly BY Line','SPOT Hourly BY Line','SPEC','異常說明'];
        const row = el('div',{class:'tabs-row'});
        tabs.forEach((name, idx)=>{
          const b = el('button',{class:'tab-btn'}); b.textContent = name;
          if ((this.currentTab==null && idx===0) || this.currentTab===name) { b.classList.add('active'); this.currentTab = name; }
          b.addEventListener('click',()=>{
            qsa('.tabs-row .tab-btn', row).forEach(x=>x.classList.remove('active'));
            b.classList.add('active'); this.currentTab = name;
            this.renderCharts(); this.renderTable();
          });
          row.appendChild(b);
        });
        if (this.tabsCacheHTML==null) this.tabsCacheHTML = host.innerHTML;
        host.innerHTML = ''; host.appendChild(row);
      },
  
      // 快速把選擇寫入四個 MultiDD（與隱藏 select 同步）
      setFilterSelections({ line, aoi, model, code }){
        if (line && this.mdd.line)   this.mdd.line.setSelected(line);
        if (aoi && this.mdd.aoi)     this.mdd.aoi.setSelected(aoi);
        if (model && this.mdd.model) this.mdd.model.setSelected(model);
        if (code && this.mdd.code)   this.mdd.code.setSelected(code);
      },
  
      // 由圖上點擊快速套 filter（line / model / aoi / hour 可任意提供）
      quickFilter({line, model, aoi, time}){
        this.setFilterSelections({
          line:  line  ? [line]  : undefined,
          aoi:   aoi   ? [aoi]   : undefined,
          model: model ? [model] : undefined
        });
        if(time){
          const d = new Date(time); d.setMinutes(0,0,0);
          const ds = dateStr(d);
          qs('#aidiStart').value = ds;
          qs('#aidiEnd').value   = ds;
        }
        this.renderCharts(); this.renderTable();
      },
  
      async ensureInit(){
        if(this.inited) return;
        await ensureD3();
  
        // 顯示 AIDI 區域、跨滿 main-area
        const root = qs('#aidi-root'); if(root){ root.style.display=''; root.style.gridColumn='1 / -1'; }
  
        // 打 API 取資料
        const payload = await this.fetchData();
        this.full = payload || { series:[], filters:{}, time_bins:[] };
  
        // 建置多選元件 + 日期預設
        this.buildFilterWidgets();
        this.fillDateFromBins();
  
        // 上方頁籤
        this.renderTopTabs();
  
        // 綁右側按鈕
        qs('#aidiApply')?.addEventListener('click', ()=>{
          this.renderCharts(); this.renderTable();
        });
        qs('#aidiClear')?.addEventListener('click', ()=>{
          // 清空四個多選
          Object.values(this.mdd).forEach(inst => inst && inst.clear());
          // 還原日期區間
          this.fillDateFromBins();
          this.renderCharts(); this.renderTable();
        });
  
        this.inited = true;
        this.renderCharts(); this.renderTable();
      },
  
      show(){
        this.ensureInit();
        // 隱藏 defect-map 區域
        ['#defect-map-section', '#run-info-block', '#defect-lists', '#defect-gallery'].forEach(id=>{
          const x = qs(id); if (x) x.style.display='none';
        });
        qs('#aidi-root')?.style && (qs('#aidi-root').style.display='');
      },
  
      hide(){
        // 還原 tabs
        const holder = qs('#all-tab-container');
        if (holder && this.tabsCacheHTML!=null) holder.innerHTML = this.tabsCacheHTML;
        // 顯示 defect-map
        ['#defect-map-section', '#run-info-block', '#defect-lists', '#defect-gallery'].forEach(id=>{
          const x = qs(id); if (x) x.style.display='';
        });
        qs('#aidi-root')?.style && (qs('#aidi-root').style.display='none');
      }
    };
  
    // 綁定左上系統分頁（切到 AIDI 才載入＆繪圖）
    function bindSystemTabs(){
      qsa('.sys-tab').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          qsa('.sys-tab').forEach(b=>b.classList.remove('active'));
          btn.classList.add('active');
          const view = btn.getAttribute('data-view');
          if (view==='aidi') AIDI.show(); else AIDI.hide();
        });
      });
    }
  
    document.addEventListener('DOMContentLoaded', ()=>{
      bindSystemTabs();
    });
  
    window.AIDI = AIDI;
  })();