// defect_list.js — 多筆 Defect Tables（兩欄並排）+ 縮圖 + 分組畫廊
(function(){
  const contId = 'defect-lists-container';
  const countId = 'dl-count';
  const galleryId = 'gallery-grid';

  function buildTableForKey(key, defects, imgBase){
    const { scantime, glass_id, recipe_id } = Utils.parseKey(key);
    const wrap = document.createElement('div');
    wrap.className = 'defect-table-wrap';

    const title = document.createElement('div');
    title.className = 'defect-table-title';
    title.textContent = `${scantime} ｜ ${glass_id} ｜ ${recipe_id}`;
    wrap.appendChild(title);

    const tbl = document.createElement('table');
    tbl.className = 'table defect-table';
    const thead = document.createElement('thead');
    const trh = document.createElement("tr");
    ['#','x','y','size','type','chip','image'].forEach(h=>{
      const th = document.createElement('th');
      th.textContent = h;
      if(h==='#') th.classList.add('index-col');
      trh.appendChild(th);
    });
    thead.appendChild(trh);
    tbl.appendChild(thead);

    const tbody = document.createElement('tbody');
    (defects||[]).slice().sort(Utils.byOriginAsc).forEach((d, idx)=>{
      const x = d.x ?? '';
      const y = d.y ?? '';
      const sz = d.size || d.defect_size || '';
      const tp = d.type || d.predict_code || '';
      const chip = d.chip || d.chip_name || '';
      const file = Utils.addJpgIfMissing(d.file || d.pic_name || '');
      const src  = (imgBase||'') + (file||'');

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="index-col">${idx+1}</td>
        <td>${x}</td>
        <td>${y}</td>
        <td>${sz}</td>
        <td>${tp}</td>
        <td>${chip}</td>
        <td class="img-cell">${file?`<img loading="lazy" src="${src}" alt="">`:''}</td>
      `;
      tbody.appendChild(tr);
    });
    tbl.appendChild(tbody);
    wrap.appendChild(tbl);

    // 同步建立畫廊群組
    addGroupToGallery(key, defects, imgBase);

    return wrap;
  }

  function addGroupToGallery(key, defects, imgBase){
    const { scantime, glass_id, recipe_id } = Utils.parseKey(key);
    const grid = document.getElementById(galleryId);
    if(!defects) defects = [];
    const group = document.createElement('div');
    group.className = 'gallery-group';
    const title = document.createElement('div');
    title.className = 'gallery-title';
    title.textContent = `${scantime} ｜ ${glass_id} ｜ ${recipe_id}`;
    group.appendChild(title);

    defects.slice().sort(Utils.byOriginAsc).forEach((d, idx)=>{
      const file = Utils.addJpgIfMissing(d.file || d.pic_name || '');
      const src = (imgBase||'') + (file||'');
      const fig = document.createElement('div');
      fig.className='gallery-item';
      fig.innerHTML = `<span class="idx">#${idx+1}</span>${src?`<img src="${src}" alt="">`:''}`;
      group.appendChild(fig);
    });
    grid.appendChild(group);
  }

  function renderAll(){
    const cont = document.getElementById(contId);
    if(!cont) return;
    cont.innerHTML = '';
    // 清畫廊
    const grid = document.getElementById(galleryId);
    if(grid) grid.innerHTML = '';

    const keys = State.selectedKeys.slice();
    keys.forEach(k=>{
      const defects = State.DefectCache[k] || [];
      const imgBase = State.imgBaseByKey[k] || '';
      cont.appendChild(buildTableForKey(k, defects, imgBase));
    });

    const c = document.getElementById(countId);
    if(c) c.textContent = String(keys.length);
  }

  Bus.on('defect-refresh', renderAll);
  Bus.on('selection-changed', renderAll);

  document.getElementById('btnClearGallery')?.addEventListener('click', ()=>{
    const grid = document.getElementById(galleryId); if(grid) grid.innerHTML='';
  });
  document.getElementById('btnClearGallery2')?.addEventListener('click', ()=>{
    const grid = document.getElementById(galleryId); if(grid) grid.innerHTML='';
  });
})();