// static/js/aidi/api.js
(function () {
    if (window.API) return;
  
    function toQuery(params) {
      const usp = new URLSearchParams();
      if (!params) return usp.toString();
  
      Object.keys(params).forEach((k) => {
        const v = params[k];
        if (v == null) return;
        if (Array.isArray(v)) {
          // FastAPI: Query(List[str]) => 重複 keys
          v.forEach((vv) => usp.append(k, String(vv)));
        } else {
          usp.set(k, String(v));
        }
      });
      return usp.toString();
    }
  
    async function get(url, params) {
      const qs = toQuery(params);
      const full = qs ? `${url}?${qs}` : url;
      const res = await fetch(full, { method: "GET" });
      if (!res.ok) {
        let text;
        try { text = await res.text(); } catch (e) { text = res.statusText; }
        throw new Error(`${url} 失敗 (${res.status}) ${text || ""}`);
      }
      return res.json();
    }
  
    window.API = { get };
  })();