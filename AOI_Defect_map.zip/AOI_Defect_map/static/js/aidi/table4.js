// table.js (Fixed: global data wiring + hour normalization + key fallbacks)
(function () {
  const ns = (window.AIDI = window.AIDI || {});
  ns.AIDI_DEBUG = ns.AIDI_DEBUG ?? true;

  // ====== 小工具 ======
  const dlog   = (...a)=> ns.AIDI_DEBUG && console.log("[AIDI:table]", ...a);
  const dgroup = (label, fn)=> { if(!ns.AIDI_DEBUG){ fn?.(); return; } console.group(label); try{ fn?.(); } finally{ console.groupEnd(); } };
  const el     = (tag, attrs={}, children=[])=>{
    const e = document.createElement(tag);
    for (const [k,v] of Object.entries(attrs)){
      if (k==="class") e.className=v;
      else if (k==="style") e.style.cssText=v;
      else e.setAttribute(k,v);
    }
    (Array.isArray(children)?children:[children]).forEach(c=>{
      if (c==null) return;
      e.appendChild(typeof c==="string"?document.createTextNode(c):c);
    });
    return e;
  };
  const getTable = ()=> document.getElementById("aidi-table") || (dlog("找不到 #aidi-table"), null);
  const safe = (v)=> v==null ? "" : String(v);

  // ====== 欄位設定 ======
  const AIDITableCols = {
    line_id: "PI Line",
    aoi_id: "AOI",
    model_id: "Model",
    glass_side: "GS",
    defect_code: "defect_code",
    density: "density",
    glass_count: "glass_num",
    bytimehour: "Hour"
  };

  const GlassSubInfoKeys = [
    "scantime","glass_id","recipe_id",
    "over_defect_count","large_defect_count","middle_defect_count","small_defect_count",
  ];

  const GlassSubInfoCols = {
      "scantime": "scantime",
      "glass_id": "glass",
      "recipe_id": "recipe",
      "over_defect_count": 'O',
      "large_defect_count": 'L',
      "middle_defect_count": 'M',
      "small_defect_count": 'S'
  };

  // ====== 本模組的 local state（可選用；主要走全域） ======
  const state = {
    series: [],
    allSummary: {}, // 若沒從全域取到，才會回退用這個
  };

  // ====== 鍵名容錯 & 時間比對 ======
  function getHour(r){ return r?.bytimehour ?? r?.time ?? r?.by_time_hour ?? r?.Hour ?? ""; }
  function normHourStr(s){ return s ? String(s).slice(0,13) : ""; } // "YYYY-MM-DD HH"
  function getGlassCount(r){ return r?.glass_count ?? r?.glass_num ?? r?.glassCount ?? null; }
  function getDensity(r){ const v = r?.density ?? r?.Density ?? r?.density_value; return v==null ? null : Number(v); }

  // 列資料來源：全域優先，逐層回退
  function getGlobalRows(){
    let rows = (typeof ns.getFiltered === 'function') ? (ns.getFiltered() || []) : [];
    if ((!rows || rows.length===0) && ns.state?.full?.series?.length) rows = ns.state.full.series;
    if ((!rows || rows.length===0) && ns.state?.series?.length)       rows = ns.state.series;
    if ((!rows || rows.length===0)) rows = state.series || [];
    return rows || [];
  }

  // ====== 表頭（只建一次） ======
  function ensureHeaderOnce(){
    const table = getTable(); if (!table) return;
    let thead = table.querySelector("thead");
    if (!thead){ thead = el("thead"); table.appendChild(thead); }
    if (thead.dataset.built === "1") return;

    const tr = el("tr");
    Object.values(AIDITableCols).forEach(text => tr.appendChild(el("th", {}, text)));
    tr.appendChild(el("th", {}, "操作"));
    thead.innerHTML = ""; thead.appendChild(tr);
    thead.dataset.built = "1";
    dlog("[HEADER] 已建立表頭 (values):", Object.values(AIDITableCols));
  }

  // ====== Rowspan 計算 ======
  function computeRowspans(rows, keys){
    const out = {};
    keys.forEach(key=>{
      out[key] = rows.map(()=>({render:false,rowspan:1}));
      let i=0;
      while(i<rows.length){
        const val = rows[i]?.[key];
        let j=i+1; while(j<rows.length && rows[j]?.[key]===val) j++;
        out[key][i] = {render:true,rowspan:j-i};
        for(let k=i+1;k<j;k++) out[key][k] = {render:false,rowspan:0};
        i=j;
      }
    });
    return out;
  }

  // ====== 明細列建構（讀全域 all_summary_dict，回退 local） ======
  function buildDetailRow(row){
    const { line_id, aoi_id, model_id } = row;
    const bytimehour = getHour(row);

    // 全域 → 本地 的順序取 summary
    const allsum =
      (ns.state?.full?.all_summary_dict) ||
      (ns.state?.all_summary_dict) ||
      state.allSummary || {};
    const aoiDict = allsum?.[line_id]?.[aoi_id] || {};
    const arr = Object.values(aoiDict);

    const filtered = arr.filter(o=>{
      if (normHourStr(o.bytimehour || "") !== normHourStr(bytimehour || "")) return false;
      if (o.model_id != null) return String(o.model_id) === String(model_id);
      return true;
    });

    dgroup("Detail match result", ()=>{
      dlog(`allSummary[${line_id}][${aoi_id}] count:`, arr.length);
      dlog("filtered count:", filtered.length);
      filtered.length ? console.table(filtered.slice(0,20)) : dlog("（無符合資料）");
    });

    const tr = el("tr", {class:"detail-row"});
    const td = el("td", {colspan: String(Object.keys(AIDITableCols).length + 1)});
    tr.appendChild(td);

    const box = el("div", {class:"detail-box"});
    box.appendChild(el("div", {class:"detail-title"},
      `明細：${line_id} / ${aoi_id} / ${model_id} / ${bytimehour}`
    ));

    if (!filtered.length){
      box.appendChild(el("div", {class:"detail-empty"}, "（無符合的明細資料）"));
      td.appendChild(box);
      return tr;
    }

    const sub = el("table", {class:"table sub-table"});
    const thead = el("thead");
    const thr = el("tr");
    //const colKeys = Object.values(GlassSubInfoCols);
    Object.values(GlassSubInfoCols).forEach(k=> thr.appendChild(el("th",{},k)));
    thead.appendChild(thr); sub.appendChild(thead);

    const tbody = el("tbody");
    filtered.forEach(o=>{
      const rr = el("tr");
      Object.keys(GlassSubInfoCols).forEach(k=> rr.appendChild(el("td",{},safe(o[k]))));
      tbody.appendChild(rr);
    });
    sub.appendChild(tbody);
    box.appendChild(sub);
    td.appendChild(box);
    return tr;
  }

  function toggleDetail(mainTr, rowData){
    dgroup("Toggle Detail - row payload", ()=>{
      console.table([rowData]);
      dlog("match keys =>", {
        line_id: rowData.line_id,
        aoi_id: rowData.aoi_id,
        model_id: rowData.model_id,
        bytimehour: getHour(rowData),
      });
    });

    const isOpen = mainTr.classList.toggle("is-open");
    const btn = mainTr.querySelector(".col-action > .btn");
    if (btn) btn.textContent = isOpen ? "收合" : "展開";

    const next = mainTr.nextElementSibling;
    if (isOpen){
      const detailTr = buildDetailRow(rowData);
      if (next && next.classList.contains("detail-row")) next.replaceWith(detailTr);
      else mainTr.insertAdjacentElement("afterend", detailTr);
    }else{
      if (next && next.classList.contains("detail-row")) next.remove();
    }
  }

  // ====== 主渲染 ======
  ns.renderTable = function(){
    const table = getTable(); if (!table) return;
    ensureHeaderOnce();

    const data = getGlobalRows();

    dgroup("RenderTable - rows(after filter/global)", ()=>{
      dlog("rows.count:", data.length);
      if (data.length) console.table(data.slice(0,20));
    });

    let tbody = table.querySelector("tbody");
    if (!tbody){ tbody = el("tbody"); table.appendChild(tbody); }
    tbody.innerHTML = "";

    if (!data.length){
      const td = el("td",{colspan:"99"}, state.series.length ? "（無資料，請調整篩選條件）" : "（無資料）");
      tbody.appendChild(el("tr",{}, td));
      return;
    }

    const colKeys = Object.keys(AIDITableCols);
    const rows = data.slice().sort((a,b)=>
      a.line_id!==b.line_id ? String(a.line_id).localeCompare(String(b.line_id)) :
      a.aoi_id!==b.aoi_id   ? String(a.aoi_id).localeCompare(String(b.aoi_id))   :
      a.model_id!==b.model_id ? String(a.model_id).localeCompare(String(b.model_id)) :
      normHourStr(getHour(a)).localeCompare(normHourStr(getHour(b)))
    );
    const spans = computeRowspans(rows, ["line_id","aoi_id"]);

    rows.forEach((r, idx)=>{
      const tr = el("tr",{class:"main-row","data-row-idx":String(idx)});
      for (const key of colKeys){
        if (key==="line_id" || key==="aoi_id"){
          const s = spans[key][idx];
          if (!s.render) continue;
          const td = el("td",{class:`col-${key} merged`,rowspan:String(s.rowspan)});
          td.textContent = safe(r[key]); tr.appendChild(td);
        }else{
          const td = el("td",{class:`col-${key}`});
          if (key === "density"){
            const dv = getDensity(r);
            td.textContent = (dv!=null && isFinite(+dv)) ? (+dv).toFixed(3) : safe(dv);
          } else if (key === "glass_count"){
            td.textContent = safe(getGlassCount(r));
          } else if (key === "bytimehour"){
            td.textContent = safe(getHour(r));
          } else {
            td.textContent = safe(r[key]);
          }
          tr.appendChild(td);
        }
      }
      const act = el("td",{class:"col-action"});
      const btn = el("button",{class:"btn btn-xs"},"展開");
      btn.addEventListener("click", ()=> toggleDetail(tr, r));
      act.appendChild(btn); tr.appendChild(act);
      tbody.appendChild(tr);
    });
  };
  /*
  要針對table
  */
  // ====== Public API：可選，用於主程式主動餵資料 ======
  ns.initAIDITable = function({ series, all_summary_dict }){
    // 單純存到本地，供沒有全域時回退使用；不影響全域 state
    state.series = Array.isArray(series) ? series.map(r => ({
      ...r,
      glass_count: r.glass_count ?? r.glass_num,
      bytimehour: r.bytimehour ?? r.time ?? r.by_time_hour ?? r.Hour
    })) : [];
    state.allSummary = all_summary_dict || {};

    dgroup("InitAIDITable - local snapshot", ()=>{
      dlog("local.series.length:", state.series.length);
      if (state.series.length) console.table(state.series.slice(0,10));
      dlog("local.allSummary.lines:", Object.keys(state.allSummary||{}));
    });

    ensureHeaderOnce();
  };

  // 頁面載入時先把表頭建好（就算還沒資料）
  document.addEventListener("DOMContentLoaded", ensureHeaderOnce);
})();