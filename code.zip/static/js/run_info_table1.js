// static/js/run_info_table1.js — 渲染 Run Info 表（多選 + 排序 + 同 glass 自動濾）
(function(){
  const theadCols = [
    {text:'選'},
    {text:'時間', key:'time', sortable:true},
    {text:'Recipe', key:'recipe_id'},
    {text:'Glass', key:'glass_id'},
    {text:'S', key:'s', sortable:true},
    {text:'M', key:'m', sortable:true},
    {text:'L', key:'l', sortable:true},
    {text:'O', key:'o', sortable:true},
    {text:'總', key:'total', sortable:true}
  ];

  let currentRows = [];
  let sortKey = 'time';
  let sortDir = 'desc';

  function toDate(s){ return Utils.toDate(s); }
  function enrich(r){
    const ds = r.defect_summary || {};
    const s = +(r.small_defect_count ?? ds.small_defect_count ?? 0);
    const m = +(r.middle_defect_count ?? ds.middle_defect_count ?? 0);
    const l = +(r.large_defect_count  ?? ds.large_defect_count  ?? 0);
    const o = +(r.over_defect_count   ?? ds.over_defect_count   ?? 0);
    const total = +(r.defect_count     ?? ds.defect_count        ?? (s+m+l+o));
    return { ...r, s, m, l, o, total };
  }

  function passFilters(rows){
    const q = (State.filters.glassORrecipe || '').toLowerCase();
    let r = rows;
    if(q){
      r = r.filter(x =>
        String(x.glass_id||'').toLowerCase().includes(q) ||
        String(x.recipe_id||'').toLowerCase().includes(q)
      );
    }
    // 同 glass 自動濾（沿用你原邏輯）
    if(State.selectedKeys.length>=1){
      const g = Utils.parseKey(State.selectedKeys[0]).glass_id;
      if(g) r = r.filter(x => x.glass_id === g);
    }
    return r;
  }

  function sortRows(rows){
    const arr = rows.slice();
    if(sortKey==='time'){
      arr.sort((a,b)=> toDate(a.scantime)-toDate(b.scantime));
    }else if(['s','m','l','o','total'].includes(sortKey)){
      arr.sort((a,b)=> (a[sortKey]||0)-(b[sortKey]||0));
    }
    if(sortDir==='desc') arr.reverse();
    return arr;
  }

  function renderHead(thead){
    thead.innerHTML = '';
    const tr = document.createElement('tr');
    theadCols.forEach(c=>{
      const th = document.createElement('th');
      th.textContent = c.text;
      if(c.sortable){
        th.classList.add('sortable');
        th.dataset.key = c.key;
        const arrow = document.createElement('span');
        arrow.className = 'sort-arrow';
        arrow.textContent = (sortKey===c.key ? (sortDir==='asc'?' ▲':' ▼') : ' ↕');
        th.appendChild(arrow);
        th.addEventListener('click', ()=>{
          if(sortKey===c.key){ sortDir = (sortDir==='asc'?'desc':'asc'); }
          else{ sortKey=c.key; sortDir='desc'; }
          render(currentRows);
        });
      }
      tr.appendChild(th);
    });
    thead.appendChild(tr);
  }

  function renderBody(tbody, rows){
    tbody.innerHTML = '';
    rows.forEach(r=>{
      const key = Utils.keyFromRow(r);
      const tr  = document.createElement('tr');
      tr.dataset.key = key;
      //  imgfld：縮圖 base
      const imgfld = r.image_path ? `http://10.97.139.98:1454${r.image_path}` : '';
      tr.dataset.imgfld = imgfld;
      if(State.selectedKeys.includes(key)) tr.classList.add('selected');

      // 只允許點 checkbox
      const tdSel = document.createElement('td');
      const cb = document.createElement('input');
      cb.type='checkbox'; cb.className='sel';
      cb.checked = State.selectedKeys.includes(key);
      tdSel.appendChild(cb);
      tr.appendChild(tdSel);

      const cols = [ r.scantime, r.recipe_id, r.glass_id, r.s, r.m, r.l, r.o, r.total ];
      cols.forEach(val=>{
        const td = document.createElement('td');
        td.textContent = (val==null?'':val);
        tr.appendChild(td);
      });

      cb.addEventListener('change', async ()=>{
        const checked = cb.checked;
        if(checked){
          if(!State.selectedKeys.includes(key)) State.selectedKeys.push(key);
          // 存 imgBase
          //console.log('imgfld',imgfld);
          const base = tr.dataset.imgfld || '';
          Utils.aliasKeys(key).forEach(kk => { State.imgBaseByKey[kk] = base; });

          // 沒有 defects 才打 API
          const nk = Utils.normalizeKey(key);
          if(!State.DefectCache[nk]){
            try{ await API.fetchDefects(nk, State.currentLine); }
            catch(e){ console.error('[run-info] fetchDefects', e); }
          }
        }else{
          State.selectedKeys = State.selectedKeys.filter(k => k !== key);
        }
        document.getElementById('sel-count').textContent = String(State.selectedKeys.length||0);

        // 勾選會影響「同 glass 自動濾」，因此重畫
        Bus.emit('selection-changed', State.selectedKeys.slice());
        // 通知地圖/Defect tables
        Bus.emit('request-defects', State.selectedKeys.slice());
      });

      // 不再綁 tr click（避免誤觸）
      tbody.appendChild(tr);
    });

    const el = document.querySelector('#run-stats .badge b');
    if(el) el.textContent = String(rows.length);
  }

  function render(rows){
    currentRows = (rows||[]).map(enrich);
    const cont  = document.getElementById('run-info-table-container');
    if(!cont) return;
    const thead = cont.querySelector('thead');
    const tbody = cont.querySelector('tbody#run-info-tbody');
    renderHead(thead);
    const filtered = passFilters(currentRows);
    const sorted   = sortRows(filtered);
    renderBody(tbody, sorted);
  }

  Bus.on('render-run-info', rows => render(rows||[]));
  Bus.on('filters-changed', ()=> render(currentRows));
  Bus.on('selection-changed', ()=> render(currentRows));

  // 清除選取
  const btnClear = document.getElementById('btnClearSel');
  if(btnClear){
    btnClear.addEventListener('click', ()=>{
      State.selectedKeys = [];
      document.getElementById('sel-count').textContent = '0';
      Bus.emit('selection-changed', []);
      document.querySelectorAll('#run-info-tbody input.sel').forEach(cb => cb.checked = false);
      document.querySelectorAll('#run-info-tbody tr').forEach(tr => tr.classList.remove('selected'));
    });
  }
})();