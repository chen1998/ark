// ---------- Mock Data ----------
const MockData = {
  MAP_W: 1850,
  MAP_H: 1500,
  run_sheet_list: [],         // rows for run table
  sheet_defect_dict: {},      // { sheet_id: {A:[...], B:[...] } }
  images: {}                  // key: sheet_id|group -> url
};

(function gen(){
  const types = ["Dot","Particle","Line","Butterfly"];
  const sizes = ["S","M","L","O"];
  const tools = ["CCAOI202", "CCAOI203"];
  const ops = ["Tom","Amy","Ben","Cindy","Louis"];
  const now = new Date();
  const mkTime = (mins)=>{
    const d = new Date(now.getTime() - mins*60000);
    const pad = n=> String(n).padStart(2,'0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };

  const N = 12; // sheets
  for(let i=1;i<=N;i++){
    const sheet = "S" + String(i).padStart(3,'0');
    const recipe = "R" + String(100 + (i%7));
    const lot = "L" + String(200 + (i%5));
    const chip = "C" + String(1 + (i%3));
    //const operator = ops[i%ops.length];
    const tool = tools[0];

    // 基底 defects（核心點），再為 A/B 加噪聲，創造部分重疊
    const baseCount = 180 + Math.floor(Math.random()*220); // 180~400
    const base = [];
    for(let k=0;k<baseCount;k++){
      base.push({
        x: Math.random()*MockData.MAP_W,
        y: Math.random()*MockData.MAP_H,
        type: types[Math.floor(Math.random()*types.length)],
        size: sizes[Math.floor(Math.random()*sizes.length)],
        value: +(Math.random()*1.0).toFixed(2)
      });
    }
    function jitter(pt, mag=6){
      return {
        x: Math.max(0, Math.min(MockData.MAP_W, pt.x + (Math.random()*2-1)*mag)),
        y: Math.max(0, Math.min(MockData.MAP_H, pt.y + (Math.random()*2-1)*mag)),
        type: pt.type,
        size: pt.size,
        value: +(pt.value + (Math.random()*0.1-0.05)).toFixed(2)
      };
    }
    const A = base.map(b=>jitter(b, 5));
    const B = base.map(b=>jitter(b, 7));
    MockData.sheet_defect_dict[sheet] = { A, B };

    // 圖像
    MockData.images[`${sheet}|A`] = `https://placehold.co/640x360?text=${sheet}+A`;
    MockData.images[`${sheet}|B`] = `https://placehold.co/640x360?text=${sheet}+B`;

    // run_sheet_list：為每個 group 產生一筆測試時間
    const tA = mkTime(60*i + Math.floor(Math.random()*30));
    const tB = mkTime(60*i + Math.floor(Math.random()*30) - 15);
    MockData.run_sheet_list.push({
      measure_time: tA, recipe_id: recipe, sheet_id: sheet,
      chip, lot_id: lot,  tool //operator,
    });
    MockData.run_sheet_list.push({
      measure_time: tB, recipe_id: recipe, sheet_id: sheet,
      chip, lot_id: lot,  tool //operator,, group: "B", group: "A"
    });
  }
})();

// 初始化
window.addEventListener('DOMContentLoaded', ()=>{
  Bus.emit('init-data', {mock: MockData});
});
