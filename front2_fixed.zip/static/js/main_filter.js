(function(){
  const elFrom = document.getElementById('fDateFrom');
  const elTo   = document.getElementById('fDateTo');
  const elKw   = document.getElementById('fSearch');
  const btnApply = document.getElementById('applyBtn');

  // 預設日期範圍：近 7 天
  const now = new Date();
  const p7  = new Date(now.getTime() - 6*86400000);
  const iso = d=> d.toISOString().slice(0,10);
  if(elFrom) elFrom.value = iso(p7);
  if(elTo)   elTo.value   = iso(now);

  function apply(){
    State.filters.dateFrom = elFrom.value || "";
    State.filters.dateTo   = elTo.value || "";
    State.filters.recipeOrSheet = (elKw.value||"").trim();
    Bus.emit('filters-changed', {...State.filters});
  }

  if(btnApply) btnApply.addEventListener('click', apply);
})();