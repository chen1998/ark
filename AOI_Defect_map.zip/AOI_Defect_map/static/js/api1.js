(function () {
  window.AppData = window.AppData || {
    lineTabs: [],
    allRunInfo: {},   // { line_id: { 0:{...}, 1:{...}, ... } }
    currentLine: null
  };

  async function fetchAll() {
    const res = await fetch('http://10.97.142.217:8100/api/run-info');
    if (!res.ok) throw new Error('API /api-run-info failed');
    return res.json();
  }

  function buildTabs(lineTabs) {
    const cont = document.getElementById('all-tab-container');
    if (!cont) return;
    cont.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'tabs-row';
    lineTabs.forEach((line, idx) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn';
      btn.textContent = line;
      if (idx === 0) btn.classList.add('active');
      btn.addEventListener('click', () => {
        row.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        AppData.currentLine = line;
        const dictRows = AppData.allRunInfo[line] || {};
        const rows = Object.values(dictRows);
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      });
      row.appendChild(btn);
    });
    cont.appendChild(row);
  }

  async function init() {
    try {
      const payload = await fetchAll();
      AppData.lineTabs = payload.AllLineTabs || [];
      AppData.allRunInfo = payload.AllRunInfoTableData || {};
      buildTabs(AppData.lineTabs);

      // 預設顯示第一個 line
      if (AppData.lineTabs.length) {
        AppData.currentLine = AppData.lineTabs[0];
        const dictRows = AppData.allRunInfo[AppData.currentLine] || {};
        const rows = Object.values(dictRows);
        if (typeof window.renderRunSheetTable === 'function') {
          window.renderRunSheetTable(rows);
        }
      }
    } catch (err) {
      console.error('[api.js] init error:', err);
    }
  }

  // 對外：依 line + 日期區間再載入（供之後日期篩選使用）
  window.loadUniByLineAndDates = async function (lineId, start, end) {
    const url = new URL('http://10.97.142.217:8100//api/run-info', window.location.origin);
    if (lineId) url.searchParams.set('line_id', lineId);
    if (start)  url.searchParams.set('start', start);
    if (end)    url.searchParams.set('end', end);
    const res = await fetch(url.toString());
    if (!res.ok) return;
    const data = await res.json();
    if (data.UniRunInfoTableData) {
      AppData.allRunInfo[lineId] = data.UniRunInfoTableData;
      AppData.currentLine = lineId;
      if (typeof window.renderRunSheetTable === 'function') {
        window.renderRunSheetTable(Object.values(data.UniRunInfoTableData));
      }
      // 同步切 tab 的 active（若 UI 需要）
      const cont = document.getElementById('all-tab-container');
      if (cont) {
        cont.querySelectorAll('.tab-btn').forEach(btn => {
          btn.classList.toggle('active', btn.textContent === lineId);
        });
      }
    }
  };

  document.addEventListener('DOMContentLoaded', init);
})();