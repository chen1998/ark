// static/js/defect_map.js
(function(){
  const MAP_W = (window.MockData && MockData.MAP_W) || 1850;
  const MAP_H = (window.MockData && MockData.MAP_H) || 1500;

  const mapSection   = document.getElementById('map-block') || document.getElementById('defect-map-section');
  const mapContainer = document.getElementById('defect-map-container');
  const legendEl     = document.getElementById('map-legend');
  const activeFilterEl = document.getElementById('active-filters');
  const selSummaryEl = document.getElementById('selection-summary');
  const contA = document.getElementById('defect-table-A');
  const contB = document.getElementById('defect-table-B');

  if(!mapContainer) return;

  // canvas
  let canvas = document.getElementById('defect-canvas');
  if(!canvas){ canvas = document.createElement('canvas'); canvas.id = 'defect-canvas'; mapContainer.appendChild(canvas); }
  const ctx = canvas.getContext('2d');

  // tooltip
  let tip = document.getElementById('map-tooltip');
  if(!tip){
    tip = document.createElement('div'); tip.id = 'map-tooltip'; tip.className = 'map-tooltip'; tip.style.display = 'none';
    (mapSection || mapContainer).style.position = (mapSection || mapContainer).style.position || 'relative';
    (mapSection || mapContainer).appendChild(tip);
  }

  // viewport
  let vw = 800, vh = 600;
  const view = { sx:0, sy:0, scale:1 };
  let isPanning=false, lastX=0, lastY=0;
  let boxZoomMode=false, boxStart=null, boxRect=null;

  // hover
  let hoverA=null, hoverB=null;

  // index
  const HASH_CELL=40;
  let idxA=null, idxB=null;
  const worldToScreen=(x,y)=>({x:(x-view.sx)*view.scale, y:(y-view.sy)*view.scale});
  const screenToWorld=(x,y)=>({x:x/view.scale+view.sx, y:y/view.scale+view.sy});
  const radiusForSize=(s)=>({S:2,M:3,L:4,O:6}[s]||3);
  const colorForGroup=(g)=> g==='A' ? '#6aa6ff' : '#9E7BFF';

  function buildIndex(list){
    const m=new Map(); const key=(ix,iy)=>`${ix}|${iy}`;
    for(const d of list){
      const ix=Math.floor(d.x/HASH_CELL), iy=Math.floor(d.y/HASH_CELL);
      const k=key(ix,iy); (m.get(k)||m.set(k,[]).get(k)).push(d);
    }
    return m;
  }

  function renderLegend(){
    if(!legendEl) return;
    legendEl.innerHTML = `
      <div class="legend-item"><span class="legend-dot" style="background:#6aa6ff"></span>第一筆</div>
      <div class="legend-item"><span class="legend-dot" style="background:#9E7BFF"></span>第二筆</div>
      <div class="legend-item"><span class="legend-dot" style="background:#35d49a"></span>相同位置</div>
      <span class="hint">（滾輪縮放、拖曳平移、框選放大）</span>
    `;
  }
  function renderActiveFilterText(){
    if(!activeFilterEl) return;
    const f = State.subFilter || {types:new Set(), sizes:new Set()};
    const t = f.types.size ? `type=${[...f.types].join(',')}` : 'type=ALL';
    const s = f.sizes.size ? `size=${[...f.sizes].join(',')}` : 'size=ALL';
    activeFilterEl.textContent = `作用中篩選：${t}，${s}`;
  }

  // 依 key 取得 compare data（最多兩筆）
  function getCompareData(){
    const keys = State.selectedRows || []; // 這裡是「key 陣列」
    const kA = keys[0], kB = keys[1];

    // 取 defects
    let A = kA ? LR.defectsForKey(kA) : [];
    let B = kB ? LR.defectsForKey(kB) : [];

    // 子篩選
    const types = State.subFilter?.types || new Set();
    const sizes = State.subFilter?.sizes || new Set();
    const pass = (x)=>(!types.size || types.has(x.type)) && (!sizes.size || sizes.has(x.size));

    return [ A.filter(pass), B.filter(pass) ];
  }

  function rowTitleFromKey(prefix, key){
    const r = key ? LR.rowForKey(key) : null;
    if(!r) return prefix;
    const t = new Date(r.measure_time.replace(' ','T')).toLocaleString('zh-TW',{hour12:false});
    return `${t}｜SheetID: ${r.sheet_id}  RecipeID: ${r.recipe_id}`;
  }

  function matchClose(aList,bList,eps=4){
    const grid=new Map(); const key=(x,y)=>`${Math.round(x/eps)}|${Math.round(y/eps)}`;
    bList.forEach(b=>{ const k=key(b.x,b.y); (grid.get(k)||grid.set(k,[]).get(k)).push(b); });
    const matched=[];
    aList.forEach(a=>{ const k=key(a.x,a.y); const arr=grid.get(k); if(arr&&arr.length) matched.push({x:a.x,y:a.y}); });
    return matched;
  }

  function drawGrid(){
    const p1=screenToWorld(0,0), p2=screenToWorld(vw,vh);
    const wx1=Math.max(0,Math.min(p1.x,p2.x)), wy1=Math.max(0,Math.min(p1.y,p2.y));
    const wx2=Math.min(MAP_W,Math.max(p1.x,p2.x)), wy2=Math.min(MAP_H,Math.max(p1.y,p2.y));
    const minor=50, major=200;
    const sxm=Math.floor(wx1/minor)*minor, sym=Math.floor(wy1/minor)*minor;
    const sxM=Math.floor(wx1/major)*major, syM=Math.floor(wy1/major)*major;

    ctx.save(); ctx.lineWidth=1; ctx.strokeStyle='rgba(60,86,126,0.25)';
    for(let x=sxm;x<=wx2;x+=minor){ const sx=worldToScreen(x,0).x; ctx.beginPath(); ctx.moveTo(sx,worldToScreen(0,wy1).y); ctx.lineTo(sx,worldToScreen(0,wy2).y); ctx.stroke(); }
    for(let y=sym;y<=wy2;y+=minor){ const sy=worldToScreen(0,y).y; ctx.beginPath(); ctx.moveTo(worldToScreen(wx1,0).x,sy); ctx.lineTo(worldToScreen(wx2,0).x,sy); ctx.stroke(); }
    ctx.restore();

    ctx.save(); ctx.lineWidth=1; ctx.strokeStyle='rgba(120,160,220,0.35)';
    for(let x=sxM;x<=wx2;x+=major){ const sx=worldToScreen(x,0).x; ctx.beginPath(); ctx.moveTo(sx,worldToScreen(0,wy1).y); ctx.lineTo(sx,worldToScreen(0,wy2).y); ctx.stroke(); }
    for(let y=syM;y<=wy2;y+=major){ const sy=worldToScreen(0,y).y; ctx.beginPath(); ctx.moveTo(worldToScreen(wx1,0).x,sy); ctx.lineTo(worldToScreen(wx2,0).x,sy); ctx.stroke(); }
    ctx.restore();

    ctx.save(); ctx.fillStyle='#9fb0d8'; ctx.font='10px sans-serif';
    for(let x=sxM;x<=wx2;x+=major){ const p=worldToScreen(x,wy1); ctx.fillText(String(x), p.x+2, worldToScreen(0,wy1).y+12); }
    for(let y=syM;y<=wy2;y+=major){ const p=worldToScreen(wx1,y); ctx.fillText(String(y), worldToScreen(wx1,0).x+4, p.y-2); }
    ctx.restore();
  }

  function draw(){
    ctx.clearRect(0,0,vw,vh);
    drawGrid();

    ctx.save(); ctx.strokeStyle='#23324d'; ctx.lineWidth=1;
    const tl=worldToScreen(0,0), br=worldToScreen(MAP_W,MAP_H);
    ctx.strokeRect(tl.x,tl.y,br.x-tl.x, br.y-tl.y);
    ctx.restore();

    const [A,B] = getCompareData();

    ctx.fillStyle = '#6aa6ff';
    A.forEach(d=>{ const p=worldToScreen(d.x,d.y); ctx.beginPath(); ctx.arc(p.x,p.y,radiusForSize(d.size),0,Math.PI*2); ctx.fill(); });

    ctx.fillStyle = '#9E7BFF';
    B.forEach(d=>{ const p=worldToScreen(d.x,d.y); ctx.beginPath(); ctx.arc(p.x,p.y,radiusForSize(d.size),0,Math.PI*2); ctx.fill(); });

    const same = matchClose(A,B,4);
    ctx.fillStyle='#35d49a';
    same.forEach(pt=>{ const p=worldToScreen(pt.x,pt.y); ctx.beginPath(); ctx.arc(p.x,p.y,2.5,0,Math.PI*2); ctx.fill(); });

    if(boxRect){
      ctx.save(); ctx.strokeStyle='#8fb3ff'; ctx.setLineDash([4,3]); ctx.strokeRect(boxRect.x,boxRect.y,boxRect.w,boxRect.h); ctx.restore();
    }
  }

  function zoomFit(){
    const scaleX=vw/MAP_W, scaleY=vh/MAP_H;
    view.scale=Math.min(scaleX,scaleY); view.sx=0; view.sy=0; draw();
  }
  function zoomAt(cx,cy,f){
    const b=screenToWorld(cx,cy); view.scale*=f; const a=screenToWorld(cx,cy); view.sx+=(b.x-a.x); view.sy+=(b.y-a.y); draw();
  }

  function queryNearestByPixel(px,py){
    const screenRadius=8, worldRadius=screenRadius/view.scale;
    const {x:wx,y:wy} = screenToWorld(px,py);
    const ix=Math.floor(wx/HASH_CELL), iy=Math.floor(wy/HASH_CELL);
    const around=(idx)=>{ if(!idx) return null;
      let best=null, bestDist=Infinity, bestScreen=null;
      for(let dx=-1;dx<=1;dx++){ for(let dy=-1;dy<=1;dy++){
        const arr=idx.get(`${ix+dx}|${iy+dy}`); if(!arr) continue;
        for(const d of arr){
          if(Math.abs(d.x-wx)>worldRadius || Math.abs(d.y-wy)>worldRadius) continue;
          const s=worldToScreen(d.x,d.y); const dd=Math.hypot(s.x-px, s.y-py);
          if(dd<=screenRadius && dd<bestDist){ bestDist=dd; best=d; bestScreen=s; }
        }
      }} return best ? {d:best,screen:bestScreen,distPx:bestDist}:null;
    };
    return { candA: around(idxA), candB: around(idxB) };
  }

  // 互動
  canvas.addEventListener('wheel', e=>{ e.preventDefault(); zoomAt(e.offsetX,e.offsetY, e.deltaY<0?1.15:1/1.15); });
  canvas.addEventListener('mousedown', e=>{
    if(boxZoomMode){ boxStart={x:e.offsetX,y:e.offsetY}; boxRect={x:boxStart.x,y:boxStart.y,w:0,h:0}; draw(); return; }
    isPanning=true; lastX=e.offsetX; lastY=e.offsetY;
  });
  canvas.addEventListener('mousemove', e=>{
    if(boxStart){ boxRect.w=e.offsetX-boxStart.x; boxRect.h=e.offsetY-boxStart.y; draw(); return; }
    if(isPanning){
      const dx=(e.offsetX-lastX)/view.scale, dy=(e.offsetY-lastY)/view.scale;
      view.sx-=dx; view.sy-=dy; lastX=e.offsetX; lastY=e.offsetY; draw(); return;
    }
    const {candA,candB}=queryNearestByPixel(e.offsetX,e.offsetY);
    hoverA=candA; hoverB=candB;

    if(candA||candB){
      let html=`<div class="meta">滑鼠附近 Defect（半徑 8px）</div>`;
      if(candA){
        const d=candA.d;
        html+=`<div class="row"><span class="dot" style="background:#6aa6ff"></span>
               <div>第一筆 | Type:${d.type} | Size:${d.size} | Val:${d.value}</div>
               <div class="meta">${candA.distPx.toFixed(1)}px</div></div>
               <div class="row"><span></span><div>(x,y)= ${d.x.toFixed(1)}, ${d.y.toFixed(1)}</div><span></span></div>`;
      }
      if(candB){
        const d=candB.d;
        html+=`<div class="sep"></div>
               <div class="row"><span class="dot" style="background:#9E7BFF"></span>
               <div>第二筆 | Type:${d.type} | Size:${d.size} | Val:${d.value}</div>
               <div class="meta">${candB.distPx.toFixed(1)}px</div></div>
               <div class="row"><span></span><div>(x,y)= ${d.x.toFixed(1)}, ${d.y.toFixed(1)}</div><span></span></div>`;
      }
      tip.innerHTML=html; tip.style.display='block';
      const rect=(mapSection||mapContainer).getBoundingClientRect();
      let tx=e.clientX-rect.left+12, ty=e.clientY-rect.top+12;
      const tr=tip.getBoundingClientRect();
      if(tx+tr.width>rect.width-8) tx=rect.width-tr.width-8;
      if(ty+tr.height>rect.height-8) ty=rect.height-tr.height-8;
      tip.style.left=`${tx}px`; tip.style.top=`${ty}px`;
    }else{
      tip.style.display='none';
    }
    draw();
  });
  canvas.addEventListener('mouseleave', ()=>{ hoverA=hoverB=null; tip.style.display='none'; draw(); });
  window.addEventListener('mouseup', ()=>{
    if(isPanning) isPanning=false;
    if(boxStart){
      const x1=Math.min(boxStart.x, boxStart.x+boxRect.w), y1=Math.min(boxStart.y, boxStart.y+boxRect.h);
      const x2=Math.max(boxStart.x, boxStart.x+boxRect.w), y2=Math.max(boxStart.y, boxStart.y+boxRect.h);
      const w=x2-x1, h=y2-y1;
      if(w>10 && h>10){
        const p1=screenToWorld(x1,y1), p2=screenToWorld(x2,y2);
        const s=Math.min(vw/(p2.x-p1.x), vh/(p2.y-p1.y));
        view.scale=s; view.sx=p1.x; view.sy=p1.y;
      }
      boxStart=null; boxRect=null; boxZoomMode=false; draw();
    }
  });
  canvas.addEventListener('dblclick', zoomFit);

  // 控制鈕
  const btn = (id,fn)=>{ const el=document.getElementById(id); if(el) el.addEventListener('click', fn); };
  btn('map-zoom-fit', zoomFit);
  btn('map-zoom-in', ()=>zoomAt(vw/2,vh/2,1.25));
  btn('map-zoom-out',()=>zoomAt(vw/2,vh/2,0.8));
  btn('map-box-zoom',()=>{ boxZoomMode=true; toast && toast('框選放大：在畫面上拖拉矩形'); });

  // Resize
  const ro=new ResizeObserver(entries=>{
    for(const entry of entries){
      const cw=entry.contentRect.width, ch=entry.contentRect.height;
      const idealH=Math.round(cw*(MAP_H/MAP_W));
      const useH=Math.min(ch||idealH, idealH);
      canvas.width=vw=Math.max(400, Math.round(cw-2));
      canvas.height=vh=Math.max(300, useH);
      zoomFit();
    }
  });
  ro.observe(mapContainer);

  // ---- Defect tables rendering (依 key) ----
  function buildTable(container, title, arr){
    if(!container) return;
    container.innerHTML = "";

    const headBar=document.createElement('div');
    headBar.className='section-title';
    const titleSpan=document.createElement('span'); titleSpan.textContent=title||'';
    const stats=document.createElement('span'); stats.className='stats-badges';
    stats.innerHTML=`<span class="badge">筆數 <b>${arr.length}</b></span>`;
    headBar.appendChild(titleSpan); headBar.appendChild(stats);
    container.appendChild(headBar);

    const wrap=document.createElement('div'); wrap.className='table-wrap';
    const table=document.createElement('table'); table.className='table';
    const thead=document.createElement('thead'); const trh=document.createElement('tr');
    ["Type","Size","Value","X","Y"].forEach(n=>{ const th=document.createElement('th'); th.textContent=n; trh.appendChild(th); });
    thead.appendChild(trh); table.appendChild(thead);

    const tbody=document.createElement('tbody');
    arr.forEach(r=>{
      const tr=document.createElement('tr');
      [r.type, r.size, r.value, r.x.toFixed(1), r.y.toFixed(1)].forEach(val=>{
        const td=document.createElement('td'); td.textContent=val; tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody); wrap.appendChild(table); container.appendChild(wrap);
  }

  function renderDefectTables(){
    if(!contA || !contB) return;
    const keys = State.selectedRows || [];
    const kA=keys[0], kB=keys[1];

    const A = kA ? LR.defectsForKey(kA) : [];
    const B = kB ? LR.defectsForKey(kB) : [];

    // 建索引供 hover
    const pass = (x)=> {
      const types = State.subFilter?.types || new Set();
      const sizes = State.subFilter?.sizes || new Set();
      return (!types.size || types.has(x.type)) && (!sizes.size || sizes.has(x.size));
    };
    const Af = A.filter(pass), Bf = B.filter(pass);
    idxA = buildIndex(Af); idxB = buildIndex(Bf);

    const titleA = rowTitleFromKey('第一筆', kA);
    const titleB = rowTitleFromKey('第二筆', kB);

    buildTable(contA, titleA, Af);
    buildTable(contB, titleB, Bf);

    if(selSummaryEl){
      const rows = keys.map(k => LR.rowForKey(k)).filter(Boolean);
      const types = State.subFilter?.types || new Set();
      const sizes = State.subFilter?.sizes || new Set();
      const t = types.size ? [...types].join(',') : 'ALL';
      const s = sizes.size ? [...sizes].join(',') : 'ALL';
      const picked = rows.length
        ? rows.map(r=>`${r.sheet_id} @ ${r.measure_time}`).join('；')
        : '尚未勾選 Run 貨列';
      selSummaryEl.innerHTML = `
        <div><b>目前勾選：</b>${picked}</div>
        <div><b>子篩選：</b>type=${t}，size=${s}</div>
        <div class="meta">A 筆數：${Af.length}；B 筆數：${Bf.length}</div>
      `;
    }
  }

  function refreshAll(){
    renderActiveFilterText();
    renderDefectTables();
    draw();
  }

  Bus.on('init-data', ()=>{ renderLegend(); refreshAll(); });
  Bus.on('compare-selection-changed', refreshAll);
  Bus.on('sub-filter-changed', refreshAll);
})();

