// 右側篩選（建置 MultiDD、預設全選；選項固定使用 AOI.state.uniques，不隨篩選縮減）
(function(){
  const AOI = (window.AOI_DENSITY = window.AOI_DENSITY || {});
  AOI.Filter = AOI.Filter || {};

  const $  = (sel, root=document) => root.querySelector(sel);
  const el = (tag, attrs={})=>{
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([k,v])=>{
      if (k === 'class') node.className = v; else node.setAttribute(k, v);
    });
    return node;
  };

  // ParamDict 的 key → DOM selectId / hostId / 來源資料鍵
  const FIELD_CONFIG = {
    line_id:      { selectId:'line-id',     hostId:'aoiLine-dd'  },
    aoi:          { selectId:'aoi-id',      hostId:'aoiAOI-dd'   },
    model:        { selectId:'model-id',    hostId:'aoiModel-dd' },
    glass_type:   { selectId:'glass-type',  hostId:'aoiSide-dd'  },
    adc_def_code: { selectId:'defect-code', hostId:'aoiCode-dd', dataKey:'ai_code_1' },
    defect_size:  { selectId:'defect-size', hostId:'aoiSize-dd', fixed:['S','M','L','O'] }
  };

  function getDisplayName(cfgKey){
    const map = AOI.state.paramDict?.filtetItemKeyDict || {};
    return map?.[cfgKey] || cfgKey;
  }

  // 若沒有 host、也沒有 select，建立備援 select（顯示用）
  function ensureFallbackSelect(cfgKey, meta){
    let sel = $('#'+meta.selectId);
    if (sel) return sel;
    const aside = $('#aoi_density-right');
    if (!aside) return null;

    const item = el('div', {class:'filter-item'});
    const label = el('label', {class:'lbl'});
    label.textContent = getDisplayName(cfgKey);
    sel = el('select', { id: meta.selectId, multiple:'multiple' });

    item.append(label, sel);
    const actions = $('#aoi_density-right .filter-actions') || null;
    aside.insertBefore(item, actions);

    return sel;
  }

  // === 建立／更新 MultiDD；預設全選（只有尚未選取時） ===
  AOI.Filter.ensureWidgets = function(){
    const cfgMap  = AOI.state.paramDict?.filtetItemKeyDict || {};
    const uniques = AOI.state.uniques || {};
    AOI.mdd = AOI.mdd || {};

    let didDefaultAny = false;

    Object.entries(FIELD_CONFIG).forEach(([cfgKey, meta])=>{
      console.log(cfgKey, meta);
      if (!(cfgKey in cfgMap)) return;

      let opts;
      if (meta.fixed) opts = meta.fixed.slice();
      else {
        const dataKey = meta.dataKey || cfgKey;
        opts = (uniques[dataKey] || []).slice();
      }

      const title = getDisplayName(cfgKey);
      const hostEl = $('#'+meta.hostId);

      if (hostEl) {
        if (AOI.mdd[cfgKey]) {
          AOI.mdd[cfgKey].title = title;
          AOI.mdd[cfgKey].updateOptions(opts);
        } else {
          AOI.mdd[cfgKey] = new AOI.MultiDD({
            hostId: meta.hostId,
            selectId: meta.selectId,
            options: opts,
            title,
            onChange: ()=>{/* 由 router 監聽 select.change 觸發 redraw */}
          });
        }
        const cur = AOI.mdd[cfgKey].getSelected();
        if ((!cur || cur.length === 0) && opts.length) {
          AOI.mdd[cfgKey].setSelected(opts); // 預設全選
          const sel = document.getElementById(meta.selectId);
          if (sel) sel.dispatchEvent(new Event('change', {bubbles:true}));
          didDefaultAny = true;
        }
      } else {
        const selectEl = ensureFallbackSelect(cfgKey, meta);
        if (selectEl) {
          selectEl.innerHTML = '';
          opts.sort().forEach(v=>{
            const o = document.createElement('option');
            o.value = v; o.textContent = v;
            o.selected = true; // 預設全選
            selectEl.appendChild(o);
          });
          selectEl.dispatchEvent(new Event('change', {bubbles:true}));
          didDefaultAny = true;
        }
      }
    });
    /*
    
    */

    if (didDefaultAny) {
      const anySel = document.getElementById('line-id') || document.getElementById('aoi-id') ||
                     document.getElementById('model-id') || document.getElementById('glass-type');
      anySel?.dispatchEvent(new Event('change', {bubbles:true}));
    }
  };

  // 初始化：資料 ready（新資料或重新初始化）時建置/更新 MultiDD
  document.addEventListener('aoi_density:data-ready', ()=>{
    AOI.Filter.ensureWidgets();
  });

})();