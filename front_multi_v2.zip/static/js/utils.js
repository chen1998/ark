// utils.js — 小工具
(function(){
  const palette = [
    '#4F6BED', '#E39A2E', '#7FBA00', '#D13438', '#8764B8',
    '#038387', '#CA5010', '#FF8C00', '#5C2D91', '#038387',
    '#69797E', '#008272', '#B4009E', '#00B7C3', '#393939'
  ];

  function getColor(idx){
    return palette[idx % palette.length];
  }

  function keyFromRow(r){
    // 期望後端回傳 'YYYY-MM-DD HH:MM:SS'。不要轉成 T，以免 SQL = 比對出錯
    return [r.scantime, r.glass_id, r.recipe_id].join('|');
  }

  function parseKey(k){
    const parts = String(k||'').split('|');
    return { scantime: parts[0] || '', glass_id: parts[1] || '', recipe_id: parts[2] || '' };
  }

  window.Utils = { getColor, keyFromRow, parseKey };
})();
