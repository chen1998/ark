// api.js (ES Module)
const BASE = ''; // 如果後端有前綴，例如 '/aoi'，請改成 const BASE = '/aoi';

function toQuery(params) {
  const usp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null) continue;
    if (Array.isArray(v)) {
      // FastAPI List[str]: 重複 key
      v.forEach(x => usp.append(k, x));
    } else {
      usp.set(k, v);
    }
  }
  return usp.toString();
}

async function getJSON(path, params={}) {
  const qs = toQuery(params);
  const url = `${BASE}${path}${qs ? ('?' + qs) : ''}`;
  const res = await fetch(url, { method: 'GET' });
  if (!res.ok) {
    const t = await res.text().catch(()=>''); 
    throw new Error(`${url} 失敗 (${res.status}) ${t}`);
  }
  return res.json();
}

// 封裝：reset_summary_filter
export async function resetSummaryFilter({ dates=null, filters={} } = {}) {
  const params = {};
  if (Array.isArray(dates) && dates.length === 2) {
    // FastAPI: Query(Optional[List[str]])
    params['dates'] = dates;
  }
  if (filters && Object.keys(filters).length) {
    params['filter_ask_keys'] = JSON.stringify(filters);
  }
  return getJSON('/api/reset_summary_filter', params);
}

// 預留：defect_map（目前前端先不使用）
export async function defectMap(filters = {}) {
  const params = {};
  if (filters && Object.keys(filters).length) {
    params['filter_ask_keys'] = JSON.stringify(filters);
  }
  return getJSON('/api/defect_map', params);
}
