// static/js/aidi/service2.js
(function () {
    const AIDI = (window.AIDI = window.AIDI || {});
    AIDI.state = {
      payload: null,      // 後端原始回傳
      rows: [],           // 正規化後的列資料
      uniques: {},        // 唯一值：for 篩選器
      timeRange: null,    // {min: Date, max: Date}
      paramDict: null     // 後端 ParamDict（chartKeyDict 等）
    };
  
    function fmtPiHourToShort(s) {
      // 後端多半是 "YYYY-MM-DD HH:00:00"
      // 前端要 "yy-mm-dd hh"
      if (!s) return "";
      const d = new Date(s.replace(" ", "T")); // Safari 容錯
      if (isNaN(d.getTime())) {
        // 退而求其次：手動擷取
        // "2025-09-16 15:00:00" -> "25-09-16 15"
        const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2})/);
        if (m) {
          const yy = m[1].slice(-2);
          return `${yy}-${m[2]}-${m[3]} ${m[4]}`;
        }
        return String(s);
      }
      const yy = String(d.getFullYear()).slice(-2);
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const hh = String(d.getHours()).padStart(2, "0");
      return `${yy}-${mm}-${dd} ${hh}`;
    }
  
    function parsePiHourToDate(s) {
      // 能回推 Date，用來做時間範圍計算
      // 支援 "YYYY-MM-DD HH:00:00" 或 "yy-mm-dd hh"
      if (!s) return null;
      if (/^\d{2}-\d{2}-\d{2}\s+\d{2}$/.test(s)) {
        const [datePart, hh] = s.split(/\s+/);
        const [yy, mm, dd] = datePart.split("-").map(Number);
        const fullYear = 2000 + yy; // 假設 20xx
        return new Date(fullYear, mm - 1, dd, Number(hh), 0, 0);
      }
      const d = new Date(String(s).replace(" ", "T"));
      return isNaN(d.getTime()) ? null : d;
    }
  
    function buildFilterJSON(filters) {
      // 後端的 filter_ask_keys 是 JSON 字串
      if (!filters || typeof filters !== "object") return "{}";
      return JSON.stringify(filters);
    }
  
    function arraysEqual(a, b) {
      if (!Array.isArray(a) || !Array.isArray(b)) return false;
      if (a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
      return true;
    }
  
    function toDatesParam(dates) {
      // FastAPI List[str]：?dates=...&dates=...
      if (!dates || dates.length !== 2) return undefined;
      return dates;
    }
  
    function calcTimeRange(rows) {
      if (!rows || !rows.length) return null;
      let min = Infinity, max = -Infinity;
      rows.forEach((r) => {
        const d = parsePiHourToDate(r.pi_hour);
        if (!d) return;
        const t = d.getTime();
        if (t < min) min = t;
        if (t > max) max = t;
      });
      if (min === Infinity) return null;
      return { min: new Date(min), max: new Date(max) };
    }
  
    function flattenChartDataDict(chartDict) {
      // 巢狀：line_id → aoi → model → glass_type → ai_code_1 → pi_hour
      // 轉為列資料
      const out = [];
      const uniques = {
        line_id: new Set(),
        aoi: new Set(),
        model: new Set(),
        glass_type: new Set(),
        ai_code_1: new Set(),
        defect_type: new Set(),
        pi: new Set(),           // 若 FilterData 有 pi，後面補
        recipe_id: new Set()     // 同上
      };
  
      if (!chartDict || typeof chartDict !== "object") {
        return { rows: [], uniques };
      }
  
      Object.keys(chartDict).forEach((line_id) => {
        const D1 = chartDict[line_id] || {};
        Object.keys(D1).forEach((aoi) => {
          const D2 = D1[aoi] || {};
          Object.keys(D2).forEach((model) => {
            const D3 = D2[model] || {};
            Object.keys(D3).forEach((glass_type) => {
              const D4 = D3[glass_type] || {};
              Object.keys(D4).forEach((ai_code_1) => {
                const hourly = D4[ai_code_1] || {};
                Object.keys(hourly).forEach((pi_hour_key) => {
                  const v = hourly[pi_hour_key] || {};
                  const row = {
                    line_id,
                    aoi,
                    model,
                    glass_type,
                    ai_code_1: ai_code_1 || "",
                    defect_type: v.defect_type || "",
                    // 轉兩位數年份格式
                    pi_hour: fmtPiHourToShort(pi_hour_key),
                    n_rows: Number(v.n_rows || 0),
                    n_glasses: Number(v.n_glasses || 0),
                    small_defect_count: Number(v.small_defect_count || 0),
                    middle_defect_count: Number(v.middle_defect_count || 0),
                    large_defect_count: Number(v.large_defect_count || 0),
                    over_defect_count: Number(v.over_defect_count || 0),
                    unknown_defect_count: Number(v.unknown_defect_count || 0),
                    glass: v.glass || ""
                  };
                  out.push(row);
  
                  uniques.line_id.add(line_id);
                  uniques.aoi.add(aoi);
                  uniques.model.add(model);
                  uniques.glass_type.add(glass_type);
                  if (row.ai_code_1) uniques.ai_code_1.add(row.ai_code_1);
                  if (row.defect_type) uniques.defect_type.add(row.defect_type);
                });
              });
            });
          });
        });
      });
  
      return { rows: out, uniques };
    }
  
    function mergeUniques(uA, uB) {
      const out = {};
      const keys = new Set([...Object.keys(uA || {}), ...Object.keys(uB || {})]);
      keys.forEach((k) => {
        out[k] = new Set();
        (uA?.[k] || []).forEach?.((x) => out[k].add(x));
        (uB?.[k] || []).forEach?.((x) => out[k].add(x));
      });
      return out;
    }
  
    // ===== 對外：抓資料 =====
    AIDI.fetchAIDIData = async function (opts) {
      const dates = opts?.dates && Array.isArray(opts.dates) ? opts.dates : undefined;
      const filters = opts?.filters || {};
  
      const params = {
        filter_ask_keys: buildFilterJSON(filters)
      };
      const datesParam = toDatesParam(dates);
      if (datesParam) params.dates = datesParam;
  
      const payload = await window.API.get(`${window.API_BASE}/aoi_density/api/reset_summary_filter`, params);
      console.log(payload);
      // 保存原始 payload
      AIDI.state.payload = payload;
      AIDI.state.paramDict = payload?.ParamDict || null;
  
      // 正規化
      const { rows, uniques } = flattenChartDataDict(payload?.ChartDataDict || {});
      // 若 FilterData 有 pi/recipe_id，也補進 uniques
      const extra = { pi: new Set(), recipe_id: new Set() };
      (payload?.FilterData || []).forEach((r) => {
        if (r?.pi) extra.pi.add(r.pi);
        if (r?.recipe_id) extra.recipe_id.add(r.recipe_id);
      });
  
      // 存 state
      AIDI.state.rows = rows;
      AIDI.state.uniques = {
        line_id: Array.from(uniques.line_id),
        aoi: Array.from(uniques.aoi),
        model: Array.from(uniques.model),
        glass_type: Array.from(uniques.glass_type),
        ai_code_1: Array.from(uniques.ai_code_1),
        defect_type: Array.from(uniques.defect_type),
        pi: Array.from(extra.pi),
        recipe_id: Array.from(extra.recipe_id)
      };
      AIDI.state.timeRange = calcTimeRange(rows);
  
      // 對外通知
      document.dispatchEvent(new CustomEvent("aidi:data-ready", {
        detail: { rows: AIDI.state.rows, uniques: AIDI.state.uniques, timeRange: AIDI.state.timeRange, paramDict: AIDI.state.paramDict }
      }));
  
      return payload;
    };
  
    // ===== 對外：過濾（依 UI 或傳入條件） =====
    AIDI.getFiltered = function (opts) {
      const rows = AIDI.state.rows || [];
      if (!rows.length) return [];
  
      const filters = (opts && opts.filters) || readFiltersFromUI();
      const dates = (opts && opts.dates) || readDatesFromUI();
  
      // 先做基本等值過濾
      const keys = ["line_id", "aoi", "model", "glass_type", "ai_code_1"];
      let out = rows.filter((r) => {
        for (const k of keys) {
          const arr = filters?.[k];
          if (arr && arr.length) {
            if (!arr.includes(r[k])) return false;
          }
        }
        return true;
      });
  
      // defect_size: S/M/L/O 任一 > 0 通過
      const sizeMap = {
        S: "small_defect_count",
        M: "middle_defect_count",
        L: "large_defect_count",
        O: "over_defect_count"
      };
      if (filters?.defect_size && filters.defect_size.length) {
        const cols = filters.defect_size.map((s) => sizeMap[s]).filter(Boolean);
        if (cols.length) {
          out = out.filter((r) => cols.some((c) => Number(r[c] || 0) > 0));
        }
      }
  
      // 時間範圍（用兩位年 pi_hour 格式）
      if (dates && dates.length === 2) {
        const begin = parsePiHourToDate(fmtPiHourToShort(dates[0] + " 00")); // 若只給日期，補 HH
        const end   = parsePiHourToDate(fmtPiHourToShort(dates[1] + " 23"));
        if (begin && end) {
          const b = begin.getTime();
          const e = end.getTime();
          out = out.filter((r) => {
            const t = parsePiHourToDate(r.pi_hour)?.getTime();
            return typeof t === "number" && t >= b && t <= e;
          });
        }
      }
      return out;
    };
  
    // ====== UI 讀取（若你的 ID 不同，改這兩個函式即可） ======
    function readDatesFromUI() {
      const b = document.querySelector("#date-begin");
      const e = document.querySelector("#date-end");
      const begin = b && b.value ? b.value : undefined; // 期望 "YYYY-MM-DD"
      const end   = e && e.value ? e.value : undefined;
      return (begin && end) ? [begin, end] : undefined;
    }
  
    function readMultiSelectValues(id) {
      const el = document.getElementById(id);
      if (!el) return [];
      if (el.tagName === "SELECT" && el.multiple) {
        return Array.from(el.selectedOptions).map((o) => o.value).filter(Boolean);
      }
      // 若是 chips / checkbox group，請自行改這裡的擷取方式
      const val = el.value;
      if (!val) return [];
      try {
        const arr = JSON.parse(val);
        return Array.isArray(arr) ? arr : [val];
      } catch {
        return [val];
      }
    }
  
    function readFiltersFromUI() {
      return {
        line_id: readMultiSelectValues("line-id"),     // <select multiple id="line-id">
        aoi: readMultiSelectValues("aoi-id"),          // <select multiple id="aoi-id">
        model: readMultiSelectValues("model-id"),
        glass_type: readMultiSelectValues("glass-type"),
        ai_code_1: readMultiSelectValues("defect-code"),
        defect_size: readMultiSelectValues("defect-size") // ['S','M','L','O']
        // 若你還有 pi / recipe_id 等，也可加上
      };
    }
  })();
  