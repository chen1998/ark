// static/js/aoi_density/table.js
// 依 ParamDict（hourlyTable / chartKeyDict）動態產表：
// 1) 表頭：完全依 ParamDict['hourlyTable'] 的 key→標題映射，不看 DictData 內容是否有該欄
// 2) 分組鍵：依 ParamDict['chartKeyDict'] 推導（left + up + down），自動排除度量(right、n_glasses、density)與 per-glass 欄位(glass、glass_defect_count)
// 3) 每筆 DictData 的 glass 以逗號切開 → 展開為多列；非 per-glass 欄位只在群組首列輸出並加 rowspan
(function () {
    const MOD = (window.AOI_DENSITY = window.AOI_DENSITY || {});
    MOD.Table = MOD.Table || {};
  
    const $ = (sel, root = document) => root.querySelector(sel);
  
    // ---------- 小工具 ----------
    const isObj = (o) => o && typeof o === "object" && !Array.isArray(o);
    const toArr = (x) => (Array.isArray(x) ? x : []);
    function parseGlassList(val) {
      if (val == null) return [];
      if (Array.isArray(val)) return val.map(String).map((s) => s.trim()).filter(Boolean);
      return String(val).split(",").map((s) => s.trim()).filter(Boolean);
    }
    function dateKeySorter(a, b) {
      // 期望 "yy-mm-dd hh"
      const da = new Date("20" + String(a).replace(" ", "T"));
      const db = new Date("20" + String(b).replace(" ", "T"));
      return da - db;
    }
  
    // ---------- 依 ParamDict 推導欄位/分組規格 ----------
    function getPerGlassSet(hourlyTable) {
      // 哪些欄位屬於「每片玻璃一列」：只要 hourlyTable 中包含 'glass' 或 'glass_defect_count' 就視為 per-glass
      const s = new Set();
      Object.keys(hourlyTable || {}).forEach((k) => {
        if (k === "glass" || k === "glass_defect_count") s.add(k);
      });
      return s;
    }
  
    function getGroupingSpec(paramDict, rows) {
      const ckd = paramDict?.chartKeyDict || {};
      const hourlyTable = paramDict?.hourlyTable || {};
  
      // 視為度量的欄位（不做群組鍵）：right + 常見度量
      const metric = new Set([...(ckd.right || []), "n_glasses", "density"]);
  
      // 依設定的順序：left(剔除度量) → up → down
      const leftDims = toArr(ckd.left).filter((k) => !metric.has(k));
      const upDims = toArr(ckd.up);
      const downDims = toArr(ckd.down);
  
      // per-glass 欄位（不做群組鍵）
      const perGlass = getPerGlassSet(hourlyTable);
  
      // 起始維度（避免重覆）
      let dims = [...leftDims, ...upDims, ...downDims];
  
      // 若後端 hourlyTable 存在的欄位、或 rows 內常見維度（例如 glass_type）未被列入，則補上（仍排除度量與 per-glass）
      const sample = Array.isArray(rows) && rows.length ? rows[0] : {};
      const allKeys = new Set([
        ...Object.keys(hourlyTable || {}),
        ...Object.keys(sample || {})
      ]);
      for (const k of allKeys) {
        if (!dims.includes(k) && !metric.has(k) && !perGlass.has(k)) {
          // 避免把 pi_hour 重覆補進來
          if (downDims.includes(k)) continue;
          dims.splice(leftDims.length, 0, k); // 補在 left 與 up 之間較合理
        }
      }
  
      // 去重
      dims = Array.from(new Set(dims));
  
      // 哪些是時間鍵（通常就是 down 維度）
      const timeKeys = new Set(downDims);
  
      return { dims, timeKeys, perGlass };
    }
  
    // ---------- rows 展開成「每片玻璃一列」並附群組資訊 ----------
    function expandRowsByGlass(rows, paramDict) {
      const out = [];
      const { dims, perGlass, timeKeys } = getGroupingSpec(paramDict, rows);
  
      (rows || []).forEach((r) => {
        // 本筆的所有玻璃
        const gList = parseGlassList(r.glass);
        const glassList = gList.length ? gList : [""]; // 無資料也至少一列
  
        // 群組鍵（不含 per-glass 欄位）
        const gKeyVals = dims
          .filter((k) => !perGlass.has(k))
          .map((k) => (r[k] == null ? "" : String(r[k])));
        const groupKey = gKeyVals.join("¦");
  
        // 玻璃對應的 defect 數量（可能無）
        let gdc = {};
        if (isObj(r.glass_defect_count)) {
          gdc = r.glass_defect_count;
        } else if (typeof r.glass_defect_count === "string") {
          try {
            const obj = JSON.parse(r.glass_defect_count);
            if (isObj(obj)) gdc = obj;
          } catch {}
        }
  
        glassList.forEach((glassId, idx) => {
          out.push({
            __groupKey: groupKey,
            __groupSize: glassList.length,
            __groupIndex: idx,
            __glassId: glassId,
            ...r,
            glass: glassId,
            glass_defect_count: gdc
          });
        });
      });
  
      // 依 dims 順序排序；遇到時間鍵用時間排序；最後再以 glass 排序
      out.sort((a, b) => {
        for (const k of dims) {
          if (perGlass.has(k)) continue; // 不把 per-glass 欄位放在分組排序序列
          const va = a[k] ?? "";
          const vb = b[k] ?? "";
          if (timeKeys.has(k)) {
            const cmp = dateKeySorter(va, vb);
            if (cmp !== 0) return cmp;
          } else {
            const sa = String(va);
            const sb = String(vb);
            if (sa < sb) return -1;
            if (sa > sb) return 1;
          }
        }
        const ga = String(a.glass || "");
        const gb = String(b.glass || "");
        if (ga < gb) return -1;
        if (ga > gb) return 1;
        return 0;
      });
  
      return { rows: out, dims, perGlass, timeKeys };
    }
  
    // ---------- 表頭 ----------
    function renderHeader(colDict) {
      const thead = $("#aoi_density-table thead");
      if (!thead) return;
      thead.innerHTML = "";
      const tr = document.createElement("tr");
  
      const cols = Object.keys(colDict || {});
      cols.forEach((key) => {
        const th = document.createElement("th");
        th.className = `col-${key}`;
        th.textContent = String(colDict[key] || key);
        // 明確不換行，避免被其他樣式覆蓋
        th.style.whiteSpace = "nowrap";
        th.style.overflow = "hidden";
        th.style.textOverflow = "ellipsis";
        tr.appendChild(th);
      });
      thead.appendChild(tr);
    }
  
    // ---------- 表身（含 rowspan 合併） ----------
    function renderBody(expanded, colDict) {
      const tbody = $("#aoi_density-table tbody");
      if (!tbody) return;
      tbody.innerHTML = "";
  
      const { rows: expandedRows, perGlass } = expanded;
      if (!expandedRows.length) return;
  
      const colKeys = Object.keys(colDict || {});
      let lastGroup = null;
  
      expandedRows.forEach((row) => {
        const isNewGroup = row.__groupKey !== lastGroup;
        if (isNewGroup) lastGroup = row.__groupKey;
        
        const tr = document.createElement("tr");
        tr.className = "main-row";
  
        colKeys.forEach((key) => {
          const isPerGlass = perGlass.has(key);
  
          // 非 per-glass 欄位：只在群組首列輸出（套 rowspan）
          if (!isPerGlass && !isNewGroup) return;
  
          let cellValue = "";
          if (isPerGlass) {
            if (key === "glass") {
              cellValue = row.glass || "";
            } else if (key === "glass_defect_count") {
              const gdc = isObj(row.glass_defect_count) ? row.glass_defect_count : {};
              cellValue =
                row.__glassId && gdc[row.__glassId] != null ? gdc[row.__glassId] : "";
            } else {
              cellValue = row[key] != null ? row[key] : "";
            }
          } else {
            cellValue = row[key] != null ? row[key] : "";
          }
          /*
          
          */
          const td = document.createElement("td");
          td.className = `col-${key}`;
          // 強制不換行（再保一層）
          td.style.whiteSpace = "nowrap";
          td.style.overflow = "hidden";
          td.style.textOverflow = "ellipsis";
  
          if (!isPerGlass && isNewGroup) {
            td.classList.add("merged");
            td.rowSpan = row.__groupSize;
          }
  
          if (/count$/.test(key) || key === "n_glasses" || key === "density") {
            td.style.textAlign = "right";
          }
          td.textContent = cellValue === null ? "" : String(cellValue);
          tr.appendChild(td);
        });
  
        tbody.appendChild(tr);
      });
    }
  
    // ---------- 對外：渲染 ----------
    MOD.Table.render = function (rows, paramDict) {
      const colDict = isObj(paramDict?.hourlyTable) ? paramDict.hourlyTable : null;
  
      if (colDict && Object.keys(colDict).length) {
        renderHeader(colDict);
      } else {
        // 後備：若後端未提供 hourlyTable，動態取第一列 keys
        const sample = toArr(rows)[0] || {};
        const dyn = {};
        Object.keys(sample).forEach((k) => (dyn[k] = k));
        renderHeader(dyn);
      }
  
      // 2) rows → 展開（依 ParamDict 的 chartKeyDict 決定群組鍵）
      const expanded = expandRowsByGlass(rows || [], paramDict || {});
      renderBody(expanded, colDict || expanded.colsMap || {});
    };
  })();
  